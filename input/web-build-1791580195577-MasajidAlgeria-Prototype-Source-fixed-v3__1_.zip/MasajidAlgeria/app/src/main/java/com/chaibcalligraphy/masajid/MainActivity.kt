package com.chaibcalligraphy.masajid

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher

private const val GREEN = 0xFF0B3D32.toInt()
private const val GREEN2 = 0xFF176B55.toInt()
private const val GOLD = 0xFFC7A45B.toInt()
private const val CREAM = 0xFFF7F4EC.toInt()
private const val INK = 0xFF1F302B.toInt()
private const val MUTED = 0xFF69766F.toInt()

class MainActivity : Activity() {
    private lateinit var body: LinearLayout
    private lateinit var search: EditText
    private var activeTab = "الرئيسية"
    private val mosques = listOf(
        Mosque("مسجد عبد الحميد بن باديس", "وهران · الجزائر", "جامع كبير", "36.7111, -0.6325"),
        Mosque("المسجد الكبير", "الجزائر العاصمة · الجزائر", "مسجد تاريخي", "36.7850, 3.0600"),
        Mosque("مسجد الأمير عبد القادر", "قسنطينة · الجزائر", "معلم إسلامي", "36.3650, 6.6147"),
        Mosque("مسجد الاستقلال", "وهران · الجزائر", "مسجد الحي", "36.7200, -0.6400"),
        Mosque("مسجد النور", "تلمسان · الجزائر", "مسجد محلي", "34.8828, -1.3167")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = GREEN
        window.navigationBarColor = GREEN
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(CREAM) }
        val scroll = ScrollView(this).apply { setFillViewport(true) }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(24)) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomNav(), LinearLayout.LayoutParams(-1, dp(66)))
        setContentView(root)
        renderHome()
    }

    private data class Mosque(val name: String, val area: String, val tag: String, val coords: String)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun text(value: String, size: Float, color: Int = INK, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); gravity = Gravity.RIGHT
        if (bold) setTypeface(typeface, Typeface.BOLD)
        textDirection = View.TEXT_DIRECTION_RTL
    }
    private fun label(value: String, size: Float = 14f, color: Int = MUTED, bold: Boolean = false): TextView = text(value, size, color, bold)
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun sectionTitle(title: String, action: String = "") {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val t = text(title, 18f, GREEN, true).apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }
        row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        if (action.isNotEmpty()) row.addView(text(action, 12f, GREEN2, true))
        body.addView(row); body.addView(space(10))
    }

    private fun renderHome(query: String = "") {
        body.removeAllViews()
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(22)); background = rounded(GREEN, 24)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply { text = "۞"; textSize = 34f; setTextColor(GOLD); gravity = Gravity.CENTER; background = rounded(0xFF164D40.toInt(), 16) }
        top.addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT; setPadding(dp(12), 0, 0, 0) }
        brand.addView(text("مساجد الجزائر", 22f, Color.WHITE, true))
        brand.addView(text("دليلك إلى بيوت الله", 13f, 0xFFDCE9DF.toInt()))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f)); hero.addView(top)
        hero.addView(space(20))
        hero.addView(text("أقرب إلى بيوت الله", 23f, Color.WHITE, true))
        hero.addView(space(5))
        hero.addView(text("اكتشف المساجد، تابع الدروس، وشارك في خدمة مجتمعك.", 14f, 0xFFE4EEE8.toInt()))
        hero.addView(space(18))
        search = EditText(this).apply {
            hint = "ابحث عن مسجد أو مدينة..."; textSize = 14f; setSingleLine(true); setTextColor(INK); setHintTextColor(MUTED)
            setPadding(dp(14), 0, dp(14), 0); background = rounded(Color.WHITE, 14)
        }
        hero.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        body.addView(hero)
        search.setText(query)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { if (activeTab == "الرئيسية") showMosques(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        body.addView(space(22))
        sectionTitle("ماذا تحتاج اليوم؟")
        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tiles.addView(actionTile("⌖", "المساجد القريبة", "اكتشف حولك"), LinearLayout.LayoutParams(0, dp(112), 1f))
        val gap = View(this); tiles.addView(gap, LinearLayout.LayoutParams(dp(10), 1))
        tiles.addView(actionTile("◈", "بطاقتي", "رقمك الموحّد"), LinearLayout.LayoutParams(0, dp(112), 1f))
        body.addView(tiles); body.addView(space(10))
        val tiles2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tiles2.addView(actionTile("◉", "الدروس والأنشطة", "تابع مسجدك"), LinearLayout.LayoutParams(0, dp(105), 1f))
        tiles2.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        tiles2.addView(actionTile("＋", "أضف مسجدًا", "ساهم في الدليل"), LinearLayout.LayoutParams(0, dp(105), 1f))
        body.addView(tiles2); body.addView(space(24))
        sectionTitle("مساجد من قاعدة العرض التجريبية", "عرض الكل")
        val note = text("هذه سجلات نموذجية لا تمثل قاعدة البيانات الكاملة بعد.", 12f, MUTED)
        note.setPadding(0, 0, 0, dp(10)); body.addView(note)
        showMosques(query)
    }

    private fun actionTile(icon: String, title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT; setPadding(dp(14), dp(14), dp(14), dp(12)); background = rounded(Color.WHITE, 18, 0xFFE4E6DC.toInt())
        addView(text(icon, 22f, GOLD, true)); addView(space(6)); addView(text(title, 15f, GREEN, true)); addView(space(3)); addView(text(subtitle, 12f, MUTED))
    }

    private fun showMosques(query: String) {
        val old = body.findViewWithTag<LinearLayout>("mosque_list")
        if (old != null) body.removeView(old)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "mosque_list" }
        val filtered = mosques.filter { (it.name + it.area + it.tag).contains(query.trim(), ignoreCase = true) }
        if (filtered.isEmpty()) list.addView(text("لا توجد نتائج في البيانات التجريبية.", 14f, MUTED).apply { setPadding(0, dp(10), 0, dp(10)) })
        filtered.forEach { m ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(Color.WHITE, 18, 0xFFE7E6DE.toInt()) }
            val badge = TextView(this).apply { text = "۞"; textSize = 25f; setTextColor(GOLD); gravity = Gravity.CENTER; background = rounded(0xFFF0E8D5.toInt(), 14) }
            card.addView(badge, LinearLayout.LayoutParams(dp(54), dp(58)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT; setPadding(dp(12), 0, 0, 0) }
            info.addView(text(m.name, 15f, GREEN, true)); info.addView(space(4)); info.addView(text(m.area, 12f, MUTED)); info.addView(space(7))
            val tag = TextView(this).apply { text = m.tag; textSize = 10f; setTextColor(GREEN2); setPadding(dp(8), dp(4), dp(8), dp(4)); background = rounded(0xFFE4F0E8.toInt(), 8); gravity = Gravity.RIGHT }
            info.addView(tag)
            card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            card.setOnClickListener { showMosqueDetails(m) }
            list.addView(card); list.addView(space(10))
        }
        body.addView(list)
    }

    private fun showMosqueDetails(m: Mosque) {
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle(m.name)
            .setMessage("${m.area}\n${m.tag}\n\nالإحداثيات التجريبية: ${m.coords}\n\nستُربط التفاصيل الفعلية بقاعدة البيانات بعد استيرادها والتحقق منها.")
            .setPositiveButton("حسنًا", null)
            .create()
        dialog.show()
    }

    private fun bottomNav(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE); elevation = dp(10).toFloat()
        listOf("الرئيسية" to "⌂", "الخريطة" to "⌖", "البطاقات" to "▤", "المزيد" to "⋯").forEach { (title, icon) ->
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(5)) }
            col.addView(TextView(this@MainActivity).apply { text = icon; textSize = 21f; gravity = Gravity.CENTER; setTextColor(if (activeTab == title) GREEN2 else MUTED) })
            col.addView(TextView(this@MainActivity).apply { text = title; textSize = 10f; gravity = Gravity.CENTER; setTextColor(if (activeTab == title) GREEN2 else MUTED); if (activeTab == title) setTypeface(typeface, Typeface.BOLD) })
            col.setOnClickListener { activeTab = title; when (title) {
                "الرئيسية" -> renderHome()
                "الخريطة" -> showSimplePage("خريطة المساجد", "ستُضاف الخريطة التفاعلية بعد اختيار مزوّد الخرائط المناسب وشروط استخدامه.")
                "البطاقات" -> showSimplePage("بطاقاتي", "سيتم هنا طلب بطاقة المسلم أو المصلّي أو المتطوع أو فاعل الخير، بعد ربط نظام الحسابات والموافقات.")
                else -> showSimplePage("المزيد", "الإعدادات · اللغة · الخصوصية · عن التطبيق")
            }; recreateBottomNav() }
            addView(col, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }
    private fun recreateBottomNav() {
        val root = findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as? LinearLayout ?: return
        val old = root.getChildAt(root.childCount - 1); root.removeView(old); root.addView(bottomNav(), LinearLayout.LayoutParams(-1, dp(66)))
    }
    private fun showSimplePage(title: String, description: String) {
        body.removeAllViews()
        body.addView(space(30))
        body.addView(text("۞", 46f, GOLD, true).apply { gravity = Gravity.CENTER })
        body.addView(space(12))
        body.addView(text(title, 25f, GREEN, true).apply { gravity = Gravity.CENTER })
        body.addView(space(12))
        body.addView(text(description, 16f, MUTED).apply { gravity = Gravity.CENTER; setPadding(dp(18), 0, dp(18), 0) })
        body.addView(space(22))
        body.addView(text("هذه شاشة أولية ضمن النسخة التجريبية، وستُفعّل الوظائف عند تنفيذ المرحلة الخاصة بها.", 13f, MUTED).apply { gravity = Gravity.CENTER })
    }
}
