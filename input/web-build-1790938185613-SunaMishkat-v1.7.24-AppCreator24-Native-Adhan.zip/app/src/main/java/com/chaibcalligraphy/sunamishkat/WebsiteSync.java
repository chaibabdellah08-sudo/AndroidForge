package com.chaibcalligraphy.sunamishkat;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;

/**
 * Synchronizes prayer times and adhan settings from the WordPress control API.
 * The website remains the source of truth; local SharedPreferences keep the
 * last successful values available while the app is closed/offline.
 */
public final class WebsiteSync {
    public static final String BASE = "https://www.chaibcalligraphy.com/wp-json/mishkat/v1/";
    private WebsiteSync() {}

    public static void sync(Context context, Runnable done) {
        Context app = context.getApplicationContext();
        new Thread(() -> {
            boolean ok = false;
            try {
                JSONObject cfg = getJson(BASE + "app-config");
                if (cfg != null) {
                    JSONObject adhan = cfg.optJSONObject("adhan");
                    if (adhan != null) {
                        saveAdhan(app, adhan);
                        ok = true;
                    }
                }
            } catch (Exception ignored) {}

            try {
                JSONObject p = getJson(BASE + "prayer-times");
                if (p != null) {
                    JSONObject timings = p.optJSONObject("timings");
                    if (timings == null && p.optJSONObject("data") != null)
                        timings = p.optJSONObject("data").optJSONObject("timings");
                    if (timings != null) {
                        savePrayerTimes(app, timings);
                        ok = true;
                    }
                }
            } catch (Exception ignored) {}

            AdhanScheduler.scheduleAll(app);
            final boolean result = ok;
            if (done != null) new Handler(Looper.getMainLooper()).post(() -> done.run());
        }).start();
    }

    private static void saveAdhan(Context c, JSONObject a) {
        android.content.SharedPreferences.Editor e = c.getSharedPreferences("adhan_config", Context.MODE_PRIVATE).edit();
        String url = firstString(a, "sound_url", "url", "audio", "src");
        if (url != null && url.startsWith("http")) e.putString("sound_url", url);
        if (a.has("enabled")) e.putBoolean("enabled", a.optBoolean("enabled", true));
        if (a.has("volume")) e.putFloat("volume", (float)Math.max(0, Math.min(1, a.optDouble("volume", .85))));
        e.apply();
    }

    private static void savePrayerTimes(Context c, JSONObject t) {
        String[] keys = {"fajr", "dhuhr", "asr", "maghrib", "isha"};
        String[] names = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
        android.content.SharedPreferences.Editor e = c.getSharedPreferences("prayer_times", Context.MODE_PRIVATE).edit();
        for (int i = 0; i < keys.length; i++) {
            String v = t.optString(names[i], "");
            if (v.length() >= 5) v = v.substring(0,5);
            if (v.matches("\\d{1,2}:\\d{2}")) {
                String[] p = v.split(":");
                e.putInt(keys[i]+"_h", Integer.parseInt(p[0]));
                e.putInt(keys[i]+"_m", Integer.parseInt(p[1]));
            }
        }
        e.apply();
    }

    private static String firstString(JSONObject o, String... names) {
        for (String n : names) {
            String s = o.optString(n, "").trim();
            if (!s.isEmpty()) return s;
        }
        return null;
    }

    private static JSONObject getJson(String urlString) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(urlString).openConnection();
        c.setConnectTimeout(7000);
        c.setReadTimeout(10000);
        c.setRequestMethod("GET");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "SunaMishkat/1.7.23");
        try {
            if (c.getResponseCode() < 200 || c.getResponseCode() >= 300) return null;
            InputStream in = c.getInputStream();
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) b.append(line);
            r.close();
            return new JSONObject(b.toString());
        } finally { c.disconnect(); }
    }
}
