package com.chaibcalligraphy.sunamishkat;
public final class AppConfig {
 public static final String DEFAULT_ADHAN_URL="https://www.chaibcalligraphy.com/wp-content/uploads/2026/09/cbcd8d249dcc.mp3";
 public static String getAdhanUrl(android.content.Context c){
  String u=c.getSharedPreferences("adhan_config",0).getString("sound_url","");
  return u.startsWith("http")?u:DEFAULT_ADHAN_URL;
 }
 public static float getAdhanVolume(android.content.Context c){
  return c.getSharedPreferences("adhan_config",0).getFloat("volume",.85f);
 }
 public static boolean isAdhanEnabled(android.content.Context c){
  return c.getSharedPreferences("adhan_config",0).getBoolean("enabled",true);
 }
 private AppConfig(){}
}
