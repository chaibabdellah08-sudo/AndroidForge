package com.chaibcalligraphy.sunamishkat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AdhanReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        boolean test=i!=null && i.getBooleanExtra("test",false);
        String prayer=i!=null ? i.getStringExtra("prayer") : null;
        if(!test && prayer!=null) AdhanScheduler.scheduleNext(c,prayer);
        Intent s=new Intent(c,AdhanService.class)
                .putExtra("prayer",test ? "test" : prayer)
                .putExtra("test",test);
        if(Build.VERSION.SDK_INT>=26) c.startForegroundService(s);
        else c.startService(s);
    }
}
