package com.chaibcalligraphy.masajid

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

private const val GREEN = 0xFF0B3D32.toInt()
private const val GREEN2 = 0xFF176B55.toInt()
private const val GOLD = 0xFFC7A45B.toInt()
private const val CREAM = 0xFFF7F4EC.toInt()
private const val INK = 0xFF1F302B.toInt()
private const val MUTED = 0xFF69766F.toInt()
private const val LOCATION_REQUEST_CODE = 4107

class MainActivity : Activity() {
    private lateinit var rootLayout: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var search: EditText
    private var activeTab = "الرئيسية"
    private var locationManager: LocationManager? = null
    private var locationListener: LocationListener? = null
    private var currentLocation: Location? = null
    private var mapFocus: Location? = null
    private var radiusKm = 10.0
    private var locationPurpose = "nearby"
    private var nearResultContainer: LinearLayout? = null
    private val prefs by lazy { getSharedPreferences("masajid_local_v1", MODE_PRIVATE) }

    private data class Mosque(
        val name: String,
        val area: String,
        val tag: String,
        val lat: Double,
        val lon: Double,
        val precision: String = "تقريبي من مصدر مفتوح"
    )

    // A small, clearly-labelled starter catalogue. Coordinates for named Oran mosques
    // are taken from OpenStreetMap/Wikidata-linked public map records. This is NOT the
    // full national database; far-away records are kept for search, not shown as nearby.
    private val mosques = listOf(
        Mosque("مسجد القادسية", "وهران · الجزائر", "مسجد محلي", 35.73495, -0.56363),
        Mosque("مسجد عبد الحميد بن باديس", "وهران · الجزائر", "جامع كبير", 35.69773, -0.60643),
        Mosque("مسجد ابن بديس", "بير الجير · وهران", "مسجد محلي", 35.70966, -0.61989),
        Mosque("مسجد زيد بن حارثة", "وهران · الجزائر", "مسجد محلي", 35.70224, -0.62533),
        Mosque("مسجد أبي موسى الأشعري", "وهران · الجزائر", "مسجد محلي", 35.70126, -0.63983),
        Mosque("مسجد الشريفية", "وهران · الجزائر", "مسجد محلي", 35.69521, -0.64730),
        Mosque("مسجد الشيخ سنوسي", "وهران · الجزائر", "مسجد محلي", 35.67172, -0.65241),
        Mosque("مسجد القبة", "وهران · الجزائر", "مسجد محلي", 35.68022, -0.65049),
        Mosque("مسجد المهاجي", "وهران · الجزائر", "مسجد محلي", 35.69269, -0.64686),
        Mosque("مسجد محمد بن عثمان", "وهران · الجزائر", "مسجد محلي", 35.70444, -0.65445),
        Mosque("الجامع الكبير", "القصبة · الجزائر العاصمة", "مسجد تاريخي", 36.78500, 3.06000),
        Mosque("مسجد الأمير عبد القادر", "قسنطينة · الجزائر", "معلم إسلامي", 36.36500, 6.61470),
        Mosque("الجامع الكبير بتلمسان", "تلمسان · الجزائر", "مسجد تاريخي", 34.88490, -1.31490)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = GREEN
        window.navigationBarColor = GREEN
        rootLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(CREAM) }
        val scroll = ScrollView(this).apply { setFillViewport(true); clipToPadding = false }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(24)) }
        scroll.addView(body)
        rootLayout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        rootLayout.addView(bottomNav(), LinearLayout.LayoutParams(-1, dp(66)))
        setContentView(rootLayout)
        renderHome()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_REQUEST_CODE) {
            val granted = grantResults.any { it == PackageManager.PERMISSION_GRANTED }
            if (!granted) {
                if (locationPurpose == "form") Toast.makeText(this, "لم يُمنح إذن الموقع", Toast.LENGTH_SHORT).show()
                else showPermissionDenied()
            } else if (locationPurpose == "form") {
                getLocationForMosqueForm()
            } else {
                loadNearbyMosques()
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 18, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun text(value: String, size: Float, color: Int = INK, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); gravity = Gravity.RIGHT
        if (bold) setTypeface(typeface, Typeface.BOLD)
        textDirection = View.TEXT_DIRECTION_RTL
    }
    private fun appButton(value: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = value; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD); setPadding(dp(18), dp(13), dp(18), dp(13))
        background = rounded(GREEN2, 14); isClickable = true; isFocusable = true
        setOnClickListener { onClick() }
    }
    private fun secondaryButton(value: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = value; textSize = 14f; setTextColor(GREEN); gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD); setPadding(dp(16), dp(12), dp(16), dp(12))
        background = rounded(Color.WHITE, 14, 0xFFE0E3D8.toInt()); isClickable = true; isFocusable = true
        setOnClickListener { onClick() }
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun pageTitle(title: String, subtitle: String? = null) {
        body.addView(space(6))
        body.addView(text(title, 24f, GREEN, true))
        if (subtitle != null) { body.addView(space(6)); body.addView(text(subtitle, 13f, MUTED)) }
        body.addView(space(16))
    }
    private fun sectionTitle(title: String, action: String = "") {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text(title, 18f, GREEN, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (action.isNotEmpty()) {
            val actionView = text(action, 12f, GREEN2, true).apply {
                isClickable = true; isFocusable = true
                setOnClickListener { if (action == "عرض الكل") showAllMosques() }
            }
            row.addView(actionView)
        }
        body.addView(row); body.addView(space(10))
    }
    private fun input(hintText: String, singleLine: Boolean = true): EditText = EditText(this).apply {
        hint = hintText; textSize = 14f; setSingleLine(singleLine); setTextColor(INK); setHintTextColor(MUTED)
        setPadding(dp(13), dp(10), dp(13), dp(10)); background = rounded(Color.WHITE, 12, 0xFFE2E4DA.toInt())
        textDirection = View.TEXT_DIRECTION_RTL; gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
    }
    private fun styledSpinner(items: List<String>): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        s.background = rounded(Color.WHITE, 12, 0xFFE2E4DA.toInt())
        return s
    }

    private fun renderHome(query: String = "") {
        activeTab = "الرئيسية"
        body.removeAllViews()
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(22)); background = rounded(GREEN, 24) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.masajid_logo); scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(0xFF164D40.toInt(), 16); clipToOutline = true; contentDescription = "شعار مساجد الجزائر"
        }
        top.addView(logo, LinearLayout.LayoutParams(dp(64), dp(64)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT; setPadding(dp(12), 0, 0, 0) }
        brand.addView(text("مساجد الجزائر", 22f, Color.WHITE, true))
        brand.addView(text("دليلك إلى بيوت الله", 13f, 0xFFDCE9DF.toInt()))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f)); hero.addView(top)
        hero.addView(space(20)); hero.addView(text("أقرب إلى بيوت الله", 23f, Color.WHITE, true)); hero.addView(space(5))
        hero.addView(text("اكتشف المساجد، تابع الدروس، وشارك في خدمة مجتمعك.", 14f, 0xFFE4EEE8.toInt())); hero.addView(space(18))
        search = input("ابحث عن مسجد أو مدينة...")
        hero.addView(search, LinearLayout.LayoutParams(-1, dp(50))); body.addView(hero)
        search.setText(query)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { if (activeTab == "الرئيسية") updateHomeMosques(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        body.addView(space(22)); sectionTitle("ماذا تحتاج اليوم؟")
        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tiles.addView(actionTile("⌖", "المساجد القريبة", "اكتشف حولك"), LinearLayout.LayoutParams(0, dp(112), 1f))
        tiles.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        tiles.addView(actionTile("◈", "بطاقاتي", "طلبات وبطاقات"), LinearLayout.LayoutParams(0, dp(112), 1f))
        body.addView(tiles); body.addView(space(10))
        val tiles2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tiles2.addView(actionTile("◉", "الدروس والتطوع", "أنشطة المسجد"), LinearLayout.LayoutParams(0, dp(105), 1f))
        tiles2.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        tiles2.addView(actionTile("＋", "أضف مسجدًا", "ساهم في الدليل"), LinearLayout.LayoutParams(0, dp(105), 1f))
        body.addView(tiles2); body.addView(space(24)); sectionTitle("مساجد في دليل البداية", "عرض الكل")
        body.addView(text("قاعدة البداية محدودة؛ لا تمثل جميع مساجد الجزائر. سيتم توسيعها بالبيانات المفتوحة ومراجعتها.", 12f, MUTED))
        body.addView(space(10))
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "home_mosques" }
        body.addView(results)
        updateHomeMosques(query)
    }

    private fun actionTile(icon: String, title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT; setPadding(dp(14), dp(14), dp(14), dp(12)); background = rounded(Color.WHITE, 18, 0xFFE4E6DC.toInt())
        isClickable = true; isFocusable = true
        addView(text(icon, 22f, GOLD, true)); addView(space(6)); addView(text(title, 15f, GREEN, true)); addView(space(3)); addView(text(subtitle, 12f, MUTED))
        setOnClickListener { when (title) {
            "المساجد القريبة" -> { activeTab = "الخريطة"; showNearbyPage(); if (currentLocation == null) loadNearbyMosques() }
            "بطاقاتي" -> showCardsPage()
            "الدروس والتطوع" -> showActivitiesPage()
            "أضف مسجدًا" -> showAddMosquePage()
        } }
    }

    private fun updateHomeMosques(query: String) {
        val container = body.findViewWithTag<LinearLayout>("home_mosques") ?: return
        container.removeAllViews()
        val filtered = mosques.filter { (it.name + it.area + it.tag).contains(query.trim(), ignoreCase = true) }
        if (filtered.isEmpty()) container.addView(text("لا توجد نتائج مطابقة في بيانات البداية.", 14f, MUTED))
        filtered.take(6).forEach { m -> container.addView(mosqueCard(m, null)); container.addView(space(9)) }
    }

    // NEARBY: only return mosques inside the selected radius, not every record in the country.
    private fun showNearbyPage() {
        activeTab = "الخريطة"
        body.removeAllViews(); nearResultContainer = null
        pageTitle("المساجد الأقرب إليك", "اختر نطاقًا جغرافيًا. لا يتم عرض المساجد خارج النطاق المحدد.")
        val radiusLabels = listOf("5 كم", "10 كم", "25 كم", "50 كم")
        body.addView(text("نطاق البحث", 14f, GREEN, true)); body.addView(space(5))
        val radiusSpinner = styledSpinner(radiusLabels)
        radiusSpinner.setSelection(listOf(5.0, 10.0, 25.0, 50.0).indexOf(radiusKm).coerceAtLeast(0), false)
        body.addView(radiusSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        radiusSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                radiusKm = listOf(5.0, 10.0, 25.0, 50.0)[position]
                currentLocation?.let { populateNearbyResults(it) }
            }
        }
        body.addView(space(10))
        body.addView(appButton("⌖  تحديد موقعي وتحديث الأقرب", ::loadNearbyMosques), LinearLayout.LayoutParams(-1, -2))
        body.addView(space(8))
        body.addView(secondaryButton("عرض الخريطة", ::showMapPage), LinearLayout.LayoutParams(-1, -2))
        body.addView(space(12))
        val resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "nearby_results" }
        nearResultContainer = resultBox
        body.addView(resultBox)
        if (currentLocation != null) populateNearbyResults(currentLocation!!)
        else resultBox.addView(text("اضغط تحديد موقعي لترتيب المساجد القريبة. ستظهر هنا النتائج التي تقع ضمن النطاق فقط.", 14f, MUTED))
        recreateBottomNav()
    }

    private fun hasLocationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadNearbyMosques() {
        locationPurpose = "nearby"
        mapFocus = null
        if (!hasLocationPermission()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), LOCATION_REQUEST_CODE)
            return
        }
        activeTab = "الخريطة"
        if (nearResultContainer == null) showNearbyPage()
        nearResultContainer?.removeAllViews()
        nearResultContainer?.addView(text("نحدّد موقعك ونبحث ضمن ${radiusKm.toInt()} كم…", 14f, MUTED))
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            locationManager = lm
            val fineGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val providers = (if (fineGranted) listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER) else listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER))
            val enabled = providers.filter { p -> try { lm.isProviderEnabled(p) } catch (_: Exception) { false } }
            val lastKnown = enabled.mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null } }.maxByOrNull { it.time }
            if (lastKnown != null) {
                currentLocation = lastKnown
                mapFocus = null
                populateNearbyResults(lastKnown)
            }
            val provider = when {
                fineGranted && enabled.contains(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                enabled.contains(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                enabled.isNotEmpty() -> enabled.first()
                else -> null
            }
            if (provider == null) { showLocationOffMessage(); return }
            locationListener?.let { listener -> try { lm.removeUpdates(listener) } catch (_: Exception) {} }
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    try { lm.removeUpdates(this) } catch (_: Exception) {}
                    locationListener = null
                    currentLocation = location
                    mapFocus = null
                    populateNearbyResults(location)
                }
                @Deprecated("Deprecated by Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            locationListener = listener
            @Suppress("DEPRECATION")
            lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
            Toast.makeText(this, "المسافة المعروضة بخط مستقيم؛ مسافة الطريق قد تختلف.", Toast.LENGTH_LONG).show()
        } catch (_: SecurityException) {
            showPermissionDenied()
        } catch (_: Exception) {
            showLocationOffMessage()
        }
    }

    private fun populateNearbyResults(location: Location) {
        currentLocation = location
        val box = nearResultContainer ?: return
        box.removeAllViews()
        box.addView(text("موقعك: ${String.format(Locale.US, "%.5f", location.latitude)}, ${String.format(Locale.US, "%.5f", location.longitude)}", 11f, MUTED))
        box.addView(space(8))
        val sorted = mosques.mapNotNull { m ->
            val target = Location("mosque").apply { latitude = m.lat; longitude = m.lon }
            val km = location.distanceTo(target).toDouble() / 1000.0
            if (km <= radiusKm) m to km else null
        }.sortedBy { it.second }
        if (sorted.isEmpty()) {
            box.addView(space(10)); box.addView(text("لا توجد مساجد في بيانات البداية ضمن ${radiusKm.toInt()} كم. قد تكون القاعدة التجريبية غير مكتملة.", 15f, GREEN, true))
            box.addView(space(8)); box.addView(text("جرّب توسيع النطاق أو استخدم الخريطة للبحث حول موقعك.", 13f, MUTED))
        } else {
            box.addView(text("${sorted.size} مسجد ضمن ${radiusKm.toInt()} كم", 15f, GREEN, true)); box.addView(space(8))
            sorted.forEach { (m, km) -> box.addView(mosqueCard(m, km)); box.addView(space(9)) }
        }
        box.addView(space(12))
        box.addView(secondaryButton("تحديث الموقع", ::loadNearbyMosques), LinearLayout.LayoutParams(-1, -2))
    }

    private fun showLocationOffMessage() {
        nearResultContainer = null
        body.removeAllViews()
        pageTitle("الموقع غير متاح", "فعّل خدمة الموقع في الهاتف ثم أعد المحاولة.")
        body.addView(appButton("فتح إعدادات الموقع", { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }), LinearLayout.LayoutParams(-1, -2))
        body.addView(space(8))
        body.addView(secondaryButton("العودة إلى المساجد القريبة", ::showNearbyPage), LinearLayout.LayoutParams(-1, -2))
        recreateBottomNav()
    }

    private fun showPermissionDenied() {
        nearResultContainer = null
        body.removeAllViews(); pageTitle("إذن الموقع مطلوب", "اسمح للتطبيق باستخدام الموقع أثناء الاستخدام حتى يرتب المساجد حسب قربها.")
        body.addView(appButton("طلب إذن الموقع", ::loadNearbyMosques), LinearLayout.LayoutParams(-1, -2)); body.addView(space(8))
        body.addView(secondaryButton("عرض المساجد دون ترتيب جغرافي", { activeTab = "الرئيسية"; renderHome(); recreateBottomNav() }), LinearLayout.LayoutParams(-1, -2))
        recreateBottomNav()
    }

    private fun showMapPage() {
        activeTab = "الخريطة"
        body.removeAllViews()
        pageTitle("الخريطة التفاعلية", "تستخدم هذه النسخة خريطة OpenStreetMap عبر الإنترنت. بيانات البحث المحلية ستظل على الهاتف.")
        body.addView(appButton("تحديد الموقع وعرض الأقرب", { showNearbyPage(); loadNearbyMosques() }), LinearLayout.LayoutParams(-1, -2))
        body.addView(space(10))
        val loc = mapFocus ?: currentLocation
        val lat = loc?.latitude ?: 35.69773
        val lon = loc?.longitude ?: -0.60643
        if (loc == null) body.addView(text("الخريطة معروضة مبدئيًا حول وهران. حدّد موقعك لعرض منطقتك.", 12f, MUTED))
        body.addView(space(8))
        val dLon = 0.11
        val dLat = 0.065
        val bbox = String.format(Locale.US, "%.5f,%.5f,%.5f,%.5f", lon - dLon, lat - dLat, lon + dLon, lat + dLat)
        val marker = String.format(Locale.US, "%.6f,%.6f", lat, lon)
        val web = WebView(this).apply {
            setBackgroundColor(CREAM)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head><body style='margin:0;background:#f7f4ec'><iframe title='OpenStreetMap' width='100%' height='100%' frameborder='0' scrolling='no' marginheight='0' marginwidth='0' src='https://www.openstreetmap.org/export/embed.html?bbox=$bbox&layer=mapnik&marker=$marker' style='height:420px;border:0'></iframe><div style='font:12px sans-serif;text-align:center;padding:5px'>الخريطة © <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a> contributors</div></body></html>"""
            loadDataWithBaseURL("https://www.openstreetmap.org/", html, "text/html", "UTF-8", null)
        }
        body.addView(web, LinearLayout.LayoutParams(-1, dp(420)))
        body.addView(space(10))
        body.addView(secondaryButton("قائمة المساجد القريبة", ::showNearbyPage), LinearLayout.LayoutParams(-1, -2))
        recreateBottomNav()
    }

    private fun showAllMosques() {
        activeTab = "الخريطة"
        body.removeAllViews(); pageTitle("دليل المساجد التجريبي", "مرتّب حسب الاسم؛ هذه القائمة الأولية ليست قاعدة الجزائر الكاملة.")
        mosques.sortedBy { it.name }.forEach { m -> body.addView(mosqueCard(m, null)); body.addView(space(8)) }
        body.addView(space(10)); body.addView(appButton("البحث عن الأقرب باستخدام GPS", { showNearbyPage(); loadNearbyMosques() }), LinearLayout.LayoutParams(-1, -2))
        recreateBottomNav()
    }

    private fun mosqueCard(m: Mosque, distanceKm: Double?): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(Color.WHITE, 18, 0xFFE7E6DE.toInt())
            isClickable = true; isFocusable = true
        }
        val badge = TextView(this).apply { text = "۞"; textSize = 25f; setTextColor(GOLD); gravity = Gravity.CENTER; background = rounded(0xFFF0E8D5.toInt(), 14) }
        card.addView(badge, LinearLayout.LayoutParams(dp(54), dp(58)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT; setPadding(dp(12), 0, 0, 0) }
        info.addView(text(m.name, 15f, GREEN, true)); info.addView(space(4)); info.addView(text(m.area, 12f, MUTED)); info.addView(space(7))
        val caption = if (distanceKm == null) m.tag else "${formatDistance(distanceKm)} · ${m.tag}"
        val tagView = TextView(this).apply { text = caption; textSize = 10f; setTextColor(GREEN2); setPadding(dp(8), dp(5), dp(8), dp(5)); background = rounded(0xFFE4F0E8.toInt(), 8); gravity = Gravity.RIGHT }
        info.addView(tagView); card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener { showMosqueDetails(m) }
        return card
    }

    private fun formatDistance(km: Double): String = if (km < 1.0) "${(km * 1000).toInt()} متر" else "${String.format(Locale.getDefault(), "%.1f", km)} كم"

    private fun showMosqueDetails(m: Mosque) {
        AlertDialog.Builder(this)
            .setTitle(m.name)
            .setMessage("${m.area}\n${m.tag}\nالإحداثيات: ${String.format(Locale.US, "%.5f", m.lat)}, ${String.format(Locale.US, "%.5f", m.lon)}\n\nهذه بيانات أولية مفتوحة، ويجب التحقق منها قبل اعتمادها نهائيًا.")
            .setPositiveButton("الاتجاهات") { _, _ -> openDirections(m) }
            .setNeutralButton("عرض على الخريطة") { _, _ -> showMapForMosque(m) }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun openDirections(m: Mosque) {
        val uri = Uri.parse("google.navigation:q=${m.lat},${m.lon}")
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${m.lat},${m.lon}?q=${m.lat},${m.lon}(${Uri.encode(m.name)})"))) }
            catch (_: Exception) { Toast.makeText(this, "لا يوجد تطبيق خرائط متاح", Toast.LENGTH_LONG).show() }
        }
    }

    private fun showMapForMosque(m: Mosque) {
        mapFocus = Location("selected-mosque").apply { latitude = m.lat; longitude = m.lon }
        showMapPage()
    }

    private fun showCardsPage() {
        activeTab = "البطاقات"; body.removeAllViews()
        pageTitle("بطاقاتي", "قدّم طلبًا واحفظ مسودته على هاتفك. الاعتماد الإلكتروني والمزامنة يحتاجان خادمًا مركزيًا.")
        body.addView(text("نوع البطاقة", 14f, GREEN, true)); body.addView(space(4))
        val types = listOf("بطاقة المسلم", "بطاقة المصلّي", "بطاقة المتطوّع", "بطاقة فاعل خير", "بطاقة الإمام")
        val typeSpinner = styledSpinner(types); body.addView(typeSpinner, LinearLayout.LayoutParams(-1, dp(48))); body.addView(space(10))
        val nameField = input("الاسم الكامل")
        body.addView(nameField, LinearLayout.LayoutParams(-1, dp(50))); body.addView(space(10))
        body.addView(text("المسجد المرتبط بالطلب", 14f, GREEN, true)); body.addView(space(4))
        val mosqueSpinner = styledSpinner(mosques.map { "${it.name} — ${it.area.substringBefore("·").trim()}" })
        body.addView(mosqueSpinner, LinearLayout.LayoutParams(-1, dp(48))); body.addView(space(12))
        body.addView(appButton("حفظ طلب البطاقة", {
            val nm = nameField.text.toString().trim()
            if (nm.length < 3) { nameField.error = "أدخل الاسم الكامل"; return@appButton }
            val mosque = mosques[mosqueSpinner.selectedItemPosition.coerceIn(0, mosques.lastIndex)]
            val id = "MA-${UUID.randomUUID().toString().replace("-", "").take(8).uppercase(Locale.ROOT)}"
            val card = JSONObject().put("id", id).put("name", nm).put("type", types[typeSpinner.selectedItemPosition]).put("mosque", mosque.name).put("status", "بانتظار الاعتماد").put("created", System.currentTimeMillis())
            val arr = getJsonArray("cards")
            arr.put(card); prefs.edit().putString("cards", arr.toString()).apply()
            Toast.makeText(this, "حُفظ الطلب على هذا الهاتف. لم يُرسل إلى الإمام بعد.", Toast.LENGTH_LONG).show()
            showCardsPage()
        }), LinearLayout.LayoutParams(-1, -2))
        body.addView(space(20)); sectionTitle("طلباتك المحفوظة على الهاتف")
        val cards = getJsonArray("cards")
        if (cards.length() == 0) body.addView(text("لا توجد طلبات بطاقات محفوظة بعد.", 13f, MUTED))
        for (i in cards.length() - 1 downTo 0) {
            val c = cards.optJSONObject(i) ?: continue
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14)); background = rounded(Color.WHITE, 16, 0xFFE2E4DA.toInt()) }
            box.addView(text(c.optString("type"), 16f, GREEN, true)); box.addView(space(4)); box.addView(text(c.optString("name"), 14f, INK))
            box.addView(space(4)); box.addView(text("${c.optString("id")} · ${c.optString("status")}", 11f, MUTED)); box.addView(space(4)); box.addView(text("المسجد: ${c.optString("mosque")}", 12f, MUTED))
            body.addView(box); body.addView(space(8))
        }
        if (cards.length() > 0) body.addView(text("تنبيه: الرقم في هذه النسخة محلي للتجربة وغير مسجل عالميًا، ولا تُعد البطاقة وثيقة رسمية.", 12f, MUTED))
        recreateBottomNav()
    }

    private fun showActivitiesPage() {
        activeTab = "المزيد"; body.removeAllViews()
        pageTitle("الدروس والتطوع", "أمثلة محلية قابلة للتفاعل في النسخة التجريبية. لم تُنشر بعد من مساجد موثّقة.")
        addActivityCard("درس في تفسير القرآن", "مثال توضيحي · بعد صلاة المغرب", "دروس", "book")
        addActivityCard("حلقة تحفيظ للصغار", "مثال توضيحي · نهاية الأسبوع", "دروس", "book")
        addActivityCard("مبادرة لتنظيف المسجد", "مثال تطوعي توضيحي · التسجيل اختياري", "تطوع", "volunteer")
        addActivityCard("مساعدة في تنظيم نشاط خيري", "مثال تطوعي توضيحي", "تطوع", "volunteer")
        body.addView(space(12)); body.addView(text("عند ربط التطبيق بالخادم، سيتولى الإمام أو رئيس الجمعية المعتمد نشر الإعلانات وتحديد المسجد والتاريخ، ثم تصل للمصلّين الذين اختاروا متابعة ذلك المسجد.", 12f, MUTED))
        recreateBottomNav()
    }

    private fun addActivityCard(title: String, details: String, category: String, key: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14)); background = rounded(Color.WHITE, 16, 0xFFE5E5DC.toInt()) }
        box.addView(text(if (key == "book") "📖  $title" else "🤝  $title", 16f, GREEN, true)); box.addView(space(5)); box.addView(text(details, 12f, MUTED)); box.addView(space(10))
        box.addView(appButton(if (key == "book") "حفظ كتذكير" else "سجّل اهتمامي بالتطوع", {
            val arr = getJsonArray("activity_signups")
            arr.put(JSONObject().put("title", title).put("category", category).put("time", System.currentTimeMillis()))
            prefs.edit().putString("activity_signups", arr.toString()).apply()
            Toast.makeText(this, if (key == "book") "حُفظ كتذكير محلي على الهاتف" else "حُفظ اهتمامك محليًا. لا يصل لمسؤول المسجد بعد.", Toast.LENGTH_LONG).show()
        }))
        body.addView(box); body.addView(space(9))
    }

    private var mosqueNameField: EditText? = null
    private var mosqueAreaField: EditText? = null
    private var mosqueAddressField: EditText? = null
    private var mosquePhoneField: EditText? = null
    private var mosqueCoordsField: EditText? = null

    private fun showAddMosquePage() {
        activeTab = "المزيد"; body.removeAllViews()
        pageTitle("إضافة مسجد", "املأ ما تعرفه من بيانات. سيُحفظ الطلب محليًا في هذه النسخة التجريبية.")
        mosqueNameField = input("اسم المسجد")
        mosqueAreaField = input("الولاية والبلدية")
        mosqueAddressField = input("العنوان أو الحي", false)
        mosquePhoneField = input("رقم الهاتف (اختياري)")
        mosqueCoordsField = input("الإحداثيات: تُضاف من زر الموقع")
        body.addView(mosqueNameField, LinearLayout.LayoutParams(-1, dp(50))); body.addView(space(8))
        body.addView(mosqueAreaField, LinearLayout.LayoutParams(-1, dp(50))); body.addView(space(8))
        body.addView(mosqueAddressField, LinearLayout.LayoutParams(-1, dp(76))); body.addView(space(8))
        body.addView(mosquePhoneField, LinearLayout.LayoutParams(-1, dp(50))); body.addView(space(8))
        body.addView(mosqueCoordsField, LinearLayout.LayoutParams(-1, dp(50))); body.addView(space(8))
        body.addView(secondaryButton("استخدم موقعي الحالي لإحداثيات المسجد", ::useCurrentLocationForMosqueForm), LinearLayout.LayoutParams(-1, -2)); body.addView(space(10))
        body.addView(appButton("حفظ طلب إضافة المسجد", {
            val name = mosqueNameField?.text?.toString()?.trim().orEmpty()
            val area = mosqueAreaField?.text?.toString()?.trim().orEmpty()
            if (name.length < 3) { mosqueNameField?.error = "أدخل اسم المسجد"; return@appButton }
            if (area.length < 2) { mosqueAreaField?.error = "أدخل الولاية أو البلدية"; return@appButton }
            val coords = mosqueCoordsField?.text?.toString()?.trim().orEmpty()
            val req = JSONObject().put("name", name).put("area", area).put("address", mosqueAddressField?.text?.toString()?.trim().orEmpty()).put("phone", mosquePhoneField?.text?.toString()?.trim().orEmpty()).put("coords", coords).put("status", "بانتظار المزامنة والمراجعة").put("created", System.currentTimeMillis())
            val arr = getJsonArray("pending_mosques"); arr.put(req); prefs.edit().putString("pending_mosques", arr.toString()).apply()
            AlertDialog.Builder(this).setTitle("حُفظ طلب المسجد").setMessage("تم حفظ الطلب على هذا الهاتف فقط. لن يصل إلى أقرب إمام حتى نربط خدمة المزامنة والخادم.").setPositiveButton("حسنًا") { _, _ -> showAddMosquePage() }.show()
        }), LinearLayout.LayoutParams(-1, -2))
        body.addView(space(14)); body.addView(text("لمنع البيانات المضللة، لا يُضاف المسجد إلى الدليل العام قبل مراجعة التكرار والموقع واعتماده من مسؤول مخوّل.", 12f, MUTED))
        recreateBottomNav()
    }

    private fun useCurrentLocationForMosqueForm() {
        locationPurpose = "form"
        if (!hasLocationPermission()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), LOCATION_REQUEST_CODE)
            return
        }
        getLocationForMosqueForm()
    }

    private fun getLocationForMosqueForm() {
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            locationManager = lm
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
            val last = providers.mapNotNull { try { lm.getLastKnownLocation(it) } catch (_: SecurityException) { null } }.maxByOrNull { it.time }
            if (last != null) fillMosqueCoords(last)
            val provider = providers.firstOrNull() ?: run { Toast.makeText(this, "فعّل الموقع في الهاتف", Toast.LENGTH_LONG).show(); return }
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    try { lm.removeUpdates(this) } catch (_: Exception) {}
                    locationListener = null; fillMosqueCoords(location)
                }
                @Deprecated("Deprecated by Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            locationListener?.let { try { lm.removeUpdates(it) } catch (_: Exception) {} }
            locationListener = listener
            @Suppress("DEPRECATION") lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
            Toast.makeText(this, "جارٍ تحديد الموقع…", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { Toast.makeText(this, "تعذر تحديد الموقع", Toast.LENGTH_SHORT).show() }
    }

    private fun fillMosqueCoords(location: Location) {
        currentLocation = location
        mosqueCoordsField?.setText(String.format(Locale.US, "%.6f, %.6f", location.latitude, location.longitude))
    }

    private fun showMorePage() {
        activeTab = "المزيد"; body.removeAllViews(); pageTitle("المزيد", "خيارات التطبيق وحالة البيانات المحلية")
        body.addView(appButton("إضافة مسجد", ::showAddMosquePage), LinearLayout.LayoutParams(-1, -2)); body.addView(space(8))
        body.addView(appButton("الدروس والتطوع", ::showActivitiesPage), LinearLayout.LayoutParams(-1, -2)); body.addView(space(8))
        body.addView(appButton("بطاقاتي", ::showCardsPage), LinearLayout.LayoutParams(-1, -2)); body.addView(space(8))
        body.addView(secondaryButton("عرض كل المساجد في قاعدة البداية", ::showAllMosques), LinearLayout.LayoutParams(-1, -2)); body.addView(space(16))
        val pending = getJsonArray("pending_mosques").length()
        val cards = getJsonArray("cards").length()
        val signups = getJsonArray("activity_signups").length()
        body.addView(text("حالة التخزين المحلي", 17f, GREEN, true)); body.addView(space(7))
        body.addView(text("طلبات إضافة المساجد المحفوظة: $pending\nطلبات البطاقات: $cards\nاهتمامات الأنشطة المحفوظة: $signups", 13f, MUTED)); body.addView(space(16))
        body.addView(text("معلومات البيانات: بعض مواقع المساجد الأولية مستمدة من بيانات OpenStreetMap/Wikidata؛ يجب إسناد المصادر واحترام شروطها عند نشر قاعدة مشتقة. هذه النسخة لا تتصل بخادم مركزي، لذا لا تتم مزامنة الطلبات ولا إرسال إشعارات حقيقية بعد.", 12f, MUTED))
        recreateBottomNav()
    }

    private fun getJsonArray(key: String): JSONArray = try { JSONArray(prefs.getString(key, "[]")) } catch (_: Exception) { JSONArray() }

    private fun bottomNav(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE); elevation = dp(10).toFloat()
        listOf("الرئيسية" to "⌂", "الخريطة" to "⌖", "البطاقات" to "▤", "المزيد" to "⋯").forEach { (title, icon) ->
            val selected = activeTab == title
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(5)); isClickable = true; isFocusable = true }
            col.addView(TextView(this@MainActivity).apply { text = icon; textSize = 21f; gravity = Gravity.CENTER; setTextColor(if (selected) GREEN2 else MUTED) })
            col.addView(TextView(this@MainActivity).apply { text = title; textSize = 10f; gravity = Gravity.CENTER; setTextColor(if (selected) GREEN2 else MUTED); if (selected) setTypeface(typeface, Typeface.BOLD) })
            col.setOnClickListener { when (title) {
                "الرئيسية" -> renderHome()
                "الخريطة" -> showMapPage()
                "البطاقات" -> showCardsPage()
                else -> showMorePage()
            }; recreateBottomNav() }
            addView(col, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun recreateBottomNav() {
        if (!::rootLayout.isInitialized || rootLayout.childCount < 2) return
        rootLayout.removeViewAt(rootLayout.childCount - 1)
        rootLayout.addView(bottomNav(), LinearLayout.LayoutParams(-1, dp(66)))
    }

    override fun onDestroy() {
        locationListener?.let { listener -> try { locationManager?.removeUpdates(listener) } catch (_: Exception) {} }
        locationListener = null
        super.onDestroy()
    }
}
