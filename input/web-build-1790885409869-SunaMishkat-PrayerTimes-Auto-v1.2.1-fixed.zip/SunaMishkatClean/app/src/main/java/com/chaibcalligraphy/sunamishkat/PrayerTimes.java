package com.chaibcalligraphy.sunamishkat;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/** Lightweight local prayer-time calculator. No external libraries required. */
public final class PrayerTimes {
    public final int fajr, sunrise, dhuhr, asr, sunset, maghrib, isha;

    private PrayerTimes(int fajr, int sunrise, int dhuhr, int asr,
                        int sunset, int maghrib, int isha) {
        this.fajr = fajr;
        this.sunrise = sunrise;
        this.dhuhr = dhuhr;
        this.asr = asr;
        this.sunset = sunset;
        this.maghrib = maghrib;
        this.isha = isha;
    }

    public static PrayerTimes calculate(Calendar date, double latitude,
                                        double longitude, double tzHours) {
        int dayOfYear = date.get(Calendar.DAY_OF_YEAR);
        double gamma = 2.0 * Math.PI / 365.0 * (dayOfYear - 1);

        double equationOfTime = 229.18 * (
                0.000075
                        + 0.001868 * Math.cos(gamma)
                        - 0.032077 * Math.sin(gamma)
                        - 0.014615 * Math.cos(2 * gamma)
                        - 0.040849 * Math.sin(2 * gamma));

        double declination = 0.006918
                - 0.399912 * Math.cos(gamma)
                + 0.070257 * Math.sin(gamma)
                - 0.006758 * Math.cos(2 * gamma)
                + 0.000907 * Math.sin(2 * gamma)
                - 0.002697 * Math.cos(3 * gamma)
                + 0.001480 * Math.sin(3 * gamma);

        double solarNoon = 720.0 - 4.0 * longitude - equationOfTime + tzHours * 60.0;

        // Initialize every local value first. This also keeps javac's definite-assignment
        // analysis happy on all Android/Java toolchains.
        int fajr = minToClock(solarNoon - hourAngle(latitude, declination, -18.0));
        int sunrise = minToClock(solarNoon - hourAngle(latitude, declination, -0.833));
        int dhuhr = minToClock(solarNoon);
        int asr = minToClock(solarNoon + asrHourAngle(latitude, declination));
        int sunset = minToClock(solarNoon + hourAngle(latitude, declination, -0.833));
        int maghrib = sunset;
        int isha = minToClock(solarNoon + hourAngle(latitude, declination, -18.0));

        return new PrayerTimes(fajr, sunrise, dhuhr, asr, sunset, maghrib, isha);
    }

    private static double hourAngle(double latitude, double declination, double altitude) {
        double latRad = Math.toRadians(latitude);
        double altitudeRad = Math.toRadians(altitude);
        double numerator = Math.sin(altitudeRad) - Math.sin(latRad) * Math.sin(declination);
        double denominator = Math.cos(latRad) * Math.cos(declination);

        if (Math.abs(denominator) < 1e-9) return 0.0;

        double cosH = numerator / denominator;
        cosH = Math.max(-1.0, Math.min(1.0, cosH));
        return Math.toDegrees(Math.acos(cosH)) * 4.0;
    }

    // Asr shadow factor = 1 (standard single-shadow calculation).
    private static double asrHourAngle(double latitude, double declination) {
        double latDeg = Math.abs(latitude - Math.toDegrees(declination));
        double altitude = Math.toDegrees(Math.atan(1.0 / (1.0 + Math.tan(Math.toRadians(latDeg)))));
        return hourAngle(latitude, declination, altitude);
    }

    private static int minToClock(double minutes) {
        int value = (int) Math.round(minutes);
        value = ((value % 1440) + 1440) % 1440;
        return value;
    }

    public static String fmt(int minutes) {
        return String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60);
    }

    public static int tzMinutes() {
        return TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000;
    }

    private PrayerTimes() {}
}
