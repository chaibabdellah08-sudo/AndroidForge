package com.chaibcalligraphy.sunamishkat;
import android.content.*;
public class AdhanStopReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i){
   c.stopService(new Intent(c, AdhanService.class));
 }
}
