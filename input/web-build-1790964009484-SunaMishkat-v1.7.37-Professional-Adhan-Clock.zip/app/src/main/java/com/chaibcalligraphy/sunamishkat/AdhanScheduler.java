package com.chaibcalligraphy.sunamishkat;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

public final class AdhanScheduler {
    private static final int[] IDS = {2001,2002,2003,2004,2005};
    private static final String[] KEYS = {"fajr","dhuhr","asr","maghrib","isha"};

    public static void scheduleAll(Context c){
        cancelAll(c);
        android.content.SharedPreferences p=c.getSharedPreferences("prayer_times",Context.MODE_PRIVATE);
        for(int n=0;n<5;n++){
            int h=p.getInt(KEYS[n]+"_h",-1), m=p.getInt(KEYS[n]+"_m",-1);
            if(h<0||m<0) continue;
            Calendar cal=Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY,h); cal.set(Calendar.MINUTE,m); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0);
            if(cal.getTimeInMillis()<=System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR,1);
            Intent in=new Intent(c,AdhanReceiver.class).putExtra("prayer",KEYS[n]);
            PendingIntent pi=PendingIntent.getBroadcast(c,IDS[n],in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            setExact(am(c),cal.getTimeInMillis(),pi);
        }
    }

    public static void scheduleNext(Context c,String prayer){
        int n=index(prayer); if(n<0) return;
        android.content.SharedPreferences p=c.getSharedPreferences("prayer_times",Context.MODE_PRIVATE);
        int h=p.getInt(KEYS[n]+"_h",-1), m=p.getInt(KEYS[n]+"_m",-1); if(h<0||m<0)return;
        Calendar cal=Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR,1); cal.set(Calendar.HOUR_OF_DAY,h); cal.set(Calendar.MINUTE,m); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0);
        Intent in=new Intent(c,AdhanReceiver.class).putExtra("prayer",prayer);
        PendingIntent pi=PendingIntent.getBroadcast(c,IDS[n],in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        setExact(am(c),cal.getTimeInMillis(),pi);
    }

    public static void cancelAll(Context c){
        AlarmManager am=am(c);
        for(int n=0;n<5;n++){
            PendingIntent pi=PendingIntent.getBroadcast(c,IDS[n],new Intent(c,AdhanReceiver.class),PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(pi!=null)am.cancel(pi);
        }
    }
    private static int index(String s){for(int i=0;i<KEYS.length;i++)if(KEYS[i].equals(s))return i;return -1;}
    private static AlarmManager am(Context c){return (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);}
    private static void setExact(AlarmManager am,long at,PendingIntent pi){
        try{
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){
                if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.set(AlarmManager.RTC_WAKEUP,at,pi);
            }else if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
            else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);
        }catch(SecurityException e){
            if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.set(AlarmManager.RTC_WAKEUP,at,pi);
        }
    }
    private AdhanScheduler(){}
}
