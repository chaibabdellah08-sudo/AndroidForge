package com.chaibcalligraphy.sunamishkat;
public final class AppConfig {
 public static final String ADHAN_URL="https://www.chaibcalligraphy.com/wp-content/uploads/2026/09/cbcd8d249dcc.mp3";
 private AppConfig(){}
}
