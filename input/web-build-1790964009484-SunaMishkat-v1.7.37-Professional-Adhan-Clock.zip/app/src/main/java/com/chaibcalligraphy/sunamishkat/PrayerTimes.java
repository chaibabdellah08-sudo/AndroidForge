package com.chaibcalligraphy.sunamishkat;

import java.util.Calendar;
import java.util.Locale;

public final class PrayerTimes {
 public final int fajr,dhuhr,asr,maghrib,isha;
 private PrayerTimes(int f,int d,int a,int m,int i){fajr=f;dhuhr=d;asr=a;maghrib=m;isha=i;}
 public static PrayerTimes calculate(Calendar date,double lat,double lon,double tz){
  int day=date.get(Calendar.DAY_OF_YEAR); double g=2*Math.PI*(day-1)/365.0;
  double eq=229.18*(0.000075+0.001868*Math.cos(g)-0.032077*Math.sin(g)-0.014615*Math.cos(2*g)-0.040849*Math.sin(2*g));
  double dec=0.006918-0.399912*Math.cos(g)+0.070257*Math.sin(g)-0.006758*Math.cos(2*g)+0.000907*Math.sin(2*g)-0.002697*Math.cos(3*g)+0.00148*Math.sin(3*g);
  double noon=720-4*lon-eq+tz*60;
  int fajr=clock(noon-hourAngle(lat,dec,-18));
  int dhuhr=clock(noon);
  int asr=clock(noon+hourAngle(lat,dec,Math.toDegrees(Math.atan(1.0/(1.0+Math.tan(Math.toRadians(Math.abs(lat)-Math.toDegrees(dec))))))));
  int sunset=clock(noon+hourAngle(lat,dec,-0.833));
  int maghrib=sunset;
  int isha=clock(noon+hourAngle(lat,dec,-18));
  return new PrayerTimes(fajr,dhuhr,asr,maghrib,isha);
 }
 private static double hourAngle(double lat,double dec,double alt){double x=(Math.sin(Math.toRadians(alt))-Math.sin(Math.toRadians(lat))*Math.sin(dec))/(Math.cos(Math.toRadians(lat))*Math.cos(dec)); x=Math.max(-1,Math.min(1,x)); return Math.toDegrees(Math.acos(x))*4;}
 private static int clock(double v){int m=(int)Math.round(v);m=((m%1440)+1440)%1440;return m;}
 public static String fmt(int m){return String.format(Locale.US,"%02d:%02d",m/60,m%60);}
 private PrayerTimes() {throw new AssertionError();}
}
