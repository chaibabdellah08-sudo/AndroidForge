package com.chaibcalligraphy.sunamishkat;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


public class AdhanStopReceiver extends BroadcastReceiver {
    public static final String ACTION_STOP_AND_EXIT =
            "com.chaibcalligraphy.sunamishkat.STOP_ADHAN_AND_EXIT";

    @Override public void onReceive(Context context, Intent intent) {
        context.stopService(new Intent(context, AdhanService.class));
        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.cancel(AdhanService.NOTIF);

        Intent finished = new Intent(AdhanService.ACTION_FINISHED)
                .setPackage(context.getPackageName());
        context.sendBroadcast(finished);
    }
}
