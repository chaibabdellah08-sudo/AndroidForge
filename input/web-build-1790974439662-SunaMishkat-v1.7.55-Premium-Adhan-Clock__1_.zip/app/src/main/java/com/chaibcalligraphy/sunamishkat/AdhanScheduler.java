package com.chaibcalligraphy.sunamishkat;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

/** Native Adhan scheduler. When the in-app manual clock is enabled, the app's
 * virtual clock advances from the saved manual time and native alarms are
 * translated back to real device wall-clock time. */
public final class AdhanScheduler {
    private static final int[] IDS = {2001,2002,2003,2004,2005};
    private static final String[] KEYS = {"fajr","dhuhr","asr","maghrib","isha"};

    public static void scheduleAll(Context c){
        cancelAll(c);
        android.content.SharedPreferences p=c.getSharedPreferences("prayer_times",Context.MODE_PRIVATE);
        Calendar virtualNow=appNow(c);
        for(int n=0;n<5;n++){
            int h=p.getInt(KEYS[n]+"_h",-1), m=p.getInt(KEYS[n]+"_m",-1);
            if(h<0||m<0) continue;
            Calendar target=(Calendar)virtualNow.clone();
            target.set(Calendar.HOUR_OF_DAY,h); target.set(Calendar.MINUTE,m); target.set(Calendar.SECOND,0); target.set(Calendar.MILLISECOND,0);
            if(target.getTimeInMillis()<=virtualNow.getTimeInMillis()) target.add(Calendar.DAY_OF_YEAR,1);
            scheduleVirtual(c,KEYS[n],h,m,target,n);
        }
    }

    public static void scheduleNext(Context c,String prayer){
        int n=index(prayer); if(n<0) return;
        android.content.SharedPreferences p=c.getSharedPreferences("prayer_times",Context.MODE_PRIVATE);
        int h=p.getInt(KEYS[n]+"_h",-1), m=p.getInt(KEYS[n]+"_m",-1); if(h<0||m<0)return;
        Calendar target=appNow(c);
        target.add(Calendar.DAY_OF_YEAR,1);
        target.set(Calendar.HOUR_OF_DAY,h); target.set(Calendar.MINUTE,m); target.set(Calendar.SECOND,0); target.set(Calendar.MILLISECOND,0);
        scheduleVirtual(c,prayer,h,m,target,n);
    }

    private static void scheduleVirtual(Context c,String prayer,int h,int m,Calendar virtualTarget,int index){
        long realNow=System.currentTimeMillis();
        Calendar virtualNow=appNow(c);
        long delta=virtualTarget.getTimeInMillis()-virtualNow.getTimeInMillis();
        if(delta<0) delta=0;
        long realAt=realNow+delta;
        Intent in=new Intent(c,AdhanReceiver.class).putExtra("prayer",prayer).putExtra("display_hour",h).putExtra("display_minute",m);
        PendingIntent pi=PendingIntent.getBroadcast(c,IDS[index],in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        setExact(am(c),realAt,pi);
    }

    /** Returns the app's advancing virtual clock. */
    public static Calendar appNow(Context c){
        android.content.SharedPreferences p=c.getSharedPreferences("settings",Context.MODE_PRIVATE);
        Calendar now=Calendar.getInstance();
        if(!p.getBoolean("manual_clock",false)) return now;
        Calendar base=(Calendar)now.clone();
        base.set(Calendar.YEAR,p.getInt("manual_year",base.get(Calendar.YEAR)));
        base.set(Calendar.MONTH,p.getInt("manual_month",base.get(Calendar.MONTH)+1)-1);
        base.set(Calendar.DAY_OF_MONTH,p.getInt("manual_day",base.get(Calendar.DAY_OF_MONTH)));
        base.set(Calendar.HOUR_OF_DAY,p.getInt("manual_hour",base.get(Calendar.HOUR_OF_DAY)));
        base.set(Calendar.MINUTE,p.getInt("manual_minute",base.get(Calendar.MINUTE)));
        base.set(Calendar.SECOND,p.getInt("manual_second",base.get(Calendar.SECOND)));
        base.set(Calendar.MILLISECOND,0);
        long setAt=p.getLong("manual_base_real",System.currentTimeMillis());
        long elapsed=Math.max(0,System.currentTimeMillis()-setAt);
        base.setTimeInMillis(base.getTimeInMillis()+elapsed);
        return base;
    }

    public static void cancelAll(Context c){
        AlarmManager am=am(c);
        for(int n=0;n<5;n++){
            PendingIntent pi=PendingIntent.getBroadcast(c,IDS[n],new Intent(c,AdhanReceiver.class),PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(pi!=null)am.cancel(pi);
        }
    }
    private static int index(String s){for(int i=0;i<KEYS.length;i++)if(KEYS[i].equals(s))return i;return -1;}
    private static AlarmManager am(Context c){return (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);}
    private static void setExact(AlarmManager am,long at,PendingIntent pi){
        try{
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){
                if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.set(AlarmManager.RTC_WAKEUP,at,pi);
            }else if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
            else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);
        }catch(SecurityException e){
            if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.set(AlarmManager.RTC_WAKEUP,at,pi);
        }
    }
    private AdhanScheduler(){}
}
