package com.chaibcalligraphy.sunamishkat;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/** Premium native adhan alert. One card for real and test adhan. */
public class AdhanAlertActivity extends Activity {
    private StopSlider slider;
    private final BroadcastReceiver finishedReceiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){finish();}};
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,float size,int color,int gravity){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(gravity);t.setIncludeFontPadding(false);return t;}
    private GradientDrawable bg(int color,float r){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(r));return d;}
    private GradientDrawable stroke(int fill,int line,float r){GradientDrawable d=bg(fill,r);d.setStroke(dp(1),line);return d;}
    private GradientDrawable grad(int a,int b,float r){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});d.setCornerRadius(dp(r));return d;}

    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}
        getWindow().setStatusBarColor(Color.rgb(4,27,23));getWindow().setNavigationBarColor(Color.rgb(2,17,15));
        buildUi(); new Handler(Looper.getMainLooper()).postDelayed(()->AdhanService.hideForAlert(),70);
        IntentFilter f=new IntentFilter(AdhanService.ACTION_FINISHED); if(Build.VERSION.SDK_INT>=33)registerReceiver(finishedReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(finishedReceiver,f);
    }

    private void buildUi(){
        final int WHITE=Color.WHITE, MUTED=Color.rgb(191,218,208), GOLD=Color.rgb(230,190,91), GREEN=Color.rgb(25,194,104);
        String prayer=getIntent().getStringExtra("prayer"), title=prayerName(prayer);
        boolean h24=getSharedPreferences("settings",0).getBoolean("clock_24",true);
        int dh=getIntent().getIntExtra("display_hour",-1),dm=getIntent().getIntExtra("display_minute",-1);
        Calendar c=Calendar.getInstance(); if(dh>=0&&dm>=0){c.set(Calendar.HOUR_OF_DAY,dh);c.set(Calendar.MINUTE,dm);} 
        String time=h24?String.format(Locale.US,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)):format12(c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE));
        String date=new SimpleDateFormat("EEEE  •  d MMMM",new Locale("ar")).format(c);

        FrameLayout root=new FrameLayout(this);root.setBackground(grad(Color.rgb(7,76,61),Color.rgb(1,22,19),34));
        Ambient bg=new Ambient(this);root.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);shell.setGravity(Gravity.CENTER_HORIZONTAL);shell.setPadding(dp(18),dp(22),dp(18),dp(18));
        FrameLayout.LayoutParams slp=new FrameLayout.LayoutParams(-1,-1);slp.gravity=Gravity.CENTER;root.addView(shell,slp);

        LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);brand.setPadding(dp(13),dp(8),dp(13),dp(8));brand.setBackground(stroke(0x14ffffff,0x35ffffff,22));
        TextView dot=text("●",10,GOLD,Gravity.CENTER);brand.addView(dot,new LinearLayout.LayoutParams(dp(18),dp(28)));
        TextView brandText=text("سُنا مِشكاة",15,WHITE,Gravity.CENTER);brandText.setTypeface(Typeface.DEFAULT_BOLD);brand.addView(brandText,new LinearLayout.LayoutParams(-2,dp(28)));
        TextView state=text("  •  حان وقت الأذان",13,MUTED,Gravity.CENTER);brand.addView(state,new LinearLayout.LayoutParams(-2,dp(28)));
        shell.addView(brand,new LinearLayout.LayoutParams(-2,dp(46)));

        Space topSpace=new Space(this);shell.addView(topSpace,new LinearLayout.LayoutParams(1,0,0.8f));
        TextView prayer=text(title,31,WHITE,Gravity.CENTER);prayer.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));shell.addView(prayer,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView dateView=text(date,13,MUTED,Gravity.CENTER);shell.addView(dateView,new LinearLayout.LayoutParams(-1,dp(28)));

        TextView clock=text(time,82,WHITE,Gravity.CENTER);clock.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));clock.setTextDirection(View.TEXT_DIRECTION_LTR);clock.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);clock.setTextLocale(Locale.US);clock.setSingleLine(true);clock.setLetterSpacing(.01f);clock.setShadowLayer(dp(18),0,dp(5),0x66000000);shell.addView(clock,new LinearLayout.LayoutParams(-1,dp(105)));
        TextView line=text("────────  ✦  ────────",11,GOLD,Gravity.CENTER);shell.addView(line,new LinearLayout.LayoutParams(-1,dp(26)));

        LinearLayout action=new LinearLayout(this);action.setGravity(Gravity.CENTER_VERTICAL);action.setPadding(dp(18),0,dp(18),0);action.setBackground(grad(Color.rgb(29,202,108),Color.rgb(7,142,75),22));
        TextView speaker=text("◖)))",18,WHITE,Gravity.CENTER);action.addView(speaker,new LinearLayout.LayoutParams(dp(50),dp(58)));
        LinearLayout actionText=new LinearLayout(this);actionText.setOrientation(LinearLayout.VERTICAL);TextView a1=text("الأذان يعمل الآن",17,WHITE,Gravity.RIGHT);a1.setTypeface(Typeface.DEFAULT_BOLD);TextView a2=text("يمكنك إيقافه بالسحب أدناه",11,0xddffffff,Gravity.RIGHT);actionText.addView(a1);actionText.addView(a2);action.addView(actionText,new LinearLayout.LayoutParams(0,dp(58),1));
        shell.addView(action,new LinearLayout.LayoutParams(-1,dp(64)));
        Space mid=new Space(this);shell.addView(mid,new LinearLayout.LayoutParams(1,0,1.0f));

        TextView hint=text("اسحب المقبض إلى اليسار لإيقاف الأذان",13,MUTED,Gravity.CENTER);shell.addView(hint,new LinearLayout.LayoutParams(-1,dp(25)));
        slider=new StopSlider(this);slider.setOnStopListener(this::stopAdhan);shell.addView(slider,new LinearLayout.LayoutParams(-1,dp(58)));
        TextView exit=text("إغلاق",14,WHITE,Gravity.CENTER);exit.setBackground(stroke(0x10ffffff,0x45ffffff,20));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(dp(112),dp(42));ep.topMargin=dp(8);shell.addView(exit,ep);exit.setOnClickListener(v->stopAdhan());
        setContentView(root);
    }
    private String format12(int h,int m){int hh=h%12;if(hh==0)hh=12;return String.format(Locale.US,"%02d:%02d %s",hh,m,h>=12?"م":"ص");}
    private String prayerName(String p){if(p==null||p.trim().isEmpty())return "الأذان";switch(p.toLowerCase(Locale.US)){case "fajr":return "الفجر";case "dhuhr":return "الظهر";case "asr":return "العصر";case "maghrib":return "المغرب";case "isha":return "العشاء";default:return p;}}
    private void stopAdhan(){try{stopService(new Intent(this,AdhanService.class));}catch(Exception ignored){}finish();}
    @Override protected void onStop(){super.onStop();if(!isFinishing())new Handler(Looper.getMainLooper()).postDelayed(()->AdhanService.showAfterAlert(),120);}
    @Override protected void onDestroy(){try{unregisterReceiver(finishedReceiver);}catch(Exception ignored){}super.onDestroy();}
    @Override public void onBackPressed(){stopAdhan();}

    private static class Ambient extends View{Paint p=new Paint(3);Ambient(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}protected void onDraw(Canvas c){float w=getWidth(),h=getHeight();p.setStyle(Paint.Style.FILL);p.setColor(0x173fe0a0);c.drawCircle(w*.5f,h*.35f,w*.42f,p);p.setColor(0x0ce5c56e);c.drawCircle(w*.5f,h*.42f,w*.25f,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(0x14ffffff);c.drawCircle(w*.5f,h*.35f,w*.34f,p);}}

    public static class StopSlider extends View{Paint p=new Paint(3);float progress=1;boolean dragging;Runnable listener;StopSlider(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}void setOnStopListener(Runnable r){listener=r;}protected void onDraw(Canvas c){float w=getWidth(),h=getHeight(),r=(h-6)/2f;p.setStyle(Paint.Style.FILL);p.setColor(0x1affffff);c.drawRoundRect(0,3,w,h-3,r,r,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(0x38ffffff);c.drawRoundRect(1,4,w-1,h-4,r,r,p);p.setStyle(Paint.Style.FILL);p.setColor(0x1fe6be5b);float fw=Math.max(0,(w-8)*progress);c.drawRoundRect(4,8,4+fw,h-8,(h-16)/2f,(h-16)/2f,p);float x=9+progress*(w-18);p.setColor(Color.WHITE);p.setShadowLayer(9,0,2,0x55000000);c.drawCircle(x,h/2f,23,p);p.clearShadowLayer();p.setColor(0xff075b47);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(20);c.drawText("‹",x,h/2f+7,p);}public boolean onTouchEvent(MotionEvent e){float w=getWidth();if(e.getAction()==0){dragging=true;u(e.getX(),w);return true;}if(e.getAction()==2&&dragging){u(e.getX(),w);return true;}if(e.getAction()==1&&dragging){u(e.getX(),w);dragging=false;if(progress<=.12f&&listener!=null)listener.run();else{progress=1;invalidate();}return true;}return true;}void u(float x,float w){progress=Math.max(0,Math.min(1,(x-9)/(w-18)));invalidate();}}
}
