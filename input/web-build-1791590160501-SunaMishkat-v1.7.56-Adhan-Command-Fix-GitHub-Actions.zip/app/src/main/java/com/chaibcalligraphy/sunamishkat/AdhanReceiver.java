package com.chaibcalligraphy.sunamishkat;
import android.content.*; import android.os.Build;
public class AdhanReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i) {
   String prayer=i.getStringExtra("prayer");
   if(prayer!=null) AdhanScheduler.scheduleNext(c,prayer);
   if(prayer==null || !AdhanScheduler.isPrayerEnabled(c,prayer)) return;
   Intent s=new Intent(c,AdhanService.class).putExtra("prayer",prayer).putExtra("display_hour",i.getIntExtra("display_hour",-1)).putExtra("display_minute",i.getIntExtra("display_minute",-1));
   if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s); else c.startService(s);
 }
}
