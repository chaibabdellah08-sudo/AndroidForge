package com.chaibcalligraphy.sunamishkat;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;




public final class AdhanScheduler {
    private static final int[] IDS = {2001,2002,2003,2004,2005};
    private static final String[] KEYS = {"fajr","dhuhr","asr","maghrib","isha"};

    public static void scheduleAll(Context c){
        cancelAll(c);
        android.content.SharedPreferences p=c.getSharedPreferences("prayer_times",Context.MODE_PRIVATE);
        Calendar virtualNow=appNow(c);
        for(int n=0;n<5;n++){
            int h=p.getInt(KEYS[n]+"_h",-1), m=p.getInt(KEYS[n]+"_m",-1);
            if(!isPrayerEnabled(c,KEYS[n]) || h<0||m<0) continue;
            Calendar target=(Calendar)virtualNow.clone();
            target.set(Calendar.HOUR_OF_DAY,h); target.set(Calendar.MINUTE,m); target.set(Calendar.SECOND,0); target.set(Calendar.MILLISECOND,0);
            if(target.getTimeInMillis()<=virtualNow.getTimeInMillis()) target.add(Calendar.DAY_OF_YEAR,1);
            scheduleVirtual(c,KEYS[n],h,m,target,n);
        }
    }

    public static void scheduleNext(Context c,String prayer){
        int n=index(prayer); if(n<0) return;
        android.content.SharedPreferences p=c.getSharedPreferences("prayer_times",Context.MODE_PRIVATE);
        int h=p.getInt(KEYS[n]+"_h",-1), m=p.getInt(KEYS[n]+"_m",-1); if(!isPrayerEnabled(c,KEYS[n]) || h<0||m<0)return;
        Calendar target=appNow(c);
        target.add(Calendar.DAY_OF_YEAR,1);
        target.set(Calendar.HOUR_OF_DAY,h); target.set(Calendar.MINUTE,m); target.set(Calendar.SECOND,0); target.set(Calendar.MILLISECOND,0);
        scheduleVirtual(c,prayer,h,m,target,n);
    }

    private static void scheduleVirtual(Context c,String prayer,int h,int m,Calendar virtualTarget,int index){
        long realNow=System.currentTimeMillis();
        Calendar virtualNow=appNow(c);
        long delta=virtualTarget.getTimeInMillis()-virtualNow.getTimeInMillis();
        if(delta<0) delta=0;
        long realAt=realNow+delta;
        Intent in=new Intent(c,AdhanReceiver.class).putExtra("prayer",prayer).putExtra("display_hour",h).putExtra("display_minute",m);
        PendingIntent pi=PendingIntent.getBroadcast(c,IDS[index],in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        setExact(am(c),realAt,pi);
    }

    
    public static boolean isPrayerEnabled(Context c,String prayer){
        android.content.SharedPreferences p=c.getSharedPreferences("adhan_remote_config",Context.MODE_PRIVATE);
        if(!p.getBoolean("enabled",true)) return false;
        return p.getBoolean(prayer+"_enabled",true);
    }

    public static Calendar appNow(Context c){
        return Calendar.getInstance();
    }

    private static AlarmManager am(Context c){
        return (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
    }

    private static int index(String prayer){
        if(prayer==null) return -1;
        for(int i=0;i<KEYS.length;i++) if(KEYS[i].equalsIgnoreCase(prayer)) return i;
        return -1;
    }

    public static void cancelAll(Context c){
        AlarmManager alarm=am(c);
        if(alarm==null) return;
        for(int i=0;i<IDS.length;i++){
            Intent in=new Intent(c,AdhanReceiver.class);
            PendingIntent pi=PendingIntent.getBroadcast(c,IDS[i],in,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(pi!=null){
                alarm.cancel(pi);
                pi.cancel();
            }
        }
    }

    private static void setExact(AlarmManager am,long at,PendingIntent pi){
        try{
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){
                if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.set(AlarmManager.RTC_WAKEUP,at,pi);
            }else if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
            else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);
        }catch(SecurityException e){
            if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.set(AlarmManager.RTC_WAKEUP,at,pi);
        }
    }
    private AdhanScheduler(){}
}
