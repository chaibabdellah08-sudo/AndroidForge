# سُنا مِشكاة — البناء عبر GitHub Actions

## إنشاء APK
1. ارفع محتويات هذا المشروع إلى مستودع GitHub جديد أو مستودع المشروع الحالي.
2. تأكد أن ملف `.github/workflows/android.yml` موجود في الفرع `main` أو `master`.
3. افتح تبويب **Actions** في GitHub.
4. اختر **Build Suna Mishkat Android App** ثم **Run workflow**، أو ادفع commit جديدًا إلى الفرع.
5. بعد نجاح التشغيل، افتح صفحة التشغيل (workflow run) وانزل إلى **Artifacts** ثم نزّل `SunaMishkat-debug-apk`.
6. فك ضغط الملف المنزّل للحصول على ملف APK.

## ملاحظات
- هذا workflow يبني نسخة **Debug APK** للاختبار، وليس إصدارًا موقّعًا جاهزًا للنشر على Google Play.
- إصدار Android الحالي في إعدادات المشروع: `versionName 1.7.47` و`versionCode 47`.
- يتطلب نشر Google Play إعداد مفتاح توقيع آمن في GitHub Secrets وبناء نسخة Release/AAB. لا تضع ملف المفتاح أو كلمات مروره داخل المستودع.
- يجب اختبار الأذان والإشعارات والجدولة على جهاز Android فعلي بعد التثبيت.
