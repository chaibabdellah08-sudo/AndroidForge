
(() => {
  const C=window.MishkatConfig||{}, API=C.api||'/wp-json/mishkat/v1/';
  const $=(s,r=document)=>r.querySelector(s);
  const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const store={get(k,d=null){try{const v=localStorage.getItem(k);return v===null?d:JSON.parse(v)}catch{return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}};
  const DIRECT='https://api.aladhan.com/v1/';
  let config={name:'سُنا مِشكاة',city:'Oran',country:'Algeria',method:3,default_reciter:'ar.alafasy',notifications:true,adhan:{enabled:true,volume:.85,fajr:'',dhuhr:'',asr:'',maghrib:'',isha:''}};
  let prayerData=null, prayerMonitor=null, adhanAudio=null, audioPrimed=false;
  let compass={bearing:null,heading:null,handler:null,active:false,offset:0,last:0};

  const I18N={
    ar:{name:'سُنا مِشكاة',tag:'رفيقك اليومي للقرآن والذكر والصلاة',start:'دخول',choose:'اختر لغة التطبيق',home:'الرئيسية',prayer:'الصلاة',quran:'القرآن',qibla:'القبلة',more:'المزيد',adhkar:'الأذكار',hadith:'الحديث',calendar:'التقويم',upcoming:'الصلاة القادمة',enableAdhan:'تفعيل الأذان',qiblaBtn:'القبلة',search:'ابحث في مِشكاة',today:'اليوم في مِشكاة',openAdhkar:'فتح الأذكار ←',readListen:'قراءة واستماع',prayerTimes:'مواقيت الصلاة',dailyTimes:'مواعيد اليوم والعدّ التنازلي',quranSub:'قراءة واستماع',adhkarSub:'أذكار وأدعية',hadithSub:'البخاري ومسلم',calendarSub:'التاريخ الهجري',moreSub:'إعدادات مِشكاة',dark:'الوضع الليلي',reader:'القارئ',adhan:'الأذان',about:'حول مِشكاة',back:'رجوع',playAdhan:'الأذان',adhanNow:'الأذان الآن',stopAdhan:'إيقاف الأذان',tasbeeh:'التسبيح',tasbeehSub:'عداد التسبيح الإلكتروني',reset:'تصفير',count:'العدد',noData:'لا يوجد محتوى منشور بعد في لوحة التحكم.',loading:'جاري التحميل…'},
    en:{name:'Suna Mishkat',tag:'Your daily companion for prayer, Quran, remembrance and hadith',start:'Enter',choose:'Choose app language',home:'Home',prayer:'Prayer',quran:'Quran',qibla:'Qibla',more:'More',adhkar:'Adhkar',hadith:'Hadith',calendar:'Calendar',upcoming:'Next prayer',enableAdhan:'Enable adhan',qiblaBtn:'Qibla',search:'Search Suna Mishkat',today:'Today in Mishkat',openAdhkar:'Open adhkar →',readListen:'Read & listen',prayerTimes:'Prayer times',dailyTimes:'Today and countdown',quranSub:'Read & listen',adhkarSub:'Adhkar & duas',hadithSub:'Bukhari & Muslim',calendarSub:'Hijri date',moreSub:'Suna Mishkat settings',dark:'Dark mode',reader:'Reciter',adhan:'Adhan',about:'About Mishkat',back:'Back',playAdhan:'Adhan',adhanNow:'Adhan now',stopAdhan:'Stop adhan',tasbeeh:'Tasbeeh',tasbeehSub:'Digital tasbeeh counter',reset:'Reset',count:'Count',noData:'No published content yet in the control panel.',loading:'Loading…'},
    fr:{name:'Mishkat Islamique',tag:'Votre compagnon quotidien pour la prière, le Coran et le dhikr',start:'Entrer',choose:'Choisissez la langue',home:'Accueil',prayer:'Prière',quran:'Coran',qibla:'Qibla',more:'Plus',adhkar:'Adhkar',hadith:'Hadith',calendar:'Calendrier',upcoming:'Prochaine prière',enableAdhan:'Activer l’adhan',qiblaBtn:'Qibla',search:'Rechercher dans Mishkat',today:'Aujourd’hui dans Mishkat',openAdhkar:'Ouvrir les adhkar →',readListen:'Lire et écouter',prayerTimes:'Horaires de prière',dailyTimes:'Horaires et compte à rebours',quranSub:'Lire et écouter',adhkarSub:'Adhkar et invocations',hadithSub:'Bukhari et Muslim',calendarSub:'Date hégirienne',moreSub:'Réglages Mishkat',dark:'Mode sombre',reader:'Récitateur',adhan:'Adhan',about:'À propos',back:'Retour',playAdhan:'Adhan',adhanNow:'Adhan maintenant',stopAdhan:'Arrêter',tasbeeh:'Tasbih',tasbeehSub:'Compteur de tasbih',reset:'Réinitialiser',count:'Compteur',noData:'Aucun contenu publié dans le panneau.',loading:'Chargement…'},
    es:{name:'Mishkat Islámico',tag:'Tu compañero diario para la oración, el Corán y el dhikr',start:'Entrar',choose:'Elige el idioma',home:'Inicio',prayer:'Oración',quran:'Corán',qibla:'Qibla',more:'Más',adhkar:'Adhkar',hadith:'Hadiz',calendar:'Calendario',upcoming:'Próxima oración',enableAdhan:'Activar adhan',qiblaBtn:'Qibla',search:'Buscar en Mishkat',today:'Hoy en Mishkat',openAdhkar:'Abrir adhkar →',readListen:'Leer y escuchar',prayerTimes:'Horarios de oración',dailyTimes:'Horarios y cuenta atrás',quranSub:'Leer y escuchar',adhkarSub:'Adhkar y súplicas',hadithSub:'Bujari y Muslim',calendarSub:'Fecha hégira',moreSub:'Ajustes de Mishkat',dark:'Modo oscuro',reader:'Recitador',adhan:'Adhan',about:'Acerca de Mishkat',back:'Atrás',playAdhan:'Adhan',adhanNow:'Adhan ahora',stopAdhan:'Detener',tasbeeh:'Tasbih',tasbeehSub:'Contador digital',reset:'Reiniciar',count:'Conteo',noData:'Aún no hay contenido publicado en el panel.',loading:'Cargando…'}
  };
  let locale=store.get('mk_locale','ar');
  const tr=(k)=>(I18N[locale]||I18N.ar)[k]||I18N.ar[k]||k;
  function normalizeReciter(v){return 'ar.alafasy'}
  function reciterLabel(r){return 'مشاري راشد العفاسي'}

  async function get(path,options={}){
    const ctrl=new AbortController(), timer=setTimeout(()=>ctrl.abort(),options.timeout||12000);
    try{const r=await fetch(API+path,{cache:'no-store',signal:ctrl.signal});if(!r.ok)throw Error('API '+r.status);return await r.json();}
    finally{clearTimeout(timer)}
  }

  function setLocale(l){
    if(!I18N[l])l='ar';
    locale=l;store.set('mk_locale',l);
    document.documentElement.lang=l;
    document.documentElement.dir=l==='ar'?'rtl':'ltr';
  }

  function showToast(msg){
    let x=$('.mk-toast-global');if(!x){x=document.createElement('div');x.className='mk-toast-global';document.body.appendChild(x)}
    x.textContent=msg;x.classList.add('show');clearTimeout(x._t);x._t=setTimeout(()=>x.classList.remove('show'),3200);
  }

  function applyTheme(){
    const dark=!!store.get('mk_dark',false);
    document.documentElement.classList.toggle('mk-dark',dark);
    document.body.classList.toggle('mk-dark',dark);
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content',dark?'#051a15':'#0a3027');
    $$('[data-theme]').forEach(b=>{
      b.classList.toggle('is-dark',dark);
      b.setAttribute('aria-pressed',dark?'true':'false');
      b.setAttribute('title',dark?'الوضع النهاري':'الوضع الليلي');
    });
  }
  function bindTheme(root=document){
    $$('[data-theme]',root).forEach(b=>b.onclick=()=>{store.set('mk_dark',!store.get('mk_dark',false));applyTheme()});
    applyTheme();
  }

  function shell(title,body){
    return `<div class="mk-top"><button class="mk-back" data-back aria-label="${esc(tr('back'))}">‹</button><div class="mk-top-title"><small>MISHKAT</small><h2>${esc(title)}</h2></div><span class="mk-top-spacer" aria-hidden="true"></span></div>${body}`;
  }

  function nav(){
    return `<nav class="mk-nav" aria-label="main navigation">
      <button data-go="home"><span>⌂</span>${esc(tr('home'))}</button>
      <button data-go="prayer"><span>🕌</span>${esc(tr('prayer'))}</button>
      <button data-go="quran"><span>📖</span>${esc(tr('quran'))}</button>
      <button data-go="adhkar"><span>🤲</span>${esc(tr('adhkar'))}</button>
      <button data-go="qibla"><span>🧭</span>${esc(tr('qibla'))}</button>
      <button data-go="more"><span>☰</span>${esc(tr('more'))}</button>
    </nav>`;
  }

  function prayerEntries(d){
    const t=d?.timings||d?.data?.timings||{};
    return [['Fajr','الفجر'],['Sunrise','الشروق'],['Dhuhr','الظهر'],['Asr','العصر'],['Maghrib','المغرب'],['Isha','العشاء']]
      .map(x=>({k:x[0],n:locale==='ar'?x[1]:({Fajr:'Fajr',Sunrise:'Sunrise',Dhuhr:'Dhuhr',Asr:'Asr',Maghrib:'Maghrib',Isha:'Isha'}[x[0]]),t:String(t[x[0]]||'').slice(0,5)}))
      .filter(x=>x.t.includes(':'));
  }
  function renderPrayer(d,target='mk-prayers'){
    syncNativePrayerTimes(d);
    const el=$('#'+target);if(!el)return;
    el.innerHTML=prayerEntries(d).map(x=>`<div class="mk-prayer"><span><b>${esc(x.n)}</b></span><b>${esc(x.t)}</b></div>`).join('');
  }
  function syncNativePrayerTimes(d){
    try{
      if(window.SunaMishkatNative && typeof window.SunaMishkatNative.setPrayerTimes==='function'){
        const t=d?.timings||d?.data?.timings||{};
        const v=['Fajr','Dhuhr','Asr','Maghrib','Isha'].map(k=>String(t[k]||'').slice(0,5));
        window.SunaMishkatNative.setPrayerTimes(v[0],v[1],v[2],v[3],v[4]);
      }
    }catch(e){}
  }

  function localDateKey(d=new Date()){return [d.getFullYear(),d.getMonth()+1,d.getDate()].join('-')}
  function nextInfo(d){
    const rows=prayerEntries(d).filter(x=>x.k!=='Sunrise'),now=new Date(),secNow=now.getHours()*3600+now.getMinutes()*60+now.getSeconds();
    for(const x of rows){const [h,m]=x.t.split(':').map(Number),s=h*3600+m*60;if(s>secNow)return {x,delta:s-secNow}}
    if(rows[0]){const [h,m]=rows[0].t.split(':').map(Number);return {x:rows[0],delta:86400-secNow+h*3600+m*60}}
    return null;
  }
  function fmt(sec){sec=Math.max(0,Math.floor(sec));return String(Math.floor(sec/3600)).padStart(2,'0')+':'+String(Math.floor(sec%3600/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0')}

  function prayerAudioUrl(key){
    const a=config.adhan||{};
    return a[String(key||'').toLowerCase()] || Object.values(a).find(v=>typeof v==='string'&&/^https?:/i.test(v)) || '';
  }
  function adhanName(key){
    const map={fajr:'الفجر',dhuhr:'الظهر',asr:'العصر',maghrib:'المغرب',isha:'العشاء'};
    return map[String(key||'').toLowerCase()] || key || 'الأذان';
  }
  function showAdhanScreen(key){
    let o=document.getElementById('mk-adhan-screen');
    if(!o){o=document.createElement('div');o.id='mk-adhan-screen';o.className='mk-adhan-screen';document.body.appendChild(o)}
    const now=new Date();
    const time=now.toLocaleTimeString(locale==='ar'?'ar-DZ':'en-GB',{hour:'2-digit',minute:'2-digit'});
    o.innerHTML=`<div class="mk-adhan-backdrop"></div><div class="mk-adhan-card"><div class="mk-adhan-top"><button id="mk-adhan-close" aria-label="close">×</button><span><img class="mk-app-logo" src="suna_mishkat_logo.png" alt="سُنا مِشكاة" /></span></div><div class="mk-mosque-art" aria-hidden="true"><div class="mk-moon-art">☾</div><div class="mk-dome"></div><div class="mk-minaret mk-minaret-a"></div><div class="mk-minaret mk-minaret-b"></div></div><div class="mk-adhan-clock">${esc(time)}</div><div class="mk-adhan-label">${esc(locale==='ar'?adhanName(key):tr('adhanNow'))}</div><div class="mk-adhan-pulse"><i></i><i></i><i></i></div><button id="mk-adhan-stop" class="mk-adhan-stop">${esc(tr('stopAdhan'))}</button></div>`;
    o.classList.add('show');
    const close=()=>o.classList.remove('show');
    $('#mk-adhan-close',o)?.addEventListener('click',()=>{stopAdhan();close()});
    $('#mk-adhan-stop',o)?.addEventListener('click',()=>{stopAdhan();close()});
    return o;
  }
  function stopAdhan(){try{if(adhanAudio){adhanAudio.pause();adhanAudio.currentTime=0}}catch{};document.getElementById('mk-adhan-screen')?.classList.remove('show')}
  async function globalPrayerCheck(){
    try{
      if(!prayerData)prayerData=await get('prayer-times');
      const n=nextInfo(prayerData);
      const now=new Date(), dateKey=localDateKey(now), seconds=now.getHours()*3600+now.getMinutes()*60+now.getSeconds();
      const rows=prayerEntries(prayerData).filter(x=>x.k!=='Sunrise');
      for(const r of rows){
        const [h,m]=r.t.split(':').map(Number),at=h*3600+m*60,stamp=dateKey+'|'+r.k;
        if(seconds>=at && seconds<at+5 && store.get('mk_adhan_stamp','')!==stamp){
          store.set('mk_adhan_stamp',stamp);
          if(config.notifications && 'Notification' in window && Notification.permission==='granted'){
            try{new Notification('سُنا مِشكاة',{body:(locale==='ar'?r.n:r.k)+' · '+r.t,tag:'mishkat-'+r.k})}catch{}
          }
        }
      }
      const ni=n;
      $$('[data-next-prayer]').forEach(x=>{if(ni)x.textContent=ni.x.n+' · '+ni.x.t});
      $$('[data-countdown]').forEach(x=>{if(ni)x.textContent=fmt(ni.delta)});
    }catch{}
  }
  function startGlobalPrayerMonitor(){
    clearInterval(prayerMonitor);globalPrayerCheck();prayerMonitor=setInterval(globalPrayerCheck,1000);
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')globalPrayerCheck()});
    window.addEventListener('pageshow',globalPrayerCheck);
  }

  function splash(root,done){
    const saved=store.get('mk_locale','ar');
    root.innerHTML=`<div class="mk-splash" role="dialog">
      <div class="mk-splash-glow"></div>
      <div class="mk-splash-logo"><img src="suna_mishkat_logo.png" alt="سُنا مِشكاة" /></div>
      <div class="mk-splash-title">سُنا مِشكاة</div>
      <div class="mk-splash-sub">${esc(I18N[saved]?.tag||I18N.ar.tag)}</div>
      <div class="mk-splash-lang-title">${esc(tr('choose'))}</div>
      <div class="mk-lang-list">${[['ar','العربية'],['en','English'],['fr','Français'],['es','Español']].map(([id,n])=>`<button data-lang="${id}" class="${id===saved?'active':''}">${n}</button>`).join('')}</div>
      <button class="mk-splash-enter">${esc(I18N[saved]?.start||I18N.ar.start)} <span>→</span></button>
    </div>`;
    $$('.mk-lang-list button',root).forEach(b=>b.onclick=()=>{setLocale(b.dataset.lang);$$('.mk-lang-list button',root).forEach(x=>x.classList.toggle('active',x===b));$('.mk-splash-sub',root).textContent=tr('tag');$('.mk-splash-enter',root).childNodes[0].textContent=tr('start')+' ';});
    $('.mk-splash-enter',root).onclick=()=>{root.innerHTML='';done();};
    setLocale(saved);applyTheme();
  }

  async function loadConfig(){
    try{const c=await get('app-config');config={...config,...c,adhan:{...config.adhan,...(c.adhan||{})}}}catch{}
    config.default_reciter='ar.alafasy';store.set('mk_reciter','ar.alafasy');
  }

  function localHijri(){
    try{
      const parts=new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura',{day:'numeric',month:'long',year:'numeric'}).formatToParts(new Date());
      const o={};parts.forEach(x=>{if(x.type!=='literal')o[x.type]=x.value});
      if(o.day&&o.month&&o.year)return {day:o.day,month:o.month,year:o.year};
    }catch(e){}
    return null;
  }
  function hijriText(h){return h&&h.day&&h.month&&h.year?`${h.day} ${h.month} ${h.year} هـ`:'';}
  async function getHijri(){
    try{
      const b=window.SunaMishkatNative;
      if(b&&b.getHijriDate){const raw=b.getHijriDate();if(raw){const h=JSON.parse(raw);if(h&&h.day&&h.year)return h;}}
    }catch(e){}
    try{const d=await get('calendar');if(d&&d.hijri)return d.hijri}catch(e){}
    try{
      const now=new Date(),dd=String(now.getDate()).padStart(2,'0'),mm=String(now.getMonth()+1).padStart(2,'0'),yy=now.getFullYear();
      const r=await fetch(`${DIRECT}gToH?date=${dd}-${mm}-${yy}`,{cache:'no-store'});
      if(r.ok){const z=await r.json(),h=z&&z.data;if(h)return {day:h.day,month:(h.month&&h.month.ar)||h.month?.en||'',year:h.year};}
    }catch(e){}
    return localHijri();
  }

  function home(el){
    el.innerHTML=`<section class="mk-home-hero">
      <div class="mk-hero-top"><div><small>MISHKAT ISLAMIC</small><h1>${esc(tr('name'))}</h1><p>${esc(tr('tag'))}</p></div><div class="mk-home-tools"><button class="mk-theme-switch" data-theme aria-label="${esc(tr('dark'))}"><span class="mk-theme-sun">☀</span><span class="mk-theme-track"><i></i></span><span class="mk-theme-moon">☾</span></button><button class="mk-gold-btn" data-go="more">☰</button></div></div>
      <div class="mk-home-next"><div class="mk-next-copy"><span>${esc(tr('upcoming'))}</span><strong data-next-prayer>—</strong><b data-countdown>--:--:--</b></div><div class="mk-moon"><img src="suna_mishkat_logo.png" alt="سُنا مِشكاة" /></div></div>
      <div class="mk-home-actions"><button id="mk-adhan-unlock">🔔 ${esc(tr('enableAdhan'))}</button><button data-go="qibla">🧭 ${esc(tr('qiblaBtn'))}</button></div>
    </section>
    <div class="mk-search"><input id="mk-search" placeholder="${esc(tr('search'))}"><button id="mk-sbtn">⌕</button></div>
    <div class="mk-feature-grid">
      <button data-go="prayer" class="mk-feature big"><span>🕌</span><strong>${esc(tr('prayerTimes'))}</strong><small>${esc(tr('dailyTimes'))}</small></button>
      <button data-go="quran" class="mk-feature"><span>📖</span><strong>${esc(tr('quran'))}</strong><small>${esc(tr('quranSub'))}</small></button>
      <button data-go="adhkar" class="mk-feature"><span>🤲</span><strong>${esc(tr('adhkar'))}</strong><small>${esc(tr('adhkarSub'))}</small></button>
      <button data-go="hadith" class="mk-feature"><span>📚</span><strong>${esc(tr('hadith'))}</strong><small>${esc(tr('hadithSub'))}</small></button>
      <button data-go="calendar" class="mk-feature"><span>🌙</span><strong>${esc(tr('calendar'))}</strong><small>${esc(tr('calendarSub'))}</small></button>
      <button data-go="more" class="mk-feature"><span>✦</span><strong>${esc(tr('more'))}</strong><small>${esc(tr('moreSub'))}</small></button>
    </div>
    <div class="mk-section-label"><span>${esc(tr('today'))}</span><small id="mk-date">${esc(tr('loading'))}</small></div>${nav()}`;
    const sb=$('#mk-sbtn',el),si=$('#mk-search',el);if(sb&&si)sb.onclick=()=>{const q=si.value.trim();if(q.length>1)location.hash='search='+encodeURIComponent(q)};
    $('#mk-adhan-unlock',el)?.addEventListener('click',()=>{config.adhan.enabled=true;try{window.SunaMishkatNative?.scheduleAdhan()}catch{};showToast(locale==='ar'?'تم تفعيل الأذان تلقائياً.':'Automatic adhan enabled.');});
    getHijri().then(h=>{const q=$('#mk-date',el);if(q&&h)q.textContent=hijriText(h);}).catch(()=>{});
    updateHomeFromPrayer(el);
    bindTheme(el);
  }
  async function updateHomeFromPrayer(el){
    try{if(!prayerData)prayerData=await get('prayer-times');renderPrayer(prayerData);globalPrayerCheck()}catch{
      try{const r=await fetch(DIRECT+'timingsByCity?city='+encodeURIComponent(config.city)+'&country='+encodeURIComponent(config.country)+'&method='+encodeURIComponent(config.method||3),{cache:'no-store'});const z=await r.json();prayerData=z.data;store.set('mk_prayer_cache',prayerData);globalPrayerCheck()}catch{prayerData=store.get('mk_prayer_cache',null);if(prayerData)globalPrayerCheck()}
    }
  }

  async function prayer(el){
    el.innerHTML=shell(tr('prayerTimes'),`<div class="mk-location">📍 <span>${esc(config.city)}، ${esc(config.country)}</span></div><div class="mk-next"><small>${esc(tr('upcoming'))}</small><strong data-next-prayer>—</strong><b data-countdown>--:--:--</b></div><div class="mk-prayers" id="mk-prayers">${esc(tr('loading'))}</div>${nav()}`);
    try{if(!prayerData)prayerData=await get('prayer-times');renderPrayer(prayerData);globalPrayerCheck();}catch{
      try{let r=await fetch(DIRECT+'timingsByCity?city='+encodeURIComponent(config.city)+'&country='+encodeURIComponent(config.country)+'&method='+encodeURIComponent(config.method||3),{cache:'no-store'});let z=await r.json();prayerData=z.data;renderPrayer(prayerData);globalPrayerCheck();}catch{$('#mk-prayers',el).innerHTML='<div class="mk-empty">تعذر تحميل المواقيت.</div>'}
    }
    bindTheme(el);
  }

  const Sfallback=(()=>{const names='الفاتحة|البقرة|آل عمران|النساء|المائدة|الأنعام|الأعراف|الأنفال|التوبة|يونس|هود|يوسف|الرعد|إبراهيم|الحجر|النحل|الإسراء|الكهف|مريم|طه|الأنبياء|الحج|المؤمنون|النور|الفرقان|الشعراء|النمل|القصص|العنكبوت|الروم|لقمان|السجدة|الأحزاب|سبأ|فاطر|يس|الصافات|ص|الزمر|غافر|فصلت|الشورى|الزخرف|الدخان|الجاثية|الأحقاف|محمد|الفتح|الحجرات|ق|الذاريات|الطور|النجم|القمر|الرحمن|الواقعة|الحديد|المجادلة|الحشر|الممتحنة|الصف|الجمعة|المنافقون|التغابن|الطلاق|التحريم|الملك|القلم|الحاقة|المعارج|نوح|الجن|المزمل|المدثر|القيامة|الإنسان|المرسلات|النبأ|النازعات|عبس|التكوير|الانفطار|المطففين|الانشقاق|البروج|الطارق|الأعلى|الغاشية|الفجر|البلد|الشمس|الليل|الضحى|الشرح|التين|العلق|القدر|البينة|الزلزلة|العاديات|القارعة|التكاثر|العصر|الهمزة|الفيل|قريش|الماعون|الكوثر|الكافرون|النصر|المسد|الإخلاص|الفلق|الناس'.split('|');return names.map((n,i)=>({number:i+1,name:n,englishName:'',numberOfAyahs:0}))})();

  async function quran(el){
    el.innerHTML=shell(tr('quran'),`<div class="mk-quran-head"><div><small>MISHKAT</small><h3>${esc(tr('readListen'))}</h3></div></div><input class="mk-input" id="mk-qsearch" placeholder="${esc(locale==='ar'?'ابحث عن سورة':'Search surah')}"><div id="mk-qbody" class="mk-list">${esc(tr('loading'))}</div>${nav()}`);
    let surahs=Sfallback;try{const d=await get('quran/surahs');if(Array.isArray(d)&&d.length)surahs=d}catch{}
    const render=list=>$('#mk-qbody',el).innerHTML=list.map(s=>`<button class="mk-listrow" data-surah="${s.number}"><span class="mk-num">${s.number}</span><span><b>${esc(s.name)}</b><small>${esc(s.englishName||'')}</small></span><i>${s.numberOfAyahs?s.numberOfAyahs+' آية':''}</i></button>`).join('');
    render(surahs);
    $('#mk-qsearch',el).oninput=e=>{const q=e.target.value.trim();render(surahs.filter(s=>s.name.includes(q)||(s.englishName||'').toLowerCase().includes(q.toLowerCase())))};
    el.addEventListener('click',e=>{const b=e.target.closest('[data-surah]');if(b)location.hash='surah='+b.dataset.surah},{once:false});
    bindTheme(el);
  }

  async function surah(el,id){
    id=parseInt(id,10);
    if(!id||id<1||id>114){location.hash='quran';return}

    el.innerHTML=shell(tr('quran'),`<div class="mk-surah-head"><button data-go="quran">‹ ${esc(locale==='ar'?'السور':'Surahs')}</button><div id="mk-sname">—</div><span>◈</span></div><div id="mk-player" class="mk-full-player"></div><div id="mk-ayahs" class="mk-ayahs">${esc(tr('loading'))}</div><div class="mk-quran-source"><a href="" target="_blank" rel="noopener"></a></div>${nav()}`);
    bindTheme(el);

    const rec=normalizeReciter(store.get('mk_reciter',config.default_reciter||'ar.alafasy'));
    const bit=128;
    const cdnAudio='https://cdn.islamic.network/quran/audio-surah/'+bit+'/'+encodeURIComponent(rec)+'/'+id+'.mp3';

    let s=null;
    try{
      s=await get('quran/surah/'+id+'?reciter='+encodeURIComponent(rec),{timeout:12000});
    }catch{}

    // Secondary official text fallback for mobile/WebView.
    if(!s){
      try{
        const r=await fetch('https://api.alquran.cloud/v1/surah/'+id+'/quran-uthmani-quran-academy',{cache:'no-store',headers:{'Accept':'application/json'}});
        if(r.ok){
          const z=await r.json(),d=z&&z.data;
          if(d&&Array.isArray(d.ayahs)) s={number:id,name:d.name||('سورة '+id),englishName:d.englishName||'',numberOfAyahs:d.numberOfAyahs||d.ayahs.length,ayahs:d.ayahs.map(a=>({numberInSurah:a.numberInSurah,text:a.text})),text_available:d.ayahs.length>0,basmalah:'',audio:{reciter:rec}};
        }
      }catch{}
    }

    if(!s){
      const local=(typeof Sfallback!=='undefined'&&Sfallback[id-1])?Sfallback[id-1]:{name:'سورة '+id};
      s={number:id,name:local.name,ayahs:[],text_available:false,audio:{reciter:rec},basmalah:''};
    }

    $('#mk-sname',el).textContent=s.name||('سورة '+id);

    // Use one complete-surah MP3. Never stitch ayah files together.
    // Al Quran Cloud exposes complete-surah audio separately from its ayah API.
    const backendAudio=(s&&s.audio&&typeof s.audio.url==='string'&&/^https?:\/\//.test(s.audio.url))?s.audio.url:'';
    const audioUrl=backendAudio||cdnAudio;
    $('#mk-player',el).innerHTML=`<div class="mk-player-title"><b>${esc(s.name||'')}</b><small>${esc(reciterLabel(rec))}</small></div><audio id="mk-full-audio" controls preload="metadata" playsinline src="${esc(audioUrl)}"></audio><div class="mk-audio-status" id="mk-audio-status">${esc(locale==='ar'?'ملف صوتي كامل للسورة':'Complete surah audio file')}</div>`;

    const a=Array.isArray(s.ayahs)?s.ayahs.filter(x=>x&&x.text):[];
    let html='';

    if(s.basmalah){
      html+=`<div class="mk-basmalah">${esc(s.basmalah)}</div>`;
    }

    if(a.length){
      html+=a.map(v=>`<article class="mk-ayah"><div class="mk-ayah-tools"><span>${esc(v.numberInSurah||'')}</span></div><p class="mk-arabic">${esc(v.text||'')}</p></article>`).join('');
    }else{
      html+='<div class="mk-empty">'+esc(locale==='ar'?'تعذر تحميل نص السورة الآن.':'The surah text is temporarily unavailable.')+'</div>';
    }

    $('#mk-ayahs',el).innerHTML=html;
    const audio=$('#mk-full-audio',el);
    if(audio){
      const status=$('#mk-audio-status',el);
      audio.addEventListener('loadedmetadata',()=>{
        if(status) status.textContent=locale==='ar'?'السورة كاملة — ملف صوتي واحد':'Complete surah — single audio file';
      });
      audio.addEventListener('error',()=>{
        if(audio.src!==cdnAudio){audio.src=cdnAudio;audio.load();return}
        showToast(locale==='ar'?'تعذر تحميل ملف السورة الكامل لهذا القارئ.':'The complete surah audio file could not be loaded.');
      });
    }

  }


  async function hadith(el){
    el.innerHTML=shell(tr('hadith'),`<div class="mk-tabs"><button class="active" data-col="">${esc(locale==='ar'?'الكل':'All')}</button><button data-col="bukhari">${esc(locale==='ar'?'البخاري':'Bukhari')}</button><button data-col="muslim">${esc(locale==='ar'?'مسلم':'Muslim')}</button></div><input class="mk-input" id="mk-hsearch" placeholder="${esc(locale==='ar'?'ابحث في الأحاديث':'Search hadith')}"><div id="mk-hbody" class="mk-hadith-list">${esc(tr('loading'))}</div>${nav()}`);
    const load=async()=>{const col=$('.mk-tabs .active',el)?.dataset.col||'',q=$('#mk-hsearch',el).value.trim();try{const d=await get('hadith?collection='+col+'&q='+encodeURIComponent(q));$('#mk-hbody',el).innerHTML=d.length?d.map(h=>`<article class="mk-hadith"><span>${h.collection==='bukhari'?'صحيح البخاري':h.collection==='muslim'?'صحيح مسلم':'حديث'}</span><h3>${esc(h.title)}</h3><div>${h.content}</div><small>${esc(h.book||'')} ${h.number?'· '+esc(h.number):''}</small></article>`).join(''):`<div class="mk-empty">${esc(tr('noData'))}</div>`}catch{$('#mk-hbody',el).innerHTML='<div class="mk-empty">تعذر الاتصال بمحتوى الحديث.</div>'}};
    $$('.mk-tabs [data-col]',el).forEach(b=>b.onclick=()=>{$$('.mk-tabs [data-col]',el).forEach(x=>x.classList.remove('active'));b.classList.add('active');load()});$('#mk-hsearch',el).oninput=()=>{clearTimeout(window.mkHT);window.mkHT=setTimeout(load,350)};await load();bindTheme(el);
  }

  const LOCAL_ADHKAR={
    morning:[
      ['آية الكرسي','اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ','مرة واحدة'],
      ['سور الإخلاص والفلق والناس','قُلْ هُوَ اللَّهُ أَحَدٌ • قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ • قُلْ أَعُوذُ بِرَبِّ النَّاسِ','3 مرات'],
      ['أصبحنا وأصبح الملك لله','أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.','مرة واحدة'],
      ['اللهم بك أصبحنا','اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ.','مرة واحدة'],
      ['رضيت بالله رباً','رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا.','3 مرات'],
      ['اللهم إني أسألك العفو والعافية','اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ.','مرة واحدة'],
      ['سيد الاستغفار','اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَٰهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ.','مرة واحدة'],
      ['حسبي الله لا إله إلا هو','حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ ۖ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ.','7 مرات'],
      ['سبحان الله وبحمده','سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.','100 مرة']
    ],
    evening:[
      ['آية الكرسي','اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ','مرة واحدة'],
      ['سور الإخلاص والفلق والناس','قُلْ هُوَ اللَّهُ أَحَدٌ • قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ • قُلْ أَعُوذُ بِرَبِّ النَّاسِ','3 مرات'],
      ['أمسينا وأمسى الملك لله','أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.','مرة واحدة'],
      ['اللهم بك أمسينا','اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ.','مرة واحدة'],
      ['رضيت بالله رباً','رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا.','3 مرات'],
      ['اللهم إني أسألك العفو والعافية','اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ.','مرة واحدة'],
      ['سيد الاستغفار','اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَٰهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ.','مرة واحدة'],
      ['سبحان الله وبحمده','سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.','100 مرة']
    ],
    prayer:[
      ['الاستغفار بعد الصلاة','أَسْتَغْفِرُ اللَّهَ، أَسْتَغْفِرُ اللَّهَ، أَسْتَغْفِرُ اللَّهَ.','3 مرات'],
      ['دعاء السلام','اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ.','مرة واحدة'],
      ['آية الكرسي','اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ...','مرة واحدة'],
      ['التسبيح والتحميد والتكبير','سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَاللَّهُ أَكْبَرُ.','33 مرة لكل منها']
    ],
    sleep:[
      ['آية الكرسي','اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ...','مرة واحدة'],
      ['الإخلاص والفلق والناس','قُلْ هُوَ اللَّهُ أَحَدٌ • قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ • قُلْ أَعُوذُ بِرَبِّ النَّاسِ، ثم النفث في الكفين ومسح الجسد.','3 مرات'],
      ['دعاء النوم','بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا.','مرة واحدة'],
      ['سبحان الله والحمد لله والله أكبر','سُبْحَانَ اللَّهِ 33، وَالْحَمْدُ لِلَّهِ 33، وَاللَّهُ أَكْبَرُ 34.','مرة واحدة']
    ],
    wake:[
      ['دعاء الاستيقاظ','الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ.','مرة واحدة'],
      ['لا إله إلا الله وحده','لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.','مرة واحدة']
    ],
    home:[
      ['دخول المنزل','بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا.','مرة واحدة عند الدخول'],
      ['الخروج من المنزل','بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ.','مرة واحدة']
    ],
    mosque:[
      ['دخول المسجد','اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ.','مرة واحدة'],
      ['الخروج من المسجد','اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ.','مرة واحدة']
    ],
    food:[
      ['قبل الطعام','بِسْمِ اللَّهِ.','مرة واحدة'],
      ['إذا نسي التسمية','بِسْمِ اللَّهِ فِي أَوَّلِهِ وَآخِرِهِ.','مرة واحدة'],
      ['بعد الطعام','الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ.','مرة واحدة']
    ],
    travel:[
      ['دعاء السفر','سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ • وَإِنَّا إِلَى رَبِّنَا لَمُنقَلِبُونَ.','مرة واحدة'],
      ['دعاء السفر','اللَّهُمَّ إِنَّا نَسْأَلُكَ فِي سَفَرِنَا هَذَا الْبِرَّ وَالتَّقْوَى، وَمِنَ الْعَمَلِ مَا تَرْضَى...','مرة واحدة']
    ],
    general:[
      ['الصلاة على النبي ﷺ','اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ.','بحسب الاستطاعة'],
      ['الاستغفار','أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ.','100 مرة'],
      ['لا حول ولا قوة إلا بالله','لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ.','بحسب الاستطاعة'],
      ['سبحان الله وبحمده','سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.','100 مرة']
    ]
  };
  const ADHKAR_CATS=[
    ['morning','🌅','أذكار الصباح'],['evening','🌙','أذكار المساء'],['prayer','🕌','أذكار بعد الصلاة'],['sleep','🌌','أذكار النوم'],['wake','☀️','أذكار الاستيقاظ'],['home','🏠','أذكار المنزل'],['mosque','🕌','أذكار المسجد'],['food','🍽️','أذكار الطعام والشراب'],['travel','🧳','أذكار السفر'],['general','📿','أذكار متنوعة']
  ];
  function renderLocalAdhkar(type){
    const rows=LOCAL_ADHKAR[type]||[];
    return rows.map(x=>`<article class="mk-textcard"><h3>${esc(x[0])}</h3><div class="mk-adhkar-ar">${esc(x[1])}</div><small class="mk-adhkar-count">${esc(x[2])}</small></article>`).join('')||`<div class="mk-empty">${esc(tr('noData'))}</div>`;
  }
  async function adhkar(el){
    el.innerHTML=shell(tr('adhkar'),`<div class="mk-tabs mk-adhkar-tabs">${ADHKAR_CATS.map((c,i)=>`<button class="${i===0?'active':''}" data-cat="${c[0]}">${c[1]} ${esc(c[2])}</button>`).join('')}<button data-type="duas">🤲 ${esc(locale==='ar'?'الأدعية':'Duas')}</button></div><div class="mk-adhkar-intro">${esc(locale==='ar'?'أذكار مفصلة مرتبة حسب الوقت والمناسبة':'Detailed adhkar arranged by time and occasion')}</div><div id="mk-abody" class="mk-adhkar">${renderLocalAdhkar('morning')}</div>${nav()}`);
    const load=async()=>{const cat=$('.mk-adhkar-tabs .active',el)?.dataset.cat;if(cat){$('#mk-abody',el).innerHTML=renderLocalAdhkar(cat);return}try{const d=await get('duas');$('#mk-abody',el).innerHTML=d.length?d.map(x=>`<article class="mk-textcard"><h3>${esc(x.title)}</h3><div>${x.content}</div></article>`).join(''):`<div class="mk-empty">${esc(tr('noData'))}</div>`}catch{$('#mk-abody',el).innerHTML='<div class="mk-empty">تعذر الاتصال بمحتوى الأدعية.</div>'}};
    $$('.mk-adhkar-tabs [data-cat]',el).forEach(b=>b.onclick=()=>{$$('.mk-adhkar-tabs [data-cat]',el).forEach(x=>x.classList.remove('active'));b.classList.add('active');load()});$('.mk-adhkar-tabs [data-type="duas"]',el)?.addEventListener('click',()=>{$$('.mk-adhkar-tabs [data-cat]',el).forEach(x=>x.classList.remove('active'));load()});await load();bindTheme(el);
  }

  function tasbeeh(el){
    const saved=Number(store.get('mk_tasbeeh_count',0))||0;
    el.innerHTML=shell(tr('tasbeeh'),`<div class="mk-tasbeeh"><div class="mk-tasbeeh-head"><span><img class="mk-app-logo" src="suna_mishkat_logo.png" alt="سُنا مِشكاة" /></span><div><small>${esc(tr('tasbeehSub'))}</small><h2>${esc(tr('tasbeeh'))}</h2></div></div><div class="mk-tasbeeh-counter"><small>${esc(tr('count'))}</small><strong id="mk-tas-count">${saved}</strong><p>${esc(locale==='ar'?'اضغط على السبحة للعد':'Tap the beads to count')}</p></div><button id="mk-tas-beads" class="mk-beads" aria-label="tasbeeh"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><b>●</b></button><div class="mk-tas-actions"><button id="mk-tas-reset">↻ ${esc(tr('reset'))}</button></div></div>${nav()}`);
    let count=saved;const out=$('#mk-tas-count',el);
    $('#mk-tas-beads',el).onclick=()=>{count++;store.set('mk_tasbeeh_count',count);out.textContent=count;el.classList.remove('mk-tap');void el.offsetWidth;el.classList.add('mk-tap')};
    $('#mk-tas-reset',el).onclick=()=>{count=0;store.set('mk_tasbeeh_count',0);out.textContent='0'};
    bindTheme(el);
  }
  async function calendar(el){
    el.innerHTML=shell(tr('calendar'),`<div class="mk-calendar"><div class="mk-bigmoon">🌙</div><div id="mk-cal">${esc(tr('loading'))}</div></div>${nav()}`);
    try{
      const h=await getHijri(), now=new Date();
      if(!h)throw new Error('Hijri unavailable');
      $('#mk-cal',el).innerHTML=`<h2>${esc(h.day)} ${esc(h.month)}</h2><p>${esc(h.year)} هـ</p><hr><p>${now.getDate()} / ${now.getMonth()+1} / ${now.getFullYear()} م</p>`;
    }catch{$('#mk-cal',el).innerHTML='<div class="mk-empty">تعذر تحميل التاريخ.</div>'}
    bindTheme(el);
  }

  function stopCompass(){if(compass.handler){window.removeEventListener('deviceorientationabsolute',compass.handler,true);window.removeEventListener('deviceorientation',compass.handler,true);compass.handler=null}try{window.SunaMishkatNative?.stopCompass()}catch{};compass.active=false}
  function norm(x){return (x%360+360)%360}
  function delta(a,b){return ((b-a+540)%360)-180}
  function smooth(a,b){if(a==null)return b;return norm(a+delta(a,b)*.22)}
  function rawHeading(e){
    if(typeof e.webkitCompassHeading==='number'&&isFinite(e.webkitCompassHeading))return norm(e.webkitCompassHeading+compass.offset);
    if(typeof e.alpha==='number'&&isFinite(e.alpha))return norm(360-e.alpha+(screen.orientation?.angle||0)+compass.offset);
    return null;
  }
  function onOrientation(e,el){
    const h=rawHeading(e);if(h==null||compass.bearing==null)return;
    compass.heading=smooth(compass.heading,h);
    const rel=norm(compass.bearing-compass.heading);
    const arrow=$('#mk-q-arrow',el),ring=$('#mk-q-ring',el),heading=$('#mk-heading',el),state=$('#mk-qmsg',el);
    if(arrow)arrow.style.transform=`translate(-50%,-100%) rotate(${rel}deg)`;
    if(ring)ring.style.transform=`rotate(${-compass.heading}deg)`;
    if(heading)heading.textContent=Math.round(compass.heading)+'°';
    const close=Math.abs(delta(0,rel));
    if(state)state.textContent=close<=4?(locale==='ar'?'أنت في اتجاه القبلة ✓': 'You are facing Qibla ✓'):(locale==='ar'?'حرّك الهاتف حتى يتجه السهم نحو الكعبة':'Rotate the phone until the arrow points to the Kaaba');
    compass.last=Date.now();
  }
  async function startCompassSensors(el){
    try{
      const bridge=window.SunaMishkatNative;
      if(bridge&&bridge.startCompass){
        bridge.startCompass();
        compass.active=true;
        $('#mk-qmsg',el).textContent=locale==='ar'?'البوصلة تعمل — حرّك الهاتف ببطء':'Compass active — move the phone slowly';
        return;
      }
      if(typeof DeviceOrientationEvent==='undefined')throw Error('unsupported');
      if(typeof DeviceOrientationEvent.requestPermission==='function'){const p=await DeviceOrientationEvent.requestPermission();if(p!=='granted')throw Error('denied');}
      const fn=e=>onOrientation(e,el);compass.handler=fn;
      window.addEventListener('deviceorientationabsolute',fn,true);
      window.addEventListener('deviceorientation',fn,true);
      compass.active=true;
    }catch(e){$('#mk-qmsg',el).textContent=locale==='ar'?'تعذر تشغيل مستشعر البوصلة على هذا الجهاز.':'The device orientation sensor could not be started.'}
  }

  window.__nativeHeading=function(h){
    if(!compass.active || !isFinite(h) || h<0)return;
    const el=document.querySelector('.mk-qibla-pro'); if(!el)return;
    const rel=norm(compass.bearing-h);
    compass.heading=h; compass.last=Date.now();
    const arrow=$('#mk-q-arrow',el),ring=$('#mk-q-ring',el),heading=$('#mk-heading',el),state=$('#mk-qmsg',el);
    if(arrow)arrow.style.transform=`translate(-50%,-100%) rotate(${rel}deg)`;
    if(ring)ring.style.transform=`rotate(${-h}deg)`;
    if(heading)heading.textContent=Math.round(h)+'°';
    const close=Math.abs(delta(0,rel));
    if(state)state.textContent=close<=4?(locale==='ar'?'أنت في اتجاه القبلة ✓':'You are facing Qibla ✓'):(locale==='ar'?'حرّك الهاتف حتى يتجه السهم نحو الكعبة':'Rotate the phone until the arrow points to the Kaaba');
  };

  async function qibla(el){
    stopCompass();
    el.innerHTML=shell(tr('qibla'),`<div class="mk-qibla-pro">
      <div class="mk-qibla-status"><span id="mk-qmsg">${locale==='ar'?'اضغط «بدء البوصلة» ثم اسمح بالموقع والحركة.':'Press Start compass and allow location & motion.'}</span><b id="mk-accuracy">اتجاه حقيقي</b></div>
      <div class="mk-compass-stage"><div class="mk-q-ring" id="mk-q-ring"><span class="mk-n">N</span><span class="mk-e">E</span><span class="mk-s">S</span><span class="mk-w">W</span></div><div class="mk-kaaba">🕋</div><div class="mk-q-center"></div><div id="mk-q-arrow"></div></div>
      <div class="mk-degree-big"><span id="mk-bearing">—</span><small>° ${locale==='ar'?'من الشمال الحقيقي':'true bearing'}</small></div>
      <div class="mk-heading-line">${locale==='ar'?'اتجاه الهاتف:':'Phone heading:'} <b id="mk-heading">—</b></div>
      <div class="mk-q-actions"><button class="mk-primary" id="mk-compass-start">${locale==='ar'?'بدء البوصلة':'Start compass'}</button><button id="mk-calibrate">${locale==='ar'?'معايرة الشمال':'Calibrate north'}</button></div>
      <p class="mk-hint">${locale==='ar'?'أمسك الهاتف أفقيًا. للمعايرة، وجّه N نحو الشمال الحقيقي ثم اضغط المعايرة.':'Hold the phone level. For calibration, point N to true north and press calibrate.'}</p>
    </div>${nav()}`);
    window.__nativeLocation=function(lat,lon){
      try{
        const r=x=>x*Math.PI/180;
        const bearing=norm(Math.atan2(Math.sin(r(39.826206-lon)),Math.cos(r(lat))*Math.tan(r(21.422487))-Math.sin(r(lat))*Math.cos(r(39.826206-lon)))*180/Math.PI);
        compass.bearing=bearing;
        $('#mk-bearing',el).textContent=bearing.toFixed(1);
        $('#mk-qmsg',el).textContent=locale==='ar'?'اتجاه القبلة محسوب من موقعك.':'Qibla bearing calculated from your location.';
        startCompassSensors(el);
      }catch(e){}
    };
    const bridge=window.SunaMishkatNative;
    if(bridge&&bridge.requestLocation)bridge.requestLocation();
    else if(navigator.geolocation){navigator.geolocation.getCurrentPosition(p=>window.__nativeLocation(p.coords.latitude,p.coords.longitude),()=>{}, {enableHighAccuracy:true,timeout:15000,maximumAge:60000});}
    $('#mk-compass-start',el).onclick=()=>{if(bridge&&bridge.requestLocation)bridge.requestLocation();startCompassSensors(el)};
      $('#mk-calibrate',el).onclick=()=>{if(bridge&&bridge.stopCompass)bridge.stopCompass();compass.offset=0;compass.heading=null;if(bridge&&bridge.startCompass)bridge.startCompass();showToast(locale==='ar'?'تمت إعادة تشغيل البوصلة.':'Compass restarted.');};
    bindTheme(el);
  }

  function more(el){
    el.innerHTML=shell(tr('more'),`<div class="mk-more-grid">
      <button id="mk-theme2"><span>◐</span><b>${esc(tr('dark'))}</b><small>${esc(locale==='ar'?'تبديل المظهر':'Appearance')}</small></button>
      <button id="mk-adhan-more"><span>🔔</span><b>${esc(tr('adhan'))}</b><small>${config.adhan?.enabled?'ON':'OFF'}</small></button><button data-go="tasbeeh"><span>📿</span><b>${esc(tr('tasbeeh'))}</b><small>${esc(tr('tasbeehSub'))}</small></button>
      <button data-go="qibla"><span>🧭</span><b>${esc(tr('qibla'))}</b><small>${esc(locale==='ar'?'قبلة حية':'Live qibla')}</small></button>
      <button data-go="calendar"><span>🌙</span><b>${esc(tr('calendar'))}</b><small>${esc(tr('calendarSub'))}</small></button>
      <button id="mk-about"><span>✦</span><b>${esc(tr('about'))}</b><small>Suna Mishkat 1.7.8</small></button>
    </div><div class="mk-more-note"><b>${esc(tr('name'))}</b><p>${esc(tr('tag'))}</p><div class="mk-developer"><strong>${esc(locale==='ar'?'المطور':'Developer')}: Abdellah Chaib</strong><a href="mailto:contact@chaibcalligraphy.com">contact@chaibcalligraphy.com</a></div></div>${nav()}`);
    $('#mk-theme2',el).onclick=()=>{store.set('mk_dark',!store.get('mk_dark',false));applyTheme()};
    $('#mk-adhan-more',el).onclick=()=>{config.adhan.enabled=!config.adhan.enabled;if(config.adhan.enabled)try{window.SunaMishkatNative?.scheduleAdhan()}catch{};more(el)};
    $('#mk-about',el).onclick=()=>showToast('Suna Mishkat 1.7.8');
    bindTheme(el);
  }

  async function searchPage(el,q){
    el.innerHTML=shell(locale==='ar'?'البحث':'Search',`<div id="mk-sresults" class="mk-search-results">${esc(tr('loading'))}</div>${nav()}`);
    try{const d=await get('search?q='+encodeURIComponent(q));$('#mk-sresults',el).innerHTML=d.length?d.map(x=>`<article class="mk-result"><small>${esc(x.kind)}</small><h3>${esc(x.title)}</h3><p>${esc(x.excerpt)}</p></article>`).join(''):'<div class="mk-empty">لا توجد نتائج.</div>'}catch{$('#mk-sresults',el).innerHTML='<div class="mk-empty">تعذر تنفيذ البحث.</div>'}
    bindTheme(el);
  }

  function route(){
    const el=document.getElementById('mishkat-app');if(!el)return;
    let h=location.hash.slice(1);
    if(h.startsWith('surah='))return surah(el,h.split('=')[1]);
    if(h.startsWith('search='))return searchPage(el,decodeURIComponent(h.slice(7)));
    if(h==='prayer')return prayer(el);
    if(h==='quran')return quran(el);
    if(h==='hadith')return hadith(el);
    if(h==='adhkar')return adhkar(el);
    if(h==='qibla')return qibla(el);
    if(h==='calendar')return calendar(el);
    if(h==='tasbeeh')return tasbeeh(el);
    if(h==='more')return more(el);
    return home(el);
  }

  document.addEventListener('click',e=>{
    const b=e.target.closest('[data-go]');if(b){e.preventDefault();location.hash=b.dataset.go;window.scrollTo(0,0)}
    if(e.target.closest('[data-back]')){e.preventDefault();history.back()}
  });

  let appUnlocked=false;
  async function boot(){
    const el=document.getElementById('mishkat-app');if(!el)return;
    setLocale(store.get('mk_locale','ar'));applyTheme();
    // AppCreator24 can reopen an HTML section with a stale hash. Clear it
    // before showing the language screen so no previous section can bypass it.
    try{if(location.hash)history.replaceState(null,document.title,location.pathname+location.search)}catch{}
    let started=false;
    const startApp=()=>{
      if(started || appUnlocked)return;
      started=true;
      appUnlocked=true;
      try{route()}catch(e){console.error('Suna Mishkat route',e);el.innerHTML='<div class="mk-empty">تعذر تشغيل التطبيق.</div>'}
      try{startGlobalPrayerMonitor()}catch{}
    };
    // The language/entry screen is mandatory. There is deliberately no
    // timeout, API callback, error fallback, preload, or hash event that
    // can open the application automatically.
    try{
      splash(el,startApp);
    }catch(e){
      console.error('Suna Mishkat startup screen',e);
      // Still require a real user click even if the animated splash fails.
      el.innerHTML='<div class="mk-splash" role="dialog" aria-modal="true"><div class="mk-splash-title">سُنا مِشكاة</div><div class="mk-splash-sub">اختر لغة التطبيق ثم اضغط دخول</div><div class="mk-lang-list"><button data-lang="ar" class="active">العربية</button><button data-lang="en">English</button><button data-lang="fr">Français</button><button data-lang="es">Español</button></div><button class="mk-splash-enter">دخول <span>→</span></button></div>';
      $$('.mk-lang-list button',el).forEach(b=>b.onclick=()=>{setLocale(b.dataset.lang);$$('.mk-lang-list button',el).forEach(x=>x.classList.toggle('active',x===b));});
      $('.mk-splash-enter',el).onclick=startApp;
    }
    // Configuration may load silently in the background, but it can never
    // unlock the application.
    Promise.resolve().then(()=>loadConfig()).catch(()=>{});
  }
  window.addEventListener('hashchange',()=>{if(appUnlocked)route();});
  boot();
})();
