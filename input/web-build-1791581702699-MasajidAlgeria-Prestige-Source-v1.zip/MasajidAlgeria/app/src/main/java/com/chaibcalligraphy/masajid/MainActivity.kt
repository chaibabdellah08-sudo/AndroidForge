package com.chaibcalligraphy.masajid

import android.app.Activity
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.provider.Settings
import android.os.Bundle
import android.os.Build
import android.os.Looper
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.util.Locale

private const val GREEN = 0xFF0B3D32.toInt()
private const val GREEN2 = 0xFF176B55.toInt()
private const val GOLD = 0xFFC7A45B.toInt()
private const val CREAM = 0xFFF7F4EC.toInt()
private const val INK = 0xFF1F302B.toInt()
private const val MUTED = 0xFF69766F.toInt()
private const val LOCATION_REQUEST_CODE = 4107

class MainActivity : Activity() {
    private lateinit var body: LinearLayout
    private lateinit var search: EditText
    private var activeTab = "الرئيسية"
    private var locationManager: LocationManager? = null
    private var locationListener: LocationListener? = null
    private var nearbyLoading = false
    private val mosques = listOf(
        Mosque("مسجد عبد الحميد بن باديس", "وهران · الجزائر", "جامع كبير", "36.7111, -0.6325"),
        Mosque("المسجد الكبير", "الجزائر العاصمة · الجزائر", "مسجد تاريخي", "36.7850, 3.0600"),
        Mosque("مسجد الأمير عبد القادر", "قسنطينة · الجزائر", "معلم إسلامي", "36.3650, 6.6147"),
        Mosque("مسجد الاستقلال", "وهران · الجزائر", "مسجد الحي", "36.7200, -0.6400"),
        Mosque("مسجد النور", "تلمسان · الجزائر", "مسجد محلي", "34.8828, -1.3167")
    )

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_REQUEST_CODE) {
            val granted = grantResults.any { it == PackageManager.PERMISSION_GRANTED }
            if (granted) loadNearbyMosques() else showPermissionDenied()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = GREEN
        window.navigationBarColor = GREEN
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(CREAM) }
        val scroll = ScrollView(this).apply { setFillViewport(true) }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(24)) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomNav(), LinearLayout.LayoutParams(-1, dp(66)))
        setContentView(root)
        renderHome()
    }

    private data class Mosque(val name: String, val area: String, val tag: String, val coords: String)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun text(value: String, size: Float, color: Int = INK, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); gravity = Gravity.RIGHT
        if (bold) setTypeface(typeface, Typeface.BOLD)
        textDirection = View.TEXT_DIRECTION_RTL
    }
    private fun label(value: String, size: Float = 14f, color: Int = MUTED, bold: Boolean = false): TextView = text(value, size, color, bold)
    private fun appButton(value: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = value; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD); setPadding(dp(18), dp(12), dp(18), dp(12))
        background = rounded(GREEN2, 14); isClickable = true; isFocusable = true
        setOnClickListener { onClick() }
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun sectionTitle(title: String, action: String = "") {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val t = text(title, 18f, GREEN, true).apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }
        row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        if (action.isNotEmpty()) row.addView(text(action, 12f, GREEN2, true))
        body.addView(row); body.addView(space(10))
    }

    private fun renderHome(query: String = "") {
        body.removeAllViews()
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(22)); background = rounded(GREEN, 24)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.masajid_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(0xFF164D40.toInt(), 16)
            clipToOutline = true
            contentDescription = "شعار مساجد الجزائر"
        }
        top.addView(logo, LinearLayout.LayoutParams(dp(64), dp(64)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT; setPadding(dp(12), 0, 0, 0) }
        brand.addView(text("مساجد الجزائر", 22f, Color.WHITE, true))
        brand.addView(text("دليلك إلى بيوت الله", 13f, 0xFFDCE9DF.toInt()))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f)); hero.addView(top)
        hero.addView(space(20))
        hero.addView(text("أقرب إلى بيوت الله", 23f, Color.WHITE, true))
        hero.addView(space(5))
        hero.addView(text("اكتشف المساجد، تابع الدروس، وشارك في خدمة مجتمعك.", 14f, 0xFFE4EEE8.toInt()))
        hero.addView(space(18))
        search = EditText(this).apply {
            hint = "ابحث عن مسجد أو مدينة..."; textSize = 14f; setSingleLine(true); setTextColor(INK); setHintTextColor(MUTED)
            setPadding(dp(14), 0, dp(14), 0); background = rounded(Color.WHITE, 14)
        }
        hero.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        body.addView(hero)
        search.setText(query)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { if (activeTab == "الرئيسية") showMosques(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        body.addView(space(22))
        sectionTitle("ماذا تحتاج اليوم؟")
        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tiles.addView(actionTile("⌖", "المساجد القريبة", "اكتشف حولك"), LinearLayout.LayoutParams(0, dp(112), 1f))
        val gap = View(this); tiles.addView(gap, LinearLayout.LayoutParams(dp(10), 1))
        tiles.addView(actionTile("◈", "بطاقتي", "رقمك الموحّد"), LinearLayout.LayoutParams(0, dp(112), 1f))
        body.addView(tiles); body.addView(space(10))
        val tiles2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tiles2.addView(actionTile("◉", "الدروس والأنشطة", "تابع مسجدك"), LinearLayout.LayoutParams(0, dp(105), 1f))
        tiles2.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        tiles2.addView(actionTile("＋", "أضف مسجدًا", "ساهم في الدليل"), LinearLayout.LayoutParams(0, dp(105), 1f))
        body.addView(tiles2); body.addView(space(24))
        sectionTitle("مساجد من قاعدة العرض التجريبية", "عرض الكل")
        val note = text("هذه سجلات نموذجية لا تمثل قاعدة البيانات الكاملة بعد.", 12f, MUTED)
        note.setPadding(0, 0, 0, dp(10)); body.addView(note)
        showMosques(query)
    }

    private fun actionTile(icon: String, title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT; setPadding(dp(14), dp(14), dp(14), dp(12)); background = rounded(Color.WHITE, 18, 0xFFE4E6DC.toInt())
        isClickable = true; isFocusable = true
        addView(text(icon, 22f, GOLD, true)); addView(space(6)); addView(text(title, 15f, GREEN, true)); addView(space(3)); addView(text(subtitle, 12f, MUTED))
        setOnClickListener {
            when (title) {
                "المساجد القريبة" -> showNearbyPage()
                "بطاقتي" -> { activeTab = "البطاقات"; showSimplePage("بطاقاتي", "سيتم هنا طلب بطاقة المسلم أو المصلّي أو المتطوع أو فاعل الخير، بعد ربط نظام الحسابات والموافقات."); recreateBottomNav() }
                "الدروس والأنشطة" -> { activeTab = "المزيد"; showSimplePage("الدروس والأنشطة", "ستظهر هنا دروس المساجد وإعلاناتها ودعوات التطوع بعد ربط نظام الإشعارات."); recreateBottomNav() }
                "أضف مسجدًا" -> { activeTab = "المزيد"; showSimplePage("إضافة مسجد", "سيتيح هذا القسم إرسال اسم المسجد وموقعه وصوره إلى أقرب إمام معتمد للمراجعة."); recreateBottomNav() }
            }
        }
    }

    private fun showNearbyPage() {
        activeTab = "الخريطة"
        body.removeAllViews()
        body.addView(space(8))
        body.addView(text("المساجد القريبة منك", 24f, GREEN, true))
        body.addView(space(8))
        body.addView(text("اسمح للتطبيق باستخدام موقعك لترتيب المساجد التجريبية حسب المسافة. موقعك لا يُرسل إلى الموقع.", 14f, MUTED))
        body.addView(space(18))
        body.addView(appButton("⌖  تحديد موقعي وعرض الأقرب", ::loadNearbyMosques), LinearLayout.LayoutParams(-1, -2))
        body.addView(space(12))
        body.addView(appButton("عرض المساجد التجريبية دون GPS", ::showAllSampleMosques), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        body.addView(space(10))
        body.addView(text("تنبيه: ترتيب المساجد حسب القرب يعتمد حاليًا على بيانات تجريبية محدودة، وسيُربط لاحقًا بدليل موثوق واسع للمساجد.", 12f, MUTED))
        body.addView(space(18))
        val hint = text("ملاحظة: قاعدة البيانات الحالية تجريبية فقط. سيتم استيراد قاعدة المساجد الفعلية لاحقًا.", 12f, MUTED)
        body.addView(hint)
        recreateBottomNav()
    }

    private fun hasLocationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadNearbyMosques() {
        if (!hasLocationPermission()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), LOCATION_REQUEST_CODE)
            }
            return
        }
        body.removeAllViews()
        body.addView(space(16))
        body.addView(text("نبحث عن موقعك…", 22f, GREEN, true))
        body.addView(space(8))
        body.addView(text("تأكد من تفعيل الموقع GPS في الهاتف. إذا سبق أن سمحت للتطبيق بالموقع، فانتظر لحظات للحصول على الإحداثيات.", 14f, MUTED))
        body.addView(space(16))
        body.addView(appButton("إعادة المحاولة", ::loadNearbyMosques), LinearLayout.LayoutParams(-1, -2))
        nearbyLoading = true
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            locationManager = lm
            val fineGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            // Approximate-location users can still use the network provider without fine GPS permission.
            val providers = if (fineGranted) {
                listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            } else {
                listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            }
            val lastKnown = providers.filter { provider -> try { lm.isProviderEnabled(provider) } catch (_: Exception) { false } }
                .mapNotNull { provider -> try { lm.getLastKnownLocation(provider) } catch (_: SecurityException) { null } }
                .maxByOrNull { it.time }
            if (lastKnown != null) renderNearbyResults(lastKnown)

            val provider = when {
                fineGranted && (try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (_: Exception) { false }) -> LocationManager.GPS_PROVIDER
                try { lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) } catch (_: Exception) { false } -> LocationManager.NETWORK_PROVIDER
                else -> null
            }
            if (provider == null) {
                if (lastKnown == null) showLocationOffMessage()
                return
            }
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    try { locationManager?.removeUpdates(this) } catch (_: Exception) {}
                    locationListener = null
                    nearbyLoading = false
                    renderNearbyResults(location)
                }
                @Deprecated("Deprecated by Android")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            locationListener?.let { try { lm.removeUpdates(it) } catch (_: Exception) {} }
            locationListener = listener
            @Suppress("DEPRECATION")
            lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
            if (lastKnown == null) {
                body.addView(space(12))
                body.addView(text("قد يستغرق تحديد الموقع عدة ثوانٍ. أبقِ هذه الشاشة مفتوحة.", 12f, MUTED))
            }
        } catch (_: SecurityException) {
            nearbyLoading = false
            showPermissionDenied()
        } catch (e: Exception) {
            nearbyLoading = false
            body.addView(space(12))
            body.addView(text("تعذر تحديد الموقع. فعّل GPS ثم اضغط إعادة المحاولة.", 14f, MUTED))
            body.addView(space(10))
            body.addView(appButton("فتح إعدادات الموقع", { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }), LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun showLocationOffMessage() {
        body.removeAllViews()
        body.addView(space(20))
        body.addView(text("الموقع غير مفعّل", 22f, GREEN, true))
        body.addView(space(8))
        body.addView(text("فعّل خدمة الموقع في الهاتف ثم أعد المحاولة، أو اعرض القائمة التجريبية دون استخدام GPS.", 14f, MUTED))
        body.addView(space(14))
        body.addView(appButton("فتح إعدادات الموقع", { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }), LinearLayout.LayoutParams(-1, -2))
        body.addView(space(8))
        body.addView(appButton("عرض القائمة التجريبية", ::showAllSampleMosques), LinearLayout.LayoutParams(-1, -2))
    }

    private fun showPermissionDenied() {
        body.removeAllViews()
        body.addView(space(20))
        body.addView(text("إذن الموقع مطلوب", 22f, GREEN, true))
        body.addView(space(8))
        body.addView(text("حتى نرتب المساجد حسب قربها، اسمح للتطبيق باستخدام موقعك أثناء استخدامه. يمكنك أيضًا متابعة القائمة التجريبية دون GPS.", 14f, MUTED))
        body.addView(space(14))
        body.addView(appButton("طلب إذن الموقع", ::loadNearbyMosques), LinearLayout.LayoutParams(-1, -2))
        body.addView(space(8))
        body.addView(appButton("عرض القائمة التجريبية", ::showAllSampleMosques), LinearLayout.LayoutParams(-1, -2))
    }

    private fun showAllSampleMosques() {
        activeTab = "الخريطة"
        body.removeAllViews()
        body.addView(text("قائمة المساجد التجريبية", 23f, GREEN, true))
        body.addView(space(8))
        body.addView(text("هذه بيانات مثال للتجربة وليست قاعدة مساجد الجزائر الكاملة.", 13f, MUTED))
        body.addView(space(14))
        mosques.forEach { m ->
            val card = mosqueCard(m, null)
            body.addView(card); body.addView(space(10))
        }
        body.addView(appButton("تحديد موقعي وترتيب الأقرب", ::loadNearbyMosques), LinearLayout.LayoutParams(-1, -2))
        recreateBottomNav()
    }

    private fun renderNearbyResults(location: Location) {
        activeTab = "الخريطة"
        body.removeAllViews()
        body.addView(text("المساجد الأقرب إليك", 24f, GREEN, true))
        body.addView(space(6))
        body.addView(text("تم ترتيب النتائج حسب المسافة من موقعك الحالي.", 13f, MUTED))
        body.addView(space(12))
        val sorted = mosques.mapNotNull { m ->
            val coords = parseCoordinates(m.coords) ?: return@mapNotNull null
            val target = Location("mosque").apply { latitude = coords.first; longitude = coords.second }
            m to (location.distanceTo(target).toDouble() / 1000.0)
        }.sortedBy { it.second }
        if (sorted.isEmpty()) {
            body.addView(text("لا توجد إحداثيات صالحة في البيانات التجريبية.", 14f, MUTED))
        } else {
            body.addView(text("موقعك: ${String.format(Locale.US, "%.4f", location.latitude)}, ${String.format(Locale.US, "%.4f", location.longitude)}", 11f, MUTED))
            body.addView(space(10))
            sorted.forEach { (m, km) -> body.addView(mosqueCard(m, km)); body.addView(space(10)) }
        }
        body.addView(space(8))
        body.addView(appButton("تحديث الموقع", ::loadNearbyMosques), LinearLayout.LayoutParams(-1, -2))
        body.addView(space(8))
        body.addView(appButton("العودة للرئيسية", { activeTab = "الرئيسية"; renderHome(); recreateBottomNav() }), LinearLayout.LayoutParams(-1, -2))
        recreateBottomNav()
    }

    private fun parseCoordinates(coords: String): Pair<Double, Double>? {
        val parts = coords.split(",")
        if (parts.size != 2) return null
        val lat = parts[0].trim().toDoubleOrNull() ?: return null
        val lon = parts[1].trim().toDoubleOrNull() ?: return null
        if (lat !in -90.0..90.0 || lon !in -180.0..180.0) return null
        return lat to lon
    }

    private fun mosqueCard(m: Mosque, distanceKm: Double?): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(Color.WHITE, 18, 0xFFE7E6DE.toInt())
            isClickable = true; isFocusable = true
        }
        val badge = TextView(this).apply { text = "۞"; textSize = 25f; setTextColor(GOLD); gravity = Gravity.CENTER; background = rounded(0xFFF0E8D5.toInt(), 14) }
        card.addView(badge, LinearLayout.LayoutParams(dp(54), dp(58)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT; setPadding(dp(12), 0, 0, 0) }
        info.addView(text(m.name, 15f, GREEN, true)); info.addView(space(4)); info.addView(text(m.area, 12f, MUTED)); info.addView(space(7))
        val caption = if (distanceKm == null) m.tag else "${formatDistance(distanceKm)} · ${m.tag}"
        val tagView = TextView(this).apply { text = caption; textSize = 10f; setTextColor(GREEN2); setPadding(dp(8), dp(4), dp(8), dp(4)); background = rounded(0xFFE4F0E8.toInt(), 8); gravity = Gravity.RIGHT }
        info.addView(tagView)
        card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener { showMosqueDetails(m) }
        return card
    }

    private fun formatDistance(km: Double): String = if (km < 1.0) {
        "${(km * 1000).toInt()} متر"
    } else {
        "${String.format(Locale.getDefault(), "%.1f", km)} كم"
    }

    private fun showMosques(query: String) {
        val old = body.findViewWithTag<LinearLayout>("mosque_list")
        if (old != null) body.removeView(old)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "mosque_list" }
        val filtered = mosques.filter { (it.name + it.area + it.tag).contains(query.trim(), ignoreCase = true) }
        if (filtered.isEmpty()) list.addView(text("لا توجد نتائج في البيانات التجريبية.", 14f, MUTED).apply { setPadding(0, dp(10), 0, dp(10)) })
        filtered.forEach { m ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(Color.WHITE, 18, 0xFFE7E6DE.toInt()) }
            val badge = TextView(this).apply { text = "۞"; textSize = 25f; setTextColor(GOLD); gravity = Gravity.CENTER; background = rounded(0xFFF0E8D5.toInt(), 14) }
            card.addView(badge, LinearLayout.LayoutParams(dp(54), dp(58)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT; setPadding(dp(12), 0, 0, 0) }
            info.addView(text(m.name, 15f, GREEN, true)); info.addView(space(4)); info.addView(text(m.area, 12f, MUTED)); info.addView(space(7))
            val tag = TextView(this).apply { text = m.tag; textSize = 10f; setTextColor(GREEN2); setPadding(dp(8), dp(4), dp(8), dp(4)); background = rounded(0xFFE4F0E8.toInt(), 8); gravity = Gravity.RIGHT }
            info.addView(tag)
            card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            card.setOnClickListener { showMosqueDetails(m) }
            list.addView(card); list.addView(space(10))
        }
        body.addView(list)
    }

    private fun showMosqueDetails(m: Mosque) {
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle(m.name)
            .setMessage("${m.area}\n${m.tag}\n\nالإحداثيات الحالية في النسخة التجريبية: ${m.coords}\n\nهذه بيانات اختبار وليست معلومات نهائية معتمدة.")
            .setPositiveButton("الاتجاهات", null)
            .setNegativeButton("إغلاق", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val coords = parseCoordinates(m.coords)
                if (coords == null) {
                    Toast.makeText(this, "إحداثيات المسجد غير متاحة", Toast.LENGTH_SHORT).show()
                } else {
                    val uri = Uri.parse("google.navigation:q=${coords.first},${coords.second}")
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    catch (_: Exception) {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${coords.first},${coords.second}?q=${coords.first},${coords.second}(${Uri.encode(m.name)})")))
                    }
                }
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    override fun onDestroy() {
        locationListener?.let { listener -> try { locationManager?.removeUpdates(listener) } catch (_: Exception) {} }
        locationListener = null
        super.onDestroy()
    }

    private fun bottomNav(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE); elevation = dp(10).toFloat()
        listOf("الرئيسية" to "⌂", "الخريطة" to "⌖", "البطاقات" to "▤", "المزيد" to "⋯").forEach { (title, icon) ->
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(5)) }
            col.addView(TextView(this@MainActivity).apply { text = icon; textSize = 21f; gravity = Gravity.CENTER; setTextColor(if (activeTab == title) GREEN2 else MUTED) })
            col.addView(TextView(this@MainActivity).apply { text = title; textSize = 10f; gravity = Gravity.CENTER; setTextColor(if (activeTab == title) GREEN2 else MUTED); if (activeTab == title) setTypeface(typeface, Typeface.BOLD) })
            col.setOnClickListener { activeTab = title; when (title) {
                "الرئيسية" -> renderHome()
                "الخريطة" -> showNearbyPage()
                "البطاقات" -> showSimplePage("بطاقاتي", "سيتم هنا طلب بطاقة المسلم أو المصلّي أو المتطوع أو فاعل الخير، بعد ربط نظام الحسابات والموافقات.")
                else -> showSimplePage("المزيد", "الإعدادات · اللغة · الخصوصية · عن التطبيق")
            }; recreateBottomNav() }
            addView(col, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }
    private fun recreateBottomNav() {
        val root = findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as? LinearLayout ?: return
        val old = root.getChildAt(root.childCount - 1); root.removeView(old); root.addView(bottomNav(), LinearLayout.LayoutParams(-1, dp(66)))
    }
    private fun showSimplePage(title: String, description: String) {
        body.removeAllViews()
        body.addView(space(30))
        body.addView(text("۞", 46f, GOLD, true).apply { gravity = Gravity.CENTER })
        body.addView(space(12))
        body.addView(text(title, 25f, GREEN, true).apply { gravity = Gravity.CENTER })
        body.addView(space(12))
        body.addView(text(description, 16f, MUTED).apply { gravity = Gravity.CENTER; setPadding(dp(18), 0, dp(18), 0) })
        body.addView(space(22))
        body.addView(text("هذه شاشة أولية ضمن النسخة التجريبية، وستُفعّل الوظائف عند تنفيذ المرحلة الخاصة بها.", 13f, MUTED).apply { gravity = Gravity.CENTER })
    }
}
