# مساجد الجزائر — النسخة الأولية

مشروع Android أولي بهوية خضراء زمردية وذهبية، وواجهة عربية RTL، وبحث محلي تجريبي في مجموعة صغيرة من السجلات النموذجية.

## الحالة الحالية
- واجهة رئيسية مبدئية بتصميم فاخر.
- بحث محلي في سجلات تجريبية داخل التطبيق.
- شاشات أولية للخريطة والبطاقات والمزيد.
- لا تتطلب الواجهة اتصالًا بخادم لإجراء البحث التجريبي.

## ما لم يُنفّذ بعد
- لم تُستورد قاعدة GeoAlgeria الكاملة ولم تُراجع تراخيص البيانات النهائية.
- الخريطة التفاعلية وGPS غير موصولين بعد.
- لا توجد حسابات أو رقم عالمي أو إصدار بطاقات حقيقي حتى الآن.
- لا توجد موافقات أئمة أو إشعارات دفع أو لوحة WordPress مرتبطة بعد.

## البناء
يمكن رفع ZIP إلى سير عمل AndroidForge الخاص بك لبناء APK. المشروع يستخدم Android Gradle Plugin 8.7.3 وKotlin 2.0.21، compileSdk 35، minSdk 24.

## تنبيه البيانات
الأسماء والإحداثيات الموجودة في هذه النسخة أمثلة توضيحية فقط، ولا تمثل قاعدة بيانات مكتملة أو مُتحققًا منها. يجب استيراد البيانات الفعلية ومراجعتها وترخيصها قبل النشر.


## Prestige v1 update
- Added the Masajid Algeria visual identity logo to the home header.
- Preserved the nearby-mosque location permission flow and sample fallback list.
- Nearby sorting still uses only the small demo list; this is not yet a complete verified mosque directory.
