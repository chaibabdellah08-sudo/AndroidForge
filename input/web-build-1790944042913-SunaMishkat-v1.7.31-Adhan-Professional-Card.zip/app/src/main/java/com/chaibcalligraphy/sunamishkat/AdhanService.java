package com.chaibcalligraphy.sunamishkat;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;

public class AdhanService extends Service {
    static final int NOTIF=1441;
    public static final String ACTION_FINISHED="com.chaibcalligraphy.sunamishkat.ADHAN_FINISHED";
    private MediaPlayer player;
    private boolean finished=false;
    private boolean started=false;
    private String currentPrayer="";

    @Override public void onCreate(){
        super.onCreate();
        String ch="suna_adhan";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel nc=new NotificationChannel(ch,"الأذان",NotificationManager.IMPORTANCE_HIGH);
            nc.setDescription("تنبيه الأذان وتشغيله في وقت الصلاة");
            nc.setSound(null,null);
            nc.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(nc);
        }
        startForeground(NOTIF,buildNotification(ch));
    }

    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null && i.hasExtra("prayer")) currentPrayer=i.getStringExtra("prayer");
        if(!started){
            started=true;
            String ch="suna_adhan";
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF,buildNotification(ch));
            startPlayer();
        } else {
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF,buildNotification(chName()));
        }
        return START_NOT_STICKY;
    }

    private String chName(){return "suna_adhan";}

    private Notification buildNotification(String ch){
        Intent open=new Intent(this,AdhanAlertActivity.class).putExtra("prayer",currentPrayer);
        PendingIntent full=PendingIntent.getActivity(this,1442,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop=new Intent(this,AdhanStopReceiver.class);
        PendingIntent stopPi=PendingIntent.getBroadcast(this,1443,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ch):new Notification.Builder(this);
        b.setContentTitle("سُنا مِشكاة • حان وقت الأذان")
         .setContentText(prayerName(currentPrayer))
         .setSmallIcon(com.chaibcalligraphy.sunamishkat.R.drawable.ic_stat_adhan)
         .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX)
         .setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true)
         .setContentIntent(full).setFullScreenIntent(full,true)
         .addAction(new Notification.Action.Builder(null,"إيقاف الأذان",stopPi).build());
        return b.build();
    }

    private void startPlayer(){
        player=new MediaPlayer();
        try{
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(AppConfig.ADHAN_URL);
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(p->finishAdhan());
            player.prepareAsync();
        }catch(Exception e){finishAdhan();}
    }

    private String prayerName(String p){
        if(p==null||p.trim().isEmpty())return "الأذان";
        switch(p.toLowerCase()){
            case "fajr":return "أذان الفجر";
            case "dhuhr":return "أذان الظهر";
            case "asr":return "أذان العصر";
            case "maghrib":return "أذان المغرب";
            case "isha":return "أذان العشاء";
            default:return p;
        }
    }

    private void finishAdhan(){
        if(finished)return; finished=true;
        try{sendBroadcast(new Intent(ACTION_FINISHED).setPackage(getPackageName()));}catch(Exception ignored){}
        stopForeground(true); stopSelf();
    }

    @Override public android.os.IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){
        if(player!=null){try{player.release();}catch(Exception ignored){}}
        super.onDestroy();
    }
}
