package com.chaibcalligraphy.sunamishkat;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(10,48,39));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(245,247,242));
        if(Build.VERSION.SDK_INT>=23) getWindow().getDecorView().setSystemUiVisibility(0);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},71);
        }
        buildWebView(state);
        if(!getSharedPreferences("native_boot",0).getBoolean("initialized",false)){
            getSharedPreferences("native_boot",0).edit().putBoolean("initialized",true).apply();
        }
    }

    private void buildWebView(Bundle state){
        web=new WebView(this);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new NativeBridge(this),"SunaMishkatNative");
        setContentView(web);
        if(state==null) web.loadUrl("file:///android_asset/index.html");
        else web.loadUrl("file:///android_asset/index.html");
    }

    public static final class NativeBridge {
        private final Context context;
        NativeBridge(Context c){context=c.getApplicationContext();}

        @JavascriptInterface public void setPrayerTimes(String fajr,String dhuhr,String asr,String maghrib,String isha){
            String[] keys={"fajr","dhuhr","asr","maghrib","isha"};
            String[] vals={fajr,dhuhr,asr,maghrib,isha};
            android.content.SharedPreferences.Editor e=context.getSharedPreferences("prayer_times",0).edit();
            for(int i=0;i<keys.length;i++){
                String v=vals[i]==null?"":vals[i].trim();
                if(v.matches("\\d{1,2}:\\d{2}")){
                    String[] p=v.split(":");
                    e.putInt(keys[i]+"_h",Integer.parseInt(p[0]));
                    e.putInt(keys[i]+"_m",Integer.parseInt(p[1]));
                }
            }
            e.apply();
            AdhanScheduler.scheduleAll(context);
        }

        @JavascriptInterface public void scheduleAdhan(){ AdhanScheduler.scheduleAll(context); }
        @JavascriptInterface public void testAdhan(){ AdhanScheduler.scheduleTest(context,1000); }
        @JavascriptInterface public void testAdhanAfter(long delayMs){ AdhanScheduler.scheduleTest(context,Math.max(0,delayMs)); }
        @JavascriptInterface public void stopAdhan(){ context.stopService(new Intent(context,AdhanService.class)); }
        @JavascriptInterface public void openExactAlarmSettings(){
            if(Build.VERSION.SDK_INT>=31){
                try{ context.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+context.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }catch(Exception ignored){}
            }
        }
        @JavascriptInterface public boolean exactAlarmAllowed(){
            if(Build.VERSION.SDK_INT<31) return true;
            android.app.AlarmManager am=(android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            return am!=null && am.canScheduleExactAlarms();
        }
    }

    @Override public void onBackPressed(){
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
