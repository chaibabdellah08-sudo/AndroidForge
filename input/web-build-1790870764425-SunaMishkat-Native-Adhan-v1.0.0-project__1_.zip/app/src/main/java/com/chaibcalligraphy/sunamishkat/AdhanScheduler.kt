package com.chaibcalligraphy.sunamishkat

import android.app.*
import android.content.*
import android.os.Build
import java.util.*

object AdhanScheduler {
    const val ACTION_ADHAN = "com.chaibcalligraphy.sunamishkat.ACTION_ADHAN"

    fun scheduleTest(context: Context) {
        val am = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, AdhanReceiver::class.java).apply {
            action = ACTION_ADHAN
            putExtra("prayer", "اختبار الأذان")
        }
        val pi = PendingIntent.getBroadcast(
            context, 9001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val at = System.currentTimeMillis() + 10_000L
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            return
        }
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    fun schedulePrayer(context: Context, requestCode: Int, prayer: String, millis: Long) {
        val am = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, AdhanReceiver::class.java).apply {
            action = ACTION_ADHAN
            putExtra("prayer", prayer)
        }
        val pi = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) return
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
    }
}
