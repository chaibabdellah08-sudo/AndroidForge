package com.chaibcalligraphy.sunamishkat

import android.content.*

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            // Prayer times will be scheduled here after the WordPress prayer-time
            // sync layer is connected. The native alarm engine is already ready.
        }
    }
}
