package com.chaibcalligraphy.sunamishkat

import android.content.*

class AdhanReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prayer = intent.getStringExtra("prayer") ?: "الأذان"
        val service = Intent(context, AdhanService::class.java).apply {
            putExtra("prayer", prayer)
        }
        context.startForegroundService(service)
    }
}
