package com.chaibcalligraphy.sunamishkat

import android.Manifest
import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings
import android.net.Uri
import android.widget.*
import java.util.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(0xFF0B2D26.toInt())
        }
        val title = TextView(this).apply {
            text = "🕌 سُنا مِشكاة"
            textSize = 28f
            setTextColor(0xFFE3C26B.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "منبّه الأذان الأصلي لنظام Android"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 8, 0, 30)
        }
        status = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFD6E8E1.toInt())
            setPadding(0, 10, 0, 20)
        }
        root.addView(title); root.addView(subtitle); root.addView(status)

        val exact = Button(this).apply {
            text = "⚙️ السماح بالمنبهات الدقيقة"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 31) {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        val notification = Button(this).apply {
            text = "🔔 السماح بالإشعارات"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 33)
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
            }
        }
        val test = Button(this).apply {
            text = "🔊 اختبار الأذان بعد 10 ثوانٍ"
            setOnClickListener { AdhanScheduler.scheduleTest(this) }
        }
        root.addView(exact); root.addView(notification); root.addView(test)

        status.text = "اضغط اختبار الأذان. يمكن لاحقًا ربط المواقيت الخمسة من WordPress."
        setContentView(root)
    }
}
