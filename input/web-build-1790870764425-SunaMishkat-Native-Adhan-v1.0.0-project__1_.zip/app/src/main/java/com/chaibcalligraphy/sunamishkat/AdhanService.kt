package com.chaibcalligraphy.sunamishkat

import android.app.*
import android.content.*
import android.media.MediaPlayer
import android.os.IBinder

class AdhanService : Service() {
    private var player: MediaPlayer? = null
    private val channelId = "suna_mishkat_adhan"

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(
                channelId, "أذان سُنا مِشكاة",
                NotificationManager.IMPORTANCE_HIGH
            ))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prayer = intent?.getStringExtra("prayer") ?: "الأذان"
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(com.chaibcalligraphy.sunamishkat.R.drawable.ic_launcher)
            .setContentTitle("🔔 $prayer")
            .setContentText("حان الآن وقت الأذان — سُنا مِشكاة")
            .setOngoing(true)
            .build()
        startForeground(1001, notification)

        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource("https://www.chaibcalligraphy.com/wp-content/uploads/2026/09/cbcd8d249dcc.mp3")
                setOnPreparedListener { it.start() }
                setOnCompletionListener { stopSelf() }
                prepareAsync()
            }
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
