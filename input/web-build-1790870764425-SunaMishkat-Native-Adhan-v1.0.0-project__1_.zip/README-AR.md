# سُنا مِشكاة — Native Android Adhan Engine v1.0.0

هذا المشروع هو نواة Android أصلية لمنبّه الأذان.

## ما تم تنفيذه
- AlarmManager + setExactAndAllowWhileIdle
- BroadcastReceiver
- Foreground Service من نوع mediaPlayback
- إشعار الأذان
- إعادة استقبال BOOT_COMPLETED / MY_PACKAGE_REPLACED
- اختبار أذان بعد 10 ثوانٍ
- طلب صلاحية Exact Alarm وNotifications

## ما بقي للنسخة النهائية
ربط مواقيت الصلاة الخمسة من WordPress API وجدولة الفجر والظهر والعصر والمغرب والعشاء تلقائيًا، ثم إعادة جدولة اليوم التالي وبعد إعادة تشغيل الجهاز.

## ملف الصوت
https://www.chaibcalligraphy.com/wp-content/uploads/2026/09/cbcd8d249dcc.mp3

## بناء APK
افتح المشروع في Android Studio ثم Build > Build APK(s).

ملاحظة: المشروع يحتاج Android SDK/Gradle في جهاز البناء.
