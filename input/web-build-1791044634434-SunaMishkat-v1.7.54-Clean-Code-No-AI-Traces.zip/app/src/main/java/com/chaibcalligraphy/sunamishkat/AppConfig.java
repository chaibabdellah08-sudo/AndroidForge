package com.chaibcalligraphy.sunamishkat;
public final class AppConfig {
 public static final String ADHAN_URL="https:www.chaibcalligraphy.comuploads09/cbcd8d249dcc.mp3";
 private AppConfig(){}
}
