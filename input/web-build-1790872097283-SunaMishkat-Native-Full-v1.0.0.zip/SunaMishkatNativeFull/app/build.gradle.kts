plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.chaibcalligraphy.sunamishkat"; compileSdk = 35
    defaultConfig { applicationId = "com.chaibcalligraphy.sunamishkat"; minSdk = 26; targetSdk = 35; versionCode = 100; versionName = "1.0.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
