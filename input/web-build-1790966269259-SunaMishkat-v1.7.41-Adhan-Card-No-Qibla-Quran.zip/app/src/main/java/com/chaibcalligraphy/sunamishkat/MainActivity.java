package com.chaibcalligraphy.sunamishkat;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.content.Intent;
import android.net.Uri;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.content.ActivityNotFoundException;
import android.widget.Toast;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Surface;
import android.view.WindowManager;
import android.icu.util.Calendar;
import android.icu.util.ULocale;
import android.hardware.GeomagneticField;

import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {
    private WebView web;
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private boolean compassRunning = false;
    private LocationManager locationManager;
    private String pendingOpenHash;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(10,48,39));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(245,247,242));
        if(Build.VERSION.SDK_INT>=23) getWindow().getDecorView().setSystemUiVisibility(0);
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);
        rotationSensor=sensorManager!=null?sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR):null;
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},71);
        }
        buildWebView(state);
        scheduleNativePrayerTimes();
    }

    private void buildWebView(Bundle state){
        web=new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(2,19,15));
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view,String url){ if(pendingOpenHash!=null){ String h=pendingOpenHash; pendingOpenHash=null; view.evaluateJavascript("location.hash=\""+h+"\"",null); } }
            private boolean handleUrl(String url){
                if(url==null)return false;
                Uri uri;
                try{uri=Uri.parse(url);}catch(Exception e){return false;}
                String scheme=uri.getScheme();
                if("mailto".equalsIgnoreCase(scheme)){
                    try{
                        Intent email=new Intent(Intent.ACTION_SENDTO,uri);
                        email.putExtra(Intent.EXTRA_SUBJECT,"التواصل مع مطور سُنا مِشكاة");
                        startActivity(Intent.createChooser(email,"اختيار تطبيق البريد الإلكتروني"));
                    }catch(ActivityNotFoundException e){
                        Toast.makeText(MainActivity.this,"لا يوجد تطبيق بريد إلكتروني مثبت على الهاتف",Toast.LENGTH_LONG).show();
                    }catch(Exception e){
                        Toast.makeText(MainActivity.this,"تعذر فتح البريد الإلكتروني",Toast.LENGTH_LONG).show();
                    }
                    return true;
                }
                if("http".equalsIgnoreCase(scheme)||"https".equalsIgnoreCase(scheme)){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){Toast.makeText(MainActivity.this,"تعذر فتح الرابط",Toast.LENGTH_SHORT).show();}
                    return true;
                }
                return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                return handleUrl(request!=null && request.getUrl()!=null?request.getUrl().toString():null);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url){
                return handleUrl(url);
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback){
                if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
                    pendingGeoCallback=callback;
                    pendingGeoOrigin=origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},72);
                }else callback.invoke(origin,true,false);
            }
        });
        web.addJavascriptInterface(new NativeBridge(this),"SunaMishkatNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        pendingOpenHash=getIntent().getStringExtra("open_hash");
    }

    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==72 && pendingGeoCallback!=null){
            boolean ok=grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED;
            pendingGeoCallback.invoke(pendingGeoOrigin,ok,false);
            pendingGeoCallback=null; pendingGeoOrigin=null;
            if(ok){ Toast.makeText(this,"تم السماح بالموقع للقبلة ومواقيت الصلاة",Toast.LENGTH_SHORT).show(); requestLocation(); scheduleNativePrayerTimes(); }
        }
    }

    public void startNativeCompass(){
        if(sensorManager==null || rotationSensor==null){
            sendHeading(-1);
            return;
        }
        if(!compassRunning){
            sensorManager.registerListener(this,rotationSensor,SensorManager.SENSOR_DELAY_GAME);
            compassRunning=true;
        }
    }

    public void stopNativeCompass(){
        if(sensorManager!=null && compassRunning) sensorManager.unregisterListener(this);
        compassRunning=false;
    }

    @Override public void onSensorChanged(SensorEvent event){
        if(event.sensor.getType()!=Sensor.TYPE_ROTATION_VECTOR)return;
        float[] rotation=new float[9];
        float[] orientation=new float[3];
        SensorManager.getRotationMatrixFromVector(rotation,event.values);
        int rotationMode=Surface.ROTATION_0;
        try{ rotationMode=((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRotation(); }catch(Exception ignored){}
        float[] adjusted=new float[9];
        if(rotationMode==Surface.ROTATION_90) SensorManager.remapCoordinateSystem(rotation,SensorManager.AXIS_Y,SensorManager.AXIS_MINUS_X,adjusted);
        else if(rotationMode==Surface.ROTATION_270) SensorManager.remapCoordinateSystem(rotation,SensorManager.AXIS_MINUS_Y,SensorManager.AXIS_X,adjusted);
        else if(rotationMode==Surface.ROTATION_180) SensorManager.remapCoordinateSystem(rotation,SensorManager.AXIS_MINUS_X,SensorManager.AXIS_MINUS_Y,adjusted);
        else System.arraycopy(rotation,0,adjusted,0,9);
        SensorManager.getOrientation(adjusted,orientation);
        double magnetic=Math.toDegrees(orientation[0]);
        double heading=(magnetic+360)%360;
        double[] ll=getLocationPair();
        if(ll!=null){
            try{ GeomagneticField g=new GeomagneticField((float)ll[0],(float)ll[1],0,System.currentTimeMillis()); heading=(heading+g.getDeclination()+360)%360; }catch(Exception ignored){}
        }
        sendHeading(heading);
    }

    private void sendHeading(double h){
        if(web==null)return;
        web.post(() -> web.evaluateJavascript("window.__nativeHeading && window.__nativeHeading("+String.format(Locale.US,"%.2f",h)+")",null));
    }
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}

    private double[] getLocationPair(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED) return null;
        try{
            Location best=null;
            if(locationManager!=null){
                Location gps=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                Location net=locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                best=(gps!=null && (net==null || gps.getTime()>=net.getTime()))?gps:net;
            }
            if(best!=null)return new double[]{best.getLatitude(),best.getLongitude()};
        }catch(Exception ignored){}
        return null;
    }

    public void requestLocation(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},72);
            return;
        }
        if(locationManager==null)return;
        try{
            Location best=null;
            for(String provider:new String[]{LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER}){
                try{
                    Location l=locationManager.getLastKnownLocation(provider);
                    if(l!=null && (best==null || l.getTime()>best.getTime()))best=l;
                }catch(Exception ignored){}
            }
            if(best!=null){ sendLocation(best); return; }
            LocationListener listener=new LocationListener(){
                @Override public void onLocationChanged(Location l){sendLocation(l);try{locationManager.removeUpdates(this);}catch(Exception ignored){}}
                @Override public void onProviderEnabled(String p){}
                @Override public void onProviderDisabled(String p){}
            };
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1000,1,listener,getMainLooper());
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,1,listener,getMainLooper());
        }catch(Exception ignored){}
    }

    private void sendLocation(Location l){
        if(web==null)return;
        String js=String.format(Locale.US,"window.__nativeLocation && window.__nativeLocation(%.7f,%.7f)",l.getLatitude(),l.getLongitude());
        web.post(() -> web.evaluateJavascript(js,null));
    }

    private String nativeHijri(){
        try{
            ULocale u=new ULocale("ar_SA@calendar=islamic-umalqura");
            Calendar c=Calendar.getInstance(u);
            int d=c.get(Calendar.DAY_OF_MONTH), m=c.get(Calendar.MONTH), y=c.get(Calendar.YEAR);
            String[] names={"محرم","صفر","ربيع الأول","ربيع الآخر","جمادى الأولى","جمادى الآخرة","رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة"};
            String name=(m>=0&&m<names.length)?names[m]:"";
            return "{\"day\":"+d+",\"month\":\""+name+"\",\"year\":"+y+"}";
        }catch(Exception e){return "";}
    }

    private void scheduleNativePrayerTimes(){
        // The web UI can provide exact times from Aladhan; this local fallback keeps
        // adhan scheduling alive when the network is unavailable.
        double[] ll=getLocationPair();
        if(ll==null) ll=new double[]{35.6971, -0.6308}; // Oran fallback
        java.util.Calendar d=java.util.Calendar.getInstance();
        double tz=d.getTimeZone().getOffset(d.getTimeInMillis())/3600000.0;
        PrayerTimes pt=PrayerTimes.calculate(d,ll[0],ll[1],tz);
        android.content.SharedPreferences.Editor e=getSharedPreferences("prayer_times",0).edit();
        int[] vals={pt.fajr,pt.dhuhr,pt.asr,pt.maghrib,pt.isha}; String[] keys={"fajr","dhuhr","asr","maghrib","isha"};
        for(int i=0;i<keys.length;i++){e.putInt(keys[i]+"_h",vals[i]/60);e.putInt(keys[i]+"_m",vals[i]%60);} e.apply();
        AdhanScheduler.scheduleAll(this);
    }

    public static final class NativeBridge {
        private final MainActivity activity; private final Context context;
        NativeBridge(MainActivity a){activity=a;context=a.getApplicationContext();}
        @JavascriptInterface public void setPrayerTimes(String fajr,String dhuhr,String asr,String maghrib,String isha){
            String[] keys={"fajr","dhuhr","asr","maghrib","isha"}; String[] vals={fajr,dhuhr,asr,maghrib,isha};
            android.content.SharedPreferences.Editor e=context.getSharedPreferences("prayer_times",0).edit();
            for(int i=0;i<keys.length;i++){String v=vals[i]==null?"":vals[i].trim(); if(v.matches("\\d{1,2}:\\d{2}")){String[] p=v.split(":");e.putInt(keys[i]+"_h",Integer.parseInt(p[0]));e.putInt(keys[i]+"_m",Integer.parseInt(p[1]));}}
            e.apply(); AdhanScheduler.scheduleAll(context);
        }
        @JavascriptInterface public void scheduleAdhan(){AdhanScheduler.scheduleAll(context);}
        @JavascriptInterface public void requestLocation(){activity.requestLocation();}
        @JavascriptInterface public void startCompass(){activity.startNativeCompass();}
        @JavascriptInterface public void stopCompass(){activity.stopNativeCompass();}
        @JavascriptInterface public String getHijriDate(){return activity.nativeHijri();}
        @JavascriptInterface public void stopAdhan(){context.stopService(new Intent(context,AdhanService.class));}
        @JavascriptInterface public void testAdhan(){ testAdhan("dhuhr",-1,-1); }
        @JavascriptInterface public void testAdhan(String prayer,int hour,int minute){ Intent s=new Intent(context,AdhanService.class).putExtra("test",true).putExtra("prayer",prayer); if(Build.VERSION.SDK_INT>=26) context.startForegroundService(s); else context.startService(s); try{ Intent a=new Intent(context,AdhanAlertActivity.class).putExtra("prayer",prayer).putExtra("display_hour",hour).putExtra("display_minute",minute).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP); context.startActivity(a); }catch(Exception ignored){} }
        @JavascriptInterface public void setClock24(boolean enabled){ context.getSharedPreferences("settings",0).edit().putBoolean("clock_24",enabled).apply(); }
        @JavascriptInterface public void setManualClock(int year,int month,int day,int hour,int minute,int second){ context.getSharedPreferences("settings",0).edit().putBoolean("manual_clock",true).putInt("manual_year",year).putInt("manual_month",month).putInt("manual_day",day).putInt("manual_hour",hour).putInt("manual_minute",minute).putInt("manual_second",second).apply(); }
        @JavascriptInterface public void clearManualClock(){ context.getSharedPreferences("settings",0).edit().putBoolean("manual_clock",false).apply(); }
        @JavascriptInterface public boolean getClock24(){ return context.getSharedPreferences("settings",0).getBoolean("clock_24",false); }
        @JavascriptInterface public void openExactAlarmSettings(){if(Build.VERSION.SDK_INT>=31){try{context.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+context.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception ignored){}}}
        @JavascriptInterface public boolean exactAlarmAllowed(){if(Build.VERSION.SDK_INT<31)return true;android.app.AlarmManager am=(android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);return am!=null&&am.canScheduleExactAlarms();}
    }

    @Override protected void onNewIntent(Intent intent){ super.onNewIntent(intent); setIntent(intent); pendingOpenHash=intent.getStringExtra("open_hash"); if(web!=null&&web.getUrl()!=null&&pendingOpenHash!=null){ String h=pendingOpenHash; pendingOpenHash=null; web.evaluateJavascript("location.hash=\""+h+"\"",null); } }

    @Override protected void onDestroy(){stopNativeCompass();super.onDestroy();}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
