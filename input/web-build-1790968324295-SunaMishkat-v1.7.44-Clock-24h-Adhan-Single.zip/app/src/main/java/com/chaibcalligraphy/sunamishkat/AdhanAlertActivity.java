package com.chaibcalligraphy.sunamishkat;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class AdhanAlertActivity extends Activity {
    private StopSlider slider;
    private final BroadcastReceiver finishedReceiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){finish();}};

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}
        getWindow().setStatusBarColor(Color.rgb(3,47,38));
        getWindow().setNavigationBarColor(Color.rgb(2,34,28));
        buildUi();
        new Handler(Looper.getMainLooper()).postDelayed(()->AdhanService.hideForAlert(),80);
        IntentFilter f=new IntentFilter(AdhanService.ACTION_FINISHED);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(finishedReceiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(finishedReceiver,f);
    }

    private GradientDrawable bg(int c,float r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
    private GradientDrawable grad(int a,int b,float r){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});d.setCornerRadius(r);return d;}
    private TextView tv(String s,float z,int c,int g){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setGravity(g);t.setIncludeFontPadding(false);return t;}

    private void buildUi(){
        final int WHITE=Color.WHITE, MUTED=Color.rgb(210,235,226), GOLD=Color.rgb(231,198,106);
        String prayer=getIntent().getStringExtra("prayer"), title=prayerName(prayer);
        boolean h24=getSharedPreferences("settings",0).getBoolean("clock_24",true);
        int dh=getIntent().getIntExtra("display_hour",-1), dm=getIntent().getIntExtra("display_minute",-1);
        String time;
        if(dh>=0&&dm>=0) time=h24?String.format(Locale.US,"%02d:%02d",dh,dm):format12(dh,dm);
        else {Calendar c=Calendar.getInstance();time=h24?String.format(Locale.US,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)):format12(c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE));}

        FrameLayout root=new FrameLayout(this);
        root.setBackground(grad(Color.rgb(4,91,73),Color.rgb(1,38,31),0));
        root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        View glow=new View(this); glow.setBackground(bg(Color.argb(22,255,255,255),500));
        FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(560,560,Gravity.CENTER);gp.topMargin=-20;root.addView(glow,gp);

        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setGravity(Gravity.CENTER_HORIZONTAL);content.setPadding(22,20,22,18);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        TextView badge=tv("سُنا مشكاة  •  حان وقت الأذان",16,MUTED,Gravity.CENTER);
        badge.setBackground(pill());
        content.addView(badge,new LinearLayout.LayoutParams(-2,48));

        Space top=new Space(this);content.addView(top,new LinearLayout.LayoutParams(1,54));
        TextView clock=tv(time,76,WHITE,Gravity.CENTER);clock.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));clock.setTextDirection(View.TEXT_DIRECTION_LTR);clock.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);clock.setLetterSpacing(0.01f);
        content.addView(clock,new LinearLayout.LayoutParams(-1,92));
        TextView label=tv(title,32,WHITE,Gravity.CENTER);label.setTypeface(Typeface.DEFAULT_BOLD);content.addView(label,new LinearLayout.LayoutParams(-1,48));
        TextView ornament=tv("—  ✦  —",20,GOLD,Gravity.CENTER);content.addView(ornament,new LinearLayout.LayoutParams(-1,42));

        TextView now=tv("صل الآن",27,WHITE,Gravity.CENTER);now.setTypeface(Typeface.DEFAULT_BOLD);now.setBackground(grad(Color.rgb(29,203,107),Color.rgb(5,143,75),30));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,74);np.setMargins(0,10,0,0);content.addView(now,np);

        Space bottom=new Space(this);content.addView(bottom,new LinearLayout.LayoutParams(1,0,1));
        TextView hint=tv("اسحب لإيقاف الأذان",16,MUTED,Gravity.CENTER);content.addView(hint,new LinearLayout.LayoutParams(-1,30));
        slider=new StopSlider(this);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,60);sp.topMargin=5;content.addView(slider,sp);slider.setOnStopListener(this::stopAdhan);
        TextView foot=tv("اسحب الدائرة إلى النهاية لإيقاف الأذان",13,Color.rgb(160,198,186),Gravity.CENTER);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,28);fp.topMargin=4;content.addView(foot,fp);
        TextView exit=tv("خروج",16,WHITE,Gravity.CENTER);exit.setBackground(transparentButton());LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(140,48);ep.topMargin=7;content.addView(exit,ep);exit.setOnClickListener(v->stopAdhan());

        setContentView(root);
    }
    private String format12(int h,int m){int hh=h%12;if(hh==0)hh=12;return String.format(Locale.US,"%02d:%02d %s",hh,m,h>=12?"م":"ص");}
    private GradientDrawable pill(){GradientDrawable d=bg(Color.argb(18,255,255,255),28);d.setStroke(2,Color.argb(85,255,255,255));return d;}
    private GradientDrawable transparentButton(){GradientDrawable d=bg(Color.argb(18,255,255,255),28);d.setStroke(1,Color.argb(85,255,255,255));return d;}
    private String prayerName(String p){if(p==null)return "الأذان";switch(p.toLowerCase(Locale.US)){case "fajr":return "الفجر";case "dhuhr":return "الظهر";case "asr":return "العصر";case "maghrib":return "المغرب";case "isha":return "العشاء";default:return p;}}
    private void stopAdhan(){try{stopService(new Intent(this,AdhanService.class));}catch(Exception ignored){}finish();}
    @Override protected void onStop(){super.onStop();if(!isFinishing())new Handler(Looper.getMainLooper()).postDelayed(()->AdhanService.showAfterAlert(),120);}
    @Override protected void onDestroy(){try{unregisterReceiver(finishedReceiver);}catch(Exception ignored){}super.onDestroy();}
    @Override public void onBackPressed(){stopAdhan();}

    public static class StopSlider extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private float progress=1f;private boolean dragging;private Runnable listener;
        public StopSlider(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        public void setOnStopListener(Runnable r){listener=r;}
        protected void onDraw(Canvas c){float w=getWidth(),h=getHeight();p.setColor(Color.argb(38,0,0,0));c.drawRoundRect(0,3,w,h-3,(h-6)/2f,(h-6)/2f,p);p.setColor(Color.argb(40,255,255,255));c.drawRoundRect(3,6,w-3,h-6,(h-12)/2f,(h-12)/2f,p);p.setColor(Color.WHITE);p.setTextSize(14);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("اسحب الدائرة لإيقاف الأذان",w/2f,h/2f+5,p);float x=9+progress*(w-18);p.setColor(Color.WHITE);c.drawCircle(x,h/2f,22,p);p.setColor(Color.rgb(7,95,74));p.setTextSize(22);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("‹",x,h/2f+8,p);}
        public boolean onTouchEvent(MotionEvent e){float w=getWidth();if(e.getAction()==MotionEvent.ACTION_DOWN){dragging=true;update(e.getX(),w);return true;}if(e.getAction()==MotionEvent.ACTION_MOVE&&dragging){update(e.getX(),w);return true;}if(e.getAction()==MotionEvent.ACTION_UP&&dragging){update(e.getX(),w);dragging=false;if(progress<=.12f&&listener!=null)listener.run();else{progress=1f;invalidate();}return true;}return true;}
        private void update(float x,float w){progress=Math.max(0,Math.min(1,(x-9)/(w-18)));invalidate();}
    }
}
