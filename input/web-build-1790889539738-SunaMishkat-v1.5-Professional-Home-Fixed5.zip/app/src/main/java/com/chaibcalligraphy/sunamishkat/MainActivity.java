package com.chaibcalligraphy.sunamishkat;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

import java.util.*;

public class MainActivity extends Activity {
    private static final String[] KEYS={"fajr","dhuhr","asr","maghrib","isha"};
    private static final String[] NAMES={"الفجر","الظهر","العصر","المغرب","العشاء"};
    private static final String[] ICONS={"☀","☀","☀","◐","☾"};
    private LinearLayout root, prayerList;
    private TextView clock, dateText, nextTitle, countdown, locationText, status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable ticker;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(10,52,45));
        getWindow().setNavigationBarColor(Color.rgb(247,244,236));
        if(Build.VERSION.SDK_INT>=23) getWindow().getDecorView().setSystemUiVisibility(0);
        ticker=()->{refreshHeader(); handler.postDelayed(ticker,1000);};
        build();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},56);
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},55);
    }
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(ticker);handler.post(ticker);}
    @Override protected void onPause(){handler.removeCallbacks(ticker);super.onPause();}

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setFontFeatureSettings("kern");t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return t;}
    private GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
    private GradientDrawable stroke(int fill,int line,float r){GradientDrawable g=bg(fill,r);g.setStroke(dp(1),line);return g;}

    private void build(){
        final int cream=Color.rgb(247,244,236), green=Color.rgb(10,52,45), gold=Color.rgb(190,148,62), dark=Color.rgb(30,38,35), muted=Color.rgb(105,112,106), white=Color.WHITE;
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(cream);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(14),dp(18),dp(28));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);scroll.addView(root);

        LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);brand.setPadding(dp(4),dp(4),dp(4),dp(10));
        TextView mark=text("۞",34,gold);mark.setGravity(Gravity.CENTER);brand.addView(mark,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout brandWords=new LinearLayout(this);brandWords.setOrientation(LinearLayout.VERTICAL);
        TextView title=text("سُنا مِشكاة",25,green);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);brandWords.addView(title,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView sub=text("نورٌ للوقت والذكر",13,muted);brandWords.addView(sub,new LinearLayout.LayoutParams(-1,dp(25)));
        brand.addView(brandWords,new LinearLayout.LayoutParams(0,-2,1));
        TextView gear=text("⚙",25,green);gear.setGravity(Gravity.CENTER);gear.setOnClickListener(v->showSettings());brand.addView(gear,new LinearLayout.LayoutParams(dp(50),dp(52)));root.addView(brand);

        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setGravity(Gravity.CENTER);hero.setPadding(dp(20),dp(20),dp(20),dp(22));hero.setBackground(bg(green,24));
        locationText=text("📍 جارٍ تحديد المدينة",14,Color.rgb(215,226,218));locationText.setGravity(Gravity.CENTER);hero.addView(locationText,new LinearLayout.LayoutParams(-1,dp(30)));
        clock=text("--:--",42,white);clock.setGravity(Gravity.CENTER);clock.setTypeface(Typeface.DEFAULT,Typeface.BOLD);hero.addView(clock,new LinearLayout.LayoutParams(-1,dp(62)));
        dateText=text("",14,Color.rgb(215,226,218));dateText.setGravity(Gravity.CENTER);hero.addView(dateText,new LinearLayout.LayoutParams(-1,dp(28)));
        LinearLayout next=new LinearLayout(this);next.setOrientation(LinearLayout.VERTICAL);next.setGravity(Gravity.CENTER);next.setPadding(dp(14),dp(10),dp(14),dp(10));next.setBackground(bg(Color.argb(38,255,255,255),18));
        nextTitle=text("الصلاة القادمة",14,Color.rgb(230,235,229));nextTitle.setGravity(Gravity.CENTER);next.addView(nextTitle,new LinearLayout.LayoutParams(-1,dp(25)));
        countdown=text("--:--:--",24,Color.WHITE);countdown.setGravity(Gravity.CENTER);countdown.setTypeface(Typeface.DEFAULT,Typeface.BOLD);next.addView(countdown,new LinearLayout.LayoutParams(-1,dp(38)));hero.addView(next,new LinearLayout.LayoutParams(-1,dp(83)));root.addView(hero,new LinearLayout.LayoutParams(-1,dp(250)));

        TextView heading=text("مواقيت الصلاة",20,dark);heading.setTypeface(Typeface.DEFAULT,Typeface.BOLD);heading.setPadding(dp(4),dp(22),dp(4),dp(10));root.addView(heading,new LinearLayout.LayoutParams(-1,dp(58)));
        prayerList=new LinearLayout(this);prayerList.setOrientation(LinearLayout.VERTICAL);root.addView(prayerList);
        rebuildPrayerCards();

        LinearLayout actions=new LinearLayout(this);actions.setPadding(0,dp(16),0,0);actions.setGravity(Gravity.CENTER);root.addView(actions,new LinearLayout.LayoutParams(-1,dp(76)));
        Button auto=actionButton("📍  تحديث الموقع",green,white);auto.setOnClickListener(v->calculateByLocation());actions.addView(auto,new LinearLayout.LayoutParams(0,dp(52),1));
        Space sp=new Space(this);actions.addView(sp,new LinearLayout.LayoutParams(dp(10),1));
        Button save=actionButton("🔔  تفعيل الأذان",gold,Color.WHITE);save.setOnClickListener(v->{AdhanScheduler.scheduleAll(this);status.setText("تمت جدولة الأذان للمواقيت الحالية");Toast.makeText(this,"تم تفعيل الأذان",Toast.LENGTH_SHORT).show();});actions.addView(save,new LinearLayout.LayoutParams(0,dp(52),1));

        status=text("",13,muted);status.setGravity(Gravity.CENTER);root.addView(status,new LinearLayout.LayoutParams(-1,dp(42)));
        LinearLayout nav=new LinearLayout(this);nav.setPadding(0,dp(12),0,0);nav.setGravity(Gravity.CENTER);root.addView(nav,new LinearLayout.LayoutParams(-1,dp(76)));
        addNav(nav,"☰","المزيد");addNav(nav,"☾","القبلة");addNav(nav,"▤","الأذكار");addNav(nav,"▣","القرآن");
        TextView dev=text("Abdellah Chaib  •  contact@chaibcalligraphy.com",11,muted);dev.setGravity(Gravity.CENTER);root.addView(dev,new LinearLayout.LayoutParams(-1,dp(30)));
        setContentView(scroll);
    }

    private Button actionButton(String s,int color,int fg){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(fg);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(bg(color,16));b.setPadding(dp(6),0,dp(6),0);return b;}
    private void addNav(LinearLayout nav,String icon,String label){LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);TextView a=text(icon,21,Color.rgb(10,52,45));a.setGravity(Gravity.CENTER);item.addView(a,new LinearLayout.LayoutParams(-1,dp(32)));TextView l=text(label,11,Color.rgb(105,112,106));l.setGravity(Gravity.CENTER);item.addView(l,new LinearLayout.LayoutParams(-1,dp(24)));nav.addView(item,new LinearLayout.LayoutParams(0,dp(60),1));}

    private void rebuildPrayerCards(){
        if(prayerList==null)return; prayerList.removeAllViews();
        final int green=Color.rgb(10,52,45),gold=Color.rgb(190,148,62),dark=Color.rgb(30,38,35),muted=Color.rgb(105,112,106);
        int next=nextPrayerIndex();
        for(int i=0;i<5;i++){
            LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(14),dp(8),dp(10),dp(8));
            card.setBackground(i==next?stroke(Color.rgb(241,232,207),gold,18):stroke(Color.WHITE,Color.rgb(228,225,216),18));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(74));cp.bottomMargin=dp(8);prayerList.addView(card,cp);
            TextView icon=text(ICONS[i],23,i==next?gold:green);icon.setGravity(Gravity.CENTER);card.addView(icon,new LinearLayout.LayoutParams(dp(48),-1));
            LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);names.setGravity(Gravity.CENTER_VERTICAL);
            TextView n=text(NAMES[i],17,dark);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);names.addView(n,new LinearLayout.LayoutParams(-1,dp(30)));
            TextView hint=text(i==next?"الصلاة القادمة":"وقت الأذان",11,i==next?gold:muted);names.addView(hint,new LinearLayout.LayoutParams(-1,dp(23)));card.addView(names,new LinearLayout.LayoutParams(0,-1,1));
            TextView time=text(getTime(i),20,green);time.setGravity(Gravity.CENTER);time.setTypeface(Typeface.DEFAULT,Typeface.BOLD);card.addView(time,new LinearLayout.LayoutParams(dp(92),-1));
            final int prayerIndex = i;
            card.setOnClickListener(v->pickPrayer(prayerIndex));
        }
    }

    private String getTime(int i){SharedPreferences p=getSharedPreferences("prayer_times",0);int h=p.getInt(KEYS[i]+"_h",-1),m=p.getInt(KEYS[i]+"_m",-1);return h<0?"—":String.format(Locale.US,"%02d:%02d",h,m);}
    private long timeMillis(int i,Calendar now){SharedPreferences p=getSharedPreferences("prayer_times",0);int h=p.getInt(KEYS[i]+"_h",-1),m=p.getInt(KEYS[i]+"_m",-1);if(h<0||m<0)return -1;Calendar c=(Calendar)now.clone();c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,m);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();}
    private int nextPrayerIndex(){Calendar now=Calendar.getInstance();long best=Long.MAX_VALUE;int idx=-1;for(int i=0;i<5;i++){long t=timeMillis(i,now);if(t>now.getTimeInMillis()&&t<best){best=t;idx=i;}}if(idx<0){for(int i=0;i<5;i++)if(timeMillis(i,now)>0){idx=i;break;}}return idx;}

    private void refreshHeader(){if(clock==null)return;Calendar now=Calendar.getInstance();clock.setText(String.format(Locale.US,"%02d:%02d:%02d",now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),now.get(Calendar.SECOND)));String[] days={"الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"};String[] months={"يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"};dateText.setText(days[now.get(Calendar.DAY_OF_WEEK)-1]+"، "+now.get(Calendar.DAY_OF_MONTH)+" "+months[now.get(Calendar.MONTH)]+" "+now.get(Calendar.YEAR));int i=nextPrayerIndex();if(i>=0){long t=timeMillis(i,now);if(t<=now.getTimeInMillis())t+=86400000L;long d=t-now.getTimeInMillis();countdown.setText(String.format(Locale.US,"%02d:%02d:%02d",d/3600000,(d/60000)%60,(d/1000)%60));nextTitle.setText("الصلاة القادمة: "+NAMES[i]+"  •  "+getTime(i));}else{nextTitle.setText("الصلاة القادمة");countdown.setText("--:--:--");}if(prayerList!=null && now.get(Calendar.SECOND)==0)rebuildPrayerCards();}

    private void pickPrayer(final int i){SharedPreferences p=getSharedPreferences("prayer_times",0);int h=p.getInt(KEYS[i]+"_h",12),m=p.getInt(KEYS[i]+"_m",0);new TimePickerDialog(this,(v,hh,mm)->{p.edit().putInt(KEYS[i]+"_h",hh).putInt(KEYS[i]+"_m",mm).apply();AdhanScheduler.scheduleAll(this);rebuildPrayerCards();refreshHeader();},h,m,true).show();}

    private void calculateByLocation(){
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},55);return;}
        LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);Location loc=null;try{loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);}catch(Exception ignored){}try{Location n=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);if(loc==null||(n!=null&&n.getTime()>loc.getTime()))loc=n;}catch(Exception ignored){}
        if(loc==null){locationText.setText("📍 فعّل الموقع ثم حاول مرة أخرى");return;}
        Calendar c=Calendar.getInstance();double tz=TimeZone.getDefault().getOffset(c.getTimeInMillis())/3600000.0;PrayerTimes pt=PrayerTimes.calculate(c,loc.getLatitude(),loc.getLongitude(),tz);int[] vals={pt.fajr,pt.dhuhr,pt.asr,pt.maghrib,pt.isha};SharedPreferences.Editor e=getSharedPreferences("prayer_times",0).edit();for(int i=0;i<5;i++)e.putInt(KEYS[i]+"_h",vals[i]/60).putInt(KEYS[i]+"_m",vals[i]%60);e.apply();AdhanScheduler.scheduleAll(this);locationText.setText("📍 تم تحديث مواقيت الصلاة حسب موقع الهاتف");rebuildPrayerCards();refreshHeader();Toast.makeText(this,"تم تحديث المواقيت وجدولة الأذان",Toast.LENGTH_SHORT).show();
    }

    private void showSettings(){
        final Dialog d=new Dialog(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(18),dp(22),dp(18));box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);box.setBackground(bg(Color.WHITE,22));
        TextView t=text("إعدادات سُنا مِشكاة",22,Color.rgb(10,52,45));t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);box.addView(t,new LinearLayout.LayoutParams(-1,dp(52)));
        Button test=actionButton("🔔 اختبار الأذان بعد 10 ثوانٍ",Color.rgb(10,52,45),Color.WHITE);test.setOnClickListener(v->{AdhanScheduler.scheduleTest(this,10000);Toast.makeText(this,"سيبدأ الاختبار بعد 10 ثوانٍ",Toast.LENGTH_SHORT).show();});box.addView(test,new LinearLayout.LayoutParams(-1,dp(52)));
        Button exact=actionButton("⚙ السماح بالمنبهات الدقيقة",Color.rgb(241,232,207),Color.rgb(10,52,45));exact.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=31)try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}});box.addView(exact,new LinearLayout.LayoutParams(-1,dp(52)));
        Button auto=actionButton("📍 إعادة حساب المواقيت",Color.rgb(238,241,237),Color.rgb(10,52,45));auto.setOnClickListener(v->{d.dismiss();calculateByLocation();});box.addView(auto,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView info=text("الأذان يعمل في الخلفية حتى عند إغلاق التطبيق.\n\nAbdellah Chaib\ncontact@chaibcalligraphy.com",13,Color.rgb(105,112,106));info.setPadding(0,dp(16),0,dp(8));box.addView(info,new LinearLayout.LayoutParams(-1,-2));
        d.setContentView(box);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(dp(340),WindowManager.LayoutParams.WRAP_CONTENT);}d.show();if(d.getWindow()!=null)d.getWindow().setLayout(dp(340),WindowManager.LayoutParams.WRAP_CONTENT);
    }
}
