# سُنا مِشكاة v1.4 — UI plan

This build intentionally keeps the verified v1.3 activity and adhan/prayer logic unchanged.

The next UI is planned as an independent layer:
- Header: سُنا مِشكاة
- Current city/location
- Current time
- Next prayer and countdown
- Five prayer cards
- Adhan status
- Night mode
- Navigation for Qibla, Quran, Adhkar, Duas and Hadith

No external dependencies are introduced in this stage.
