package com.chaibcalligraphy.sunamishkat;

import android.app.*;
import android.content.*;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.*;
import android.os.*;
import android.widget.RemoteViews;

public class AdhanService extends Service {
    static final int NOTIF=1441;
    private static AdhanService instance;
    private boolean notificationHidden=false;
    public static final String ACTION_FINISHED="com.chaibcalligraphy.sunamishkat.ADHAN_FINISHED";
    private MediaPlayer player;
    private boolean finished=false;
    private boolean started=false;
    private String currentPrayer="";

    @Override public void onCreate(){
        super.onCreate();
        instance=this;
        String ch="suna_adhan_v3";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel nc=new NotificationChannel(ch,"الأذان | Adhan",NotificationManager.IMPORTANCE_HIGH);
            nc.setDescription("تنبيه صغير للأذان وتشغيله في وقت الصلاة");
            nc.enableLights(true);
            nc.setLightColor(Color.rgb(47,207,107));
            nc.setVibrationPattern(new long[]{0,180,90,180});
            nc.setSound(null,null);
            nc.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(nc);
        }
        startForeground(NOTIF,buildNotification(ch));
    }

    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null && i.hasExtra("prayer")) currentPrayer=i.getStringExtra("prayer");
        if(!started){
            started=true;
            String ch="suna_adhan_v3";
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF,buildNotification(ch));
            startPlayer();
        } else {
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF,buildNotification(chName()));
        }
        return START_NOT_STICKY;
    }

    private String chName(){return "suna_adhan_v3";}

    private Notification buildNotification(String ch){
        Intent stop=new Intent(this,AdhanStopReceiver.class);
        PendingIntent stopPi=PendingIntent.getBroadcast(this,1443,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);

        RemoteViews compact=new RemoteViews(getPackageName(),R.layout.notification_adhan);
        compact.setImageViewResource(R.id.adhan_notification_logo,R.drawable.suna_mishkat_icon);
        compact.setTextViewText(R.id.adhan_notification_title,"الأذان | Adhan");
        compact.setTextViewText(R.id.adhan_notification_prayer,prayerName(currentPrayer));
        compact.setOnClickPendingIntent(R.id.adhan_notification_stop,stopPi);

        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ch):new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_stop_adhan)
         .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.suna_mishkat_icon))
         .setContentTitle("الأذان | Adhan")
         .setContentText(prayerName(currentPrayer))
         .setSubText("سُنا مِشكاة")
         .setColor(Color.rgb(47,207,107))
         .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_HIGH)
         .setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true)
         .setAutoCancel(false)
         .setCustomContentView(compact)
         .setCustomHeadsUpContentView(compact)
         .addAction(new Notification.Action.Builder(R.drawable.ic_stat_stop_adhan,"إيقاف الأذان | Stop",stopPi).build());
        return b.build();
    }

    private void startPlayer(){
        player=new MediaPlayer();
        try{
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(AppConfig.ADHAN_URL);
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(p->finishAdhan());
            player.prepareAsync();
        }catch(Exception e){finishAdhan();}
    }

    private String prayerName(String p){
        if(p==null||p.trim().isEmpty())return "الأذان";
        switch(p.toLowerCase()){
            case "fajr":return "الفجر | Fajr";
            case "dhuhr":return "الظهر | Dhuhr";
            case "asr":return "العصر | Asr";
            case "maghrib":return "المغرب | Maghrib";
            case "isha":return "العشاء | Isha";
            default:return p;
        }
    }

    private void finishAdhan(){
        if(finished)return; finished=true;
        try{sendBroadcast(new Intent(ACTION_FINISHED).setPackage(getPackageName()));}catch(Exception ignored){}
        stopForeground(true); stopSelf();
    }

    @Override public android.os.IBinder onBind(Intent i){return null;}
    public static void hideForAlert(){
        AdhanService s=instance;
        if(s!=null) s.hideNotification();
    }
    public static void showAfterAlert(){
        AdhanService s=instance;
        if(s!=null) s.showNotification();
    }
    private void hideNotification(){
        if(notificationHidden)return;
        notificationHidden=true;
        if(Build.VERSION.SDK_INT>=24){
            try{stopForeground(STOP_FOREGROUND_REMOVE);}catch(Exception ignored){}
        }else{try{stopForeground(true);}catch(Exception ignored){}}
    }
    private void showNotification(){
        if(!notificationHidden || finished)return;
        notificationHidden=false;
        try{startForeground(NOTIF,buildNotification(chName()));}catch(Exception ignored){}
    }
    @Override public void onDestroy(){
        instance=null;
        if(player!=null){try{player.release();}catch(Exception ignored){}}
        super.onDestroy();
    }
}
