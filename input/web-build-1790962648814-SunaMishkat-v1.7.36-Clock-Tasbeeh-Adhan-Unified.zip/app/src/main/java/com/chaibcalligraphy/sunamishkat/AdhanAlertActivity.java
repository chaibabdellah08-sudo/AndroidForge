package com.chaibcalligraphy.sunamishkat;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class AdhanAlertActivity extends Activity {
    private StopSlider slider;
    private final BroadcastReceiver finishedReceiver = new BroadcastReceiver(){
        @Override public void onReceive(Context c, Intent i){ finish(); }
    };

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}
        getWindow().setStatusBarColor(Color.rgb(4,48,39));
        getWindow().setNavigationBarColor(Color.rgb(3,36,29));
        buildUi();
        new Handler(Looper.getMainLooper()).postDelayed(() -> AdhanService.hideForAlert(), 180);
        IntentFilter f=new IntentFilter(AdhanService.ACTION_FINISHED);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(finishedReceiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(finishedReceiver,f);
    }

    private GradientDrawable bg(int color,float radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    private GradientDrawable grad(int c1,int c2,float radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{c1,c2});d.setCornerRadius(radius);return d;}
    private TextView tv(String s,float size,int color,int gravity){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(gravity);t.setIncludeFontPadding(false);return t;}

    private void buildUi(){
        final int white=Color.WHITE, muted=Color.rgb(205,231,222), green=Color.rgb(9,170,91);
        String prayer=getIntent().getStringExtra("prayer");
        String title=prayerName(prayer);
        boolean h24=getSharedPreferences("settings",0).getBoolean("clock_24",false);
        String pattern=h24?"HH:mm":"hh:mm";
        String time=new SimpleDateFormat(pattern,Locale.getDefault()).format(new Date());
        if(!h24){
            try{time=time.replace("AM","ص").replace("PM","م");}catch(Exception ignored){}
        }

        FrameLayout root=new FrameLayout(this);
        root.setBackground(grad(Color.rgb(3,68,55),Color.rgb(2,35,29),0));
        root.addView(new RingsView(this),new FrameLayout.LayoutParams(-1,-1));

        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setGravity(Gravity.CENTER_HORIZONTAL);content.setPadding(26,24,26,22);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,-1);root.addView(content,cp);

        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        TextView close=tv("×",30,white,Gravity.CENTER);close.setBackground(bg(Color.argb(45,0,0,0),60));
        top.addView(close,new LinearLayout.LayoutParams(52,52));
        content.addView(top,new LinearLayout.LayoutParams(-1,56));
        close.setOnClickListener(v->stopAdhan());

        Space s1=new Space(this);content.addView(s1,new LinearLayout.LayoutParams(1,70));
        TextView clock=tv(time,64,white,Gravity.CENTER);clock.setTypeface(null,android.graphics.Typeface.BOLD);content.addView(clock,new LinearLayout.LayoutParams(-1,80));
        TextView label=tv(title,30,white,Gravity.CENTER);label.setTypeface(null,android.graphics.Typeface.BOLD);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,48);lp.topMargin=8;content.addView(label,lp);

        TextView dots=tv("•  •  •",20,Color.rgb(224,193,100),Gravity.CENTER);LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,36);dp.topMargin=8;content.addView(dots,dp);
        Space s2=new Space(this);content.addView(s2,new LinearLayout.LayoutParams(1,24));

        TextView now=tv("صل الآن",23,white,Gravity.CENTER);now.setTypeface(null,android.graphics.Typeface.BOLD);now.setBackground(grad(Color.rgb(19,187,99),Color.rgb(4,135,69),22));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,68);np.setMargins(0,0,0,16);content.addView(now,np);

        LinearLayout links=new LinearLayout(this);links.setGravity(Gravity.CENTER);links.setOrientation(LinearLayout.HORIZONTAL);links.setWeightSum(2);content.addView(links,new LinearLayout.LayoutParams(-1,62));
        TextView qibla=link("◈", "القبلة"); TextView quran=link("▤", "القرآن");
        links.addView(qibla,weight());links.addView(quran,weight());
        qibla.setOnClickListener(v->openMain("qibla")); quran.setOnClickListener(v->openMain("quran"));

        Space bottom=new Space(this);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(1,0,1);content.addView(bottom,bp);
        TextView hint=tv("اسحب لإيقاف الأذان",14,muted,Gravity.CENTER);content.addView(hint,new LinearLayout.LayoutParams(-1,30));
        slider=new StopSlider(this);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,66);sp.topMargin=4;content.addView(slider,sp);slider.setOnStopListener(this::stopAdhan);
        TextView foot=tv("اسحب الدائرة حتى النهاية لإيقاف الأذان",12,Color.rgb(165,202,190),Gravity.CENTER);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,26);fp.topMargin=5;content.addView(foot,fp);
        setContentView(root);
    }

    private LinearLayout.LayoutParams weight(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,62,1);p.setMargins(6,0,6,0);return p;}
    private TextView link(String icon,String label){TextView t=tv(icon+"  "+label,18,Color.WHITE,Gravity.CENTER);t.setBackground(border());return t;}
    private GradientDrawable border(){GradientDrawable d=bg(Color.argb(35,255,255,255),20);d.setStroke(2,Color.argb(80,255,255,255));return d;}
    private void openMain(String hash){try{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("open_hash",hash);startActivity(i);finish();}catch(Exception ignored){}}
    private String prayerName(String p){if(p==null)return "الأذان";switch(p.toLowerCase(Locale.US)){case "fajr":return "الفجر";case "dhuhr":return "الظهر";case "asr":return "العصر";case "maghrib":return "المغرب";case "isha":return "العشاء";default:return p;}}
    private void stopAdhan(){try{stopService(new Intent(this,AdhanService.class));}catch(Exception ignored){}finish();}

    @Override protected void onStop(){super.onStop();if(!isFinishing())new Handler(Looper.getMainLooper()).postDelayed(()->AdhanService.showAfterAlert(),200);}
    @Override protected void onDestroy(){try{unregisterReceiver(finishedReceiver);}catch(Exception ignored){}super.onDestroy();}
    @Override public void onBackPressed(){moveTaskToBack(true);}

    public static class RingsView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);public RingsView(Context c){super(c);setWillNotDraw(false);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()*.40f;for(int i=3;i>=0;i--){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);p.setColor(Color.argb(25+i*6,255,255,255));c.drawCircle(cx,cy,105+i*52,p);}p.setStyle(Paint.Style.FILL);}
    }
    public static class StopSlider extends View{
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private float progress=1f;private boolean dragging;private Runnable listener;
        public StopSlider(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        public void setOnStopListener(Runnable r){listener=r;}
        @Override protected void onDraw(Canvas c){float w=getWidth(),h=getHeight();paint.setColor(Color.argb(35,0,0,0));c.drawRoundRect(0,5,w,h-5,(h-10)/2f,(h-10)/2f,paint);paint.setColor(Color.argb(40,255,255,255));c.drawRoundRect(3,8,w-3,h-8,(h-16)/2f,(h-16)/2f,paint);paint.setColor(Color.argb(210,255,255,255));paint.setTextSize(15);paint.setTextAlign(Paint.Align.CENTER);c.drawText("اسحب الدائرة لإيقاف الأذان",w/2f,h/2f+5,paint);float x=9+progress*(w-18);paint.setColor(Color.WHITE);c.drawCircle(x,h/2f,24,paint);paint.setColor(Color.rgb(7,95,74));paint.setTextSize(23);c.drawText("‹",x,h/2f+8,paint);}
        @Override public boolean onTouchEvent(MotionEvent e){float w=getWidth();if(e.getAction()==MotionEvent.ACTION_DOWN){dragging=true;update(e.getX(),w);return true;}if(e.getAction()==MotionEvent.ACTION_MOVE&&dragging){update(e.getX(),w);return true;}if(e.getAction()==MotionEvent.ACTION_UP&&dragging){update(e.getX(),w);dragging=false;if(progress<=.10f&&listener!=null)listener.run();else{progress=1f;invalidate();}return true;}return true;}
        private void update(float x,float w){progress=Math.max(0,Math.min(1,(x-9)/(w-18)));invalidate();}
    }
}
