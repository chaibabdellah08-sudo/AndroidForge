package com.chaibcalligraphy.sunamishkat;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** The single native full-screen adhan card used for both test and real prayer time. */
public class AdhanAlertActivity extends Activity {
    private StopSlider slider;
    private final BroadcastReceiver finishedReceiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){finish();}};

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}
        getWindow().setStatusBarColor(Color.rgb(3,45,36));
        getWindow().setNavigationBarColor(Color.rgb(2,28,23));
        buildUi();
        new Handler(Looper.getMainLooper()).postDelayed(()->AdhanService.hideForAlert(),80);
        IntentFilter f=new IntentFilter(AdhanService.ACTION_FINISHED);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(finishedReceiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(finishedReceiver,f);
    }

    private GradientDrawable solid(int c,float r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
    private GradientDrawable gradient(int a,int b,float r){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});d.setCornerRadius(r);return d;}
    private TextView tv(String s,float z,int c,int g){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setGravity(g);t.setIncludeFontPadding(false);return t;}

    private void buildUi(){
        final int WHITE=Color.WHITE, MUTED=Color.rgb(218,239,231), GOLD=Color.rgb(234,194,92);
        String prayer=getIntent().getStringExtra("prayer"), title=prayerName(prayer);
        boolean h24=getSharedPreferences("settings",0).getBoolean("clock_24",true);
        int dh=getIntent().getIntExtra("display_hour",-1), dm=getIntent().getIntExtra("display_minute",-1);
        String time;
        if(dh>=0&&dm>=0) time=h24?String.format(Locale.US,"%02d:%02d",dh,dm):format12(dh,dm);
        else { Calendar c=Calendar.getInstance(); time=h24?String.format(Locale.US,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)):format12(c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)); }

        getWindow().setStatusBarColor(Color.rgb(3,36,30));
        getWindow().setNavigationBarColor(Color.rgb(2,23,19));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        FrameLayout root=new FrameLayout(this);
        root.setBackground(gradient(Color.rgb(8,92,73),Color.rgb(2,31,26),0));

        // Modern, restrained background: no image and no large decorative rings.
        SoftGlow glow=new SoftGlow(this);
        root.addView(glow,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(18,18,18,16);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        TextView top=tv("سُنا مِشكاة  •  حان وقت الأذان",14,MUTED,Gravity.CENTER);
        top.setBackground(glass(0x18ffffff,0x55ffffff,24));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,46);tp.bottomMargin=22;content.addView(top,tp);

        TextView prayerLabel=tv(title,29,WHITE,Gravity.CENTER);
        prayerLabel.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        LinearLayout.LayoutParams pl=new LinearLayout.LayoutParams(-1,52);pl.bottomMargin=4;content.addView(prayerLabel,pl);

        TextView clock=tv(time,88,WHITE,Gravity.CENTER);
        clock.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        clock.setTextDirection(View.TEXT_DIRECTION_LTR); clock.setTextAlignment(View.TEXT_ALIGNMENT_CENTER); clock.setTextLocale(Locale.US);
        clock.setIncludeFontPadding(false); clock.setSingleLine(true); clock.setEllipsize(null);
        clock.setLetterSpacing(0.015f);
        clock.setContentDescription(time);
        LinearLayout.LayoutParams cl=new LinearLayout.LayoutParams(-1,112);cl.bottomMargin=8;content.addView(clock,cl);

        TextView divider=tv("────────",13,GOLD,Gravity.CENTER);
        LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,22);dl.bottomMargin=16;content.addView(divider,dl);

        TextView now=tv("صل الآن",20,WHITE,Gravity.CENTER);
        now.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        now.setBackground(gradient(Color.rgb(27,198,105),Color.rgb(8,146,76),28));
        now.setElevation(4f);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,66);np.bottomMargin=0;content.addView(now,np);

        Space spacer=new Space(this);content.addView(spacer,new LinearLayout.LayoutParams(1,0,1));

        TextView hint=tv("اسحب لإيقاف الأذان",15,MUTED,Gravity.CENTER);
        LinearLayout.LayoutParams hip=new LinearLayout.LayoutParams(-1,28);content.addView(hint,hip);
        slider=new StopSlider(this);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,58);sp.topMargin=5;content.addView(slider,sp);slider.setOnStopListener(this::stopAdhan);

        TextView exit=tv("خروج",15,WHITE,Gravity.CENTER);exit.setBackground(transparentButton());
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(132,46);ep.topMargin=10;content.addView(exit,ep);exit.setOnClickListener(v->stopAdhan());

        setContentView(root);
    }

    private String format12(int h,int m){int hh=h%12;if(hh==0)hh=12;return String.format(Locale.US,"%02d:%02d %s",hh,m,h>=12?"م":"ص");}
    private GradientDrawable pill(){GradientDrawable d=solid(Color.argb(20,255,255,255),26);d.setStroke(2,Color.argb(80,255,255,255));return d;}
    private GradientDrawable emblem(){GradientDrawable d=solid(Color.argb(18,255,255,255),36);d.setStroke(1,Color.argb(90,242,205,112));return d;}
    private GradientDrawable transparentButton(){GradientDrawable d=solid(Color.argb(22,255,255,255),26);d.setStroke(1,Color.argb(95,255,255,255));return d;}
    private String prayerName(String p){if(p==null||p.trim().isEmpty())return "الأذان";switch(p.toLowerCase(Locale.US)){case "fajr":return "الفجر";case "dhuhr":return "الظهر";case "asr":return "العصر";case "maghrib":return "المغرب";case "isha":return "العشاء";default:return p;}}
    private void stopAdhan(){try{stopService(new Intent(this,AdhanService.class));}catch(Exception ignored){}finish();}
    @Override protected void onStop(){super.onStop();if(!isFinishing())new Handler(Looper.getMainLooper()).postDelayed(()->AdhanService.showAfterAlert(),120);}
    @Override protected void onDestroy(){try{unregisterReceiver(finishedReceiver);}catch(Exception ignored){}super.onDestroy();}
    @Override public void onBackPressed(){stopAdhan();}

    private GradientDrawable glass(int fill,int stroke,float radius){GradientDrawable d=solid(Color.argb((fill>>24)&255,(fill>>16)&255,(fill>>8)&255,fill&255),radius);d.setStroke(1,Color.argb((stroke>>24)&255,(stroke>>16)&255,(stroke>>8)&255,stroke&255));return d;}

    private static class SoftGlow extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        SoftGlow(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){
            float cx=getWidth()/2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(18,72,230,167)); c.drawCircle(cx,190,190,p);
            p.setColor(Color.argb(12,238,202,100)); c.drawCircle(cx,205,120,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1f);p.setColor(Color.argb(18,255,255,255));
            c.drawCircle(cx,190,145,p); c.drawCircle(cx,190,105,p);
        }
    }

    public static class StopSlider extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private float progress=1f;private boolean dragging;private Runnable listener;
        public StopSlider(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        public void setOnStopListener(Runnable r){listener=r;}
        protected void onDraw(Canvas c){
            float w=getWidth(),h=getHeight();
            p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(35,255,255,255));c.drawRoundRect(0,2,w,h-2,(h-4)/2f,(h-4)/2f,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.2f);p.setColor(Color.argb(95,255,255,255));c.drawRoundRect(1,3,w-1,h-3,(h-6)/2f,(h-6)/2f,p);p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(25,255,255,255));float fillW=Math.max(0,(w-8)*progress);c.drawRoundRect(4,7,4+fillW,h-7,(h-14)/2f,(h-14)/2f,p);
            p.setColor(Color.WHITE);p.setShadowLayer(7,0,1,Color.argb(80,0,0,0));float x=9+progress*(w-18);c.drawCircle(x,h/2f,22,p);p.clearShadowLayer();
            p.setColor(Color.rgb(8,105,82));p.setTextSize(22);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.CENTER);c.drawText("‹",x,h/2f+8,p);
        }
        public boolean onTouchEvent(MotionEvent e){float w=getWidth();if(e.getAction()==MotionEvent.ACTION_DOWN){dragging=true;update(e.getX(),w);return true;}if(e.getAction()==MotionEvent.ACTION_MOVE&&dragging){update(e.getX(),w);return true;}if(e.getAction()==MotionEvent.ACTION_UP&&dragging){update(e.getX(),w);dragging=false;if(progress<=.12f&&listener!=null)listener.run();else{progress=1f;invalidate();}return true;}return true;}
        private void update(float x,float w){progress=Math.max(0,Math.min(1,(x-9)/(w-18)));invalidate();}
    }
}
