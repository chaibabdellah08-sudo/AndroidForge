# سُنا مِشكاة — التطبيق الأصلي Native Android

هذه النسخة ليست صفحة HTML ولا تطبيق AppCreator24. هي مشروع Android Native باسم **سُنا مِشكاة**.

## الهوية
- اسم التطبيق: سُنا مِشكاة
- Package: `com.chaibcalligraphy.sunamishkat`
- المطور: Abdellah Chaib
- البريد: contact@chaibcalligraphy.com
- الخادم: `https://www.chaibcalligraphy.com/wp-json/mishkat/v1/`
- ملف الأذان: `https://www.chaibcalligraphy.com/wp-content/uploads/2026/09/cbcd8d249dcc.mp3`

## ما تم بناؤه
- واجهة عربية RTL أصلية.
- مواقيت الصلاة من إضافة WordPress الحالية.
- جدولة الفجر والظهر والعصر والمغرب والعشاء عبر AlarmManager.
- تشغيل الأذان داخل Foreground Media Playback Service.
- إشعار Android أثناء تشغيل الأذان.
- إعادة جدولة المواقيت بعد إعادة تشغيل الهاتف.
- مزامنة يومية للمواقيت من WordPress.
- القرآن: قائمة السور وفتح نص السورة والاستماع إلى رابط الصوت الذي يعيده الخادم.
- الأذكار والأدعية من WordPress.
- أحاديث البخاري ومسلم من WordPress.
- التقويم الهجري.
- القبلة باستخدام موقع الهاتف والبوصلة.
- عداد التسبيح.
- وضع تشغيل الأذان التجريبي بعد 10 ثوانٍ.
- إعدادات إذن «المنبهات والتذكيرات» وطلب إشعارات Android.

## الأذان في الخلفية
الهدف هنا أن يعمل الأذان عندما يكون التطبيق في الخلفية أو تمت إزالته من قائمة التطبيقات الأخيرة، لأن التنفيذ يعتمد على AlarmManager + BroadcastReceiver + Foreground Service، وليس مؤقت JavaScript.

**مهم:** الضغط على «إيقاف إجباري / Force stop» من إعدادات Android يمنع النظام من تشغيل مكونات التطبيق حتى يفتحه المستخدم من جديد. كذلك قد تفرض بعض الشركات قيود بطارية إضافية؛ لذلك يجب السماح للتطبيق بالعمل في الخلفية عند الحاجة.

## بناء APK عبر AndroidForge
1. ارفع هذا المشروع ZIP إلى AndroidForge.
2. Build variant: `auto` أو `debug`.
3. بعد نجاح GitHub Actions حمّل ملف APK الناتج.

لا يحتاج المشروع إلى AppCreator24.
