# إعداد AndroidForge

المشروع مجهز للعمل مع AndroidForge. استخدم ملف ZIP الخاص بالمجلد الجذري للمشروع.

- Build variant: `auto`
- Module: `app`
- Task المتوقع: `assembleDebug`
- compileSdk: 35
- targetSdk: 35
- minSdk: 26
- AGP: 8.9.2
- Kotlin: 2.1.20

بعد بناء APK، سيكون اسم الملف غالباً قريباً من:
`AndroidForge-app-debug.apk`

هذه التسمية من خدمة البناء، أما اسم التطبيق داخل الهاتف فهو **سُنا مِشكاة**.
