package com.chaibcalligraphy.sunamishkat

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object AdhanScheduler {
    const val ACTION_ADHAN="com.chaibcalligraphy.sunamishkat.ADHAN"
    const val ACTION_SYNC="com.chaibcalligraphy.sunamishkat.SYNC"
    private val keys=listOf("Fajr","Dhuhr","Asr","Maghrib","Isha")
    fun exactAllowed(c:Context):Boolean = Build.VERSION.SDK_INT<31 || (c.getSystemService(AlarmManager::class.java)?.canScheduleExactAlarms()==true)
    fun requestExact(c:Context){ if(Build.VERSION.SDK_INT>=31) try{c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,android.net.Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}catch(_:Exception){} }
    fun scheduleDay(c:Context,day:PrayerRepository.Day){
        val am=c.getSystemService(AlarmManager::class.java) ?: return
        keys.forEachIndexed{idx,k->
            val time=day.prayers[idx].time.split(":"); if(time.size<2)return@forEachIndexed
            val cal=Calendar.getInstance().apply{set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);set(Calendar.HOUR_OF_DAY,time[0].toInt());set(Calendar.MINUTE,time[1].toInt())}
            if(cal.timeInMillis<=System.currentTimeMillis()+5000)return@forEachIndexed
            val i=Intent(c,AdhanReceiver::class.java).setAction(ACTION_ADHAN).putExtra("prayer",k)
            val pi=PendingIntent.getBroadcast(c,100+idx,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            if(exactAllowed(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi) else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
        }
        scheduleSync(c)
    }
    fun scheduleSync(c:Context){
        val am=c.getSystemService(AlarmManager::class.java) ?: return
        val cal=Calendar.getInstance().apply{add(Calendar.DAY_OF_YEAR,1);set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,10);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}
        val pi=PendingIntent.getBroadcast(c,9001,Intent(c,PrayerSyncReceiver::class.java).setAction(ACTION_SYNC),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if(exactAllowed(c))am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi) else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
    }
    fun test(c:Context,seconds:Int=10){
        val am=c.getSystemService(AlarmManager::class.java) ?: return
        val pi=PendingIntent.getBroadcast(c,9900,Intent(c,AdhanReceiver::class.java).setAction(ACTION_ADHAN).putExtra("prayer","TEST"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val at=System.currentTimeMillis()+seconds*1000L
        if(exactAllowed(c))am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi) else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi)
    }
}
