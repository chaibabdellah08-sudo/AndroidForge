package com.chaibcalligraphy.sunamishkat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AdhanReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent){
        if(!Prefs.enabled(context))return
        val prayer=intent.getStringExtra("prayer") ?: ""
        val i=Intent(context,AdhanService::class.java).setAction(AdhanService.ACTION_PLAY).putExtra("prayer",prayer)
        ContextCompat.startForegroundService(context,i)
    }
}
