package com.chaibcalligraphy.sunamishkat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class PrayerSyncReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){
   val pending=goAsync()
   Executors.newSingleThreadExecutor().execute{
     try{
       val day=PrayerRepository.today(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()))
       Prefs.saveDay(context,day);AdhanScheduler.scheduleDay(context,day)
     }catch(_:Exception){AdhanScheduler.scheduleSync(context)} finally{pending.finish()}
   }
 }
}
