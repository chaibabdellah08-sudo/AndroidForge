package com.chaibcalligraphy.sunamishkat

import android.content.Context

object Prefs {
    private const val P="suna_mishkat"
    fun p(c:Context)=c.getSharedPreferences(P,Context.MODE_PRIVATE)
    fun saveDay(c:Context,day:PrayerRepository.Day){
        p(c).edit().putString("date",day.date).putString("city",day.city).putString("country",day.country)
            .putString("Fajr",day.prayers[0].time).putString("Dhuhr",day.prayers[1].time).putString("Asr",day.prayers[2].time)
            .putString("Maghrib",day.prayers[3].time).putString("Isha",day.prayers[4].time).apply()
    }
    fun cached(c:Context,date:String):PrayerRepository.Day?{
        val s=p(c); if(s.getString("date",null)!=date)return null
        val names=listOf("Fajr" to "الفجر","Dhuhr" to "الظهر","Asr" to "العصر","Maghrib" to "المغرب","Isha" to "العشاء")
        return PrayerRepository.Day(date,names.map{PrayerRepository.Prayer(it.first,it.second,s.getString(it.first,"")?:(""))},s.getString("city","Oran")!!,s.getString("country","Algeria")!!)
    }
    fun enabled(c:Context)=p(c).getBoolean("adhan_enabled",true)
    fun setEnabled(c:Context,v:Boolean)=p(c).edit().putBoolean("adhan_enabled",v).apply()
    fun volume(c:Context)=p(c).getInt("adhan_volume",85)/100f
    fun setVolume(c:Context,v:Int)=p(c).edit().putInt("adhan_volume",v.coerceIn(0,100)).apply()
}
