package com.chaibcalligraphy.sunamishkat

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.math.*

class MainActivity:ComponentActivity(),SensorEventListener{
 private lateinit var root:LinearLayout; private lateinit var title:TextView; private val exec=Executors.newSingleThreadExecutor()
 private var sensor:SensorManager?=null; private var compass:TextView?=null; private var qibla=0f
 private val green=0xff123b35.toInt(); private val gold=0xffd8b65a.toInt(); private val bg=0xfff6f3ea.toInt(); private val text=0xff17302c.toInt()
 override fun onCreate(b:Bundle?){super.onCreate(b);window.statusBarColor=0xff0c1716.toInt();buildShell();requestNotification();loadAndSchedule();home()}
 private fun buildShell(){
   root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);layoutDirection=View.LAYOUT_DIRECTION_RTL}
   val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(20,18,20,14);setBackgroundColor(green)}
   val logo=ImageView(this).apply{setImageResource(R.drawable.ic_mishkat);layoutParams=LinearLayout.LayoutParams(46,46)};bar.addView(logo)
   title=TextView(this).apply{text=AppConfig.APP_NAME;textSize=21f;setTextColor(0xffffffff.toInt());setTypeface(null,1);gravity=Gravity.CENTER_VERTICAL;setPadding(12,0,0,0)}
   bar.addView(title,LinearLayout.LayoutParams(0,56,1f));val settings=TextView(this).apply{text="⚙";textSize=25f;setTextColor(gold);setOnClickListener{settings()}};bar.addView(settings,LinearLayout.LayoutParams(50,56))
   root.addView(bar)
   val scroll=ScrollView(this); val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,18,16,90)};scroll.addView(content);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));
   val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setBackgroundColor(0xffffffff.toInt());setPadding(8,6,8,8)}
   listOf("الرئيسية" to {home()},"الصلاة" to {prayer()},"القرآن" to {quran()},"الأذكار" to {adhkar()},"المزيد" to {more()}).forEach{(n,a)->nav.addView(MaterialButton(this).apply{text=n;textSize=11f;setOnClickListener{a()}},LinearLayout.LayoutParams(0,54,1f))}
   root.addView(nav);setContentView(root);this.content=content
 }
 private lateinit var content:LinearLayout
 private fun clear(){content.removeAllViews()}
 private fun tv(s:String,size:Float=16f,bold:Boolean=false):TextView=TextView(this).apply{text=s;textSize=size;setTextColor(text);setTypeface(null,if(bold)1 else 0);setPadding(4,4,4,4);gravity=Gravity.RIGHT}
 private fun card(title:String,sub:String,icon:String,click:()->Unit):View=MaterialCardView(this).apply{radius=24f;cardElevation=1f;setCardBackgroundColor(0xffffffff.toInt());setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,110).apply{setMargins(0,7,0,7)};addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(18,10,18,10);addView(tv(icon,32f),LinearLayout.LayoutParams(54,80));addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;addView(tv(title,18f,true));addView(tv(sub,13f))},LinearLayout.LayoutParams(0,90,1f))})}
 private fun hero():View=MaterialCardView(this).apply{radius=30f;setCardBackgroundColor(green);layoutParams=LinearLayout.LayoutParams(-1,185).apply{setMargins(0,0,0,12)};addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(22,18,22,18);addView(tv("سُنا مِشكاة",27f,true).apply{setTextColor(0xffffffff.toInt())});addView(tv("نورٌ في يومك، وطمأنينةٌ في قلبك",15f).apply{setTextColor(0xffe8e1c9.toInt());setPadding(4,4,4,12)});addView(tv("جاري تحميل مواقيت الصلاة…",15f,true).apply{setTextColor(gold);tag="next"});addView(MaterialButton(this@MainActivity).apply{text="🔔 تفعيل الأذان";setOnClickListener{enableAlarms()}})})}
 private fun home(){clear();title.text=AppConfig.APP_NAME;content.addView(hero());content.addView(tv("ماذا تريد أن تفعل؟",20f,true));content.addView(card("مواقيت الصلاة","مواقيت اليوم والعد التنازلي","🕌"){prayer()});content.addView(card("القرآن الكريم","قراءة السور والاستماع إليها","📖"){quran()});content.addView(card("الأذكار والأدعية","أذكار الصباح والمساء والأدعية","🤲"){adhkar()});content.addView(card("الحديث","صحيح البخاري وصحيح مسلم","📚"){hadith()});content.addView(card("القبلة","اتجاه القبلة باستخدام بوصلة الهاتف","🧭"){qibla()});content.addView(card("التقويم الهجري","التاريخ الهجري والميلادي","🌙"){calendar()});loadPrayerPreview()}
 private fun loadAndSchedule(){exec.execute{try{val d=PrayerRepository.today();Prefs.saveDay(this,d);AdhanScheduler.scheduleDay(this,d)}catch(_:Exception){}}}
 private fun loadPrayerPreview(){exec.execute{try{val d=PrayerRepository.today();runOnUiThread{val n=next(d);content.findViewWithTag<TextView>("next")?.text="الصلاة القادمة: ${n.first} · ${n.second}"}}catch(_:Exception){}}}
 private fun next(d:PrayerRepository.Day):Pair<String,String>{val now=Calendar.getInstance();val sec=now.get(Calendar.HOUR_OF_DAY)*3600+now.get(Calendar.MINUTE)*60;for(p in d.prayers){val x=p.time.split(":");val t=x[0].toInt()*3600+x[1].toInt()*60;if(t>sec)return p.title to p.time};return d.prayers.first().title to d.prayers.first().time}
 private fun prayer(){clear();title.text="مواقيت الصلاة";content.addView(tv("مواقيت الصلاة",26f,true));content.addView(tv("وهران، الجزائر",15f));val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(box)
   exec.execute{try{val d=PrayerRepository.today();Prefs.saveDay(this,d);AdhanScheduler.scheduleDay(this,d);runOnUiThread{d.prayers.forEach{p->val r=MaterialCardView(this).apply{radius=20f;setCardBackgroundColor(0xffffffff.toInt());layoutParams=LinearLayout.LayoutParams(-1,76).apply{setMargins(0,5,0,5)};addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(18,5,18,5);addView(tv(p.title,17f,true),LinearLayout.LayoutParams(0,66,1f));addView(tv(p.time,22f,true))})};box.addView(r)};content.addView(MaterialButton(this).apply{text="🔊 تجربة الأذان بعد 10 ثوانٍ";setOnClickListener{AdhanScheduler.test(this@MainActivity,10);toast("سيبدأ الأذان بعد 10 ثوانٍ حتى مع قفل الشاشة")}})}}catch(e:Exception){runOnUiThread{box.addView(tv("تعذر تحميل المواقيت: ${e.message}",15f))}}}
 }
 private fun enableAlarms(){if(!AdhanScheduler.exactAllowed(this)){MaterialAlertDialogBuilder(this).setTitle("السماح بالأذان الدقيق").setMessage("يحتاج سُنا مِشكاة إلى إذن «المنبهات والتذكيرات» ليوقظ الهاتف في وقت الصلاة حتى عند قفل الشاشة.").setPositiveButton("فتح الإعدادات"){_,_->AdhanScheduler.requestExact(this)}.setNegativeButton("لاحقاً",null).show()}else{toast("الأذان مفعّل وسيعمل في الخلفية");AdhanScheduler.test(this,10)}}
 private fun quran(){clear();title.text="القرآن الكريم";content.addView(tv("السور",26f,true));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(list);exec.execute{try{val a=PrayerRepository.quran();runOnUiThread{for(i in 0 until a.length()){val o=a.getJSONObject(i);val id=o.optInt("number");list.addView(card("${o.optString("name")}","${o.optString("englishName","")} · ${o.optInt("numberOfAyahs")} آية","${id}"){surah(id)})}}}catch(e:Exception){runOnUiThread{list.addView(tv("تعذر تحميل السور. ${e.message}"))}}}}
 private fun surah(id:Int){clear();title.text="القرآن الكريم";content.addView(MaterialButton(this).apply{text="‹ رجوع إلى السور";setOnClickListener{quran()}});val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(body);exec.execute{try{val o=PrayerRepository.surah(id,"ar.alafasy");runOnUiThread{body.addView(tv(o.optString("name","السورة"),27f,true));body.addView(MaterialButton(this).apply{text="▶ الاستماع للسورة";setOnClickListener{startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse(o.optJSONObject("audio")?.optString("url")?:"")))}});val a=o.optJSONArray("ayahs");if(a!=null)for(i in 0 until a.length()){val x=a.getJSONObject(i);body.addView(MaterialCardView(this).apply{radius=18f;setCardBackgroundColor(0xffffffff.toInt());layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)};addView(tv("${x.optInt("numberInSurah")}. ${x.optString("text")}",20f))})}}}catch(e:Exception){runOnUiThread{body.addView(tv("تعذر تحميل السورة. ${e.message}"))}}}}
 private fun adhkar(){clear();title.text="الأذكار";content.addView(tv("الأذكار والأدعية",26f,true));val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};content.addView(tabs);val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(body);fun load(path:String){body.removeAllViews();exec.execute{try{val a=if(path=="duas")PrayerRepository.duas() else PrayerRepository.adhkar();runOnUiThread{for(i in 0 until a.length()){val o=a.getJSONObject(i);body.addView(MaterialCardView(this).apply{radius=20f;setCardBackgroundColor(0xffffffff.toInt());layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)};addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(16,10,16,10);addView(tv(o.optString("title"),18f,true));addView(tv(o.optString("content"),17f))})})}}}catch(e:Exception){runOnUiThread{body.addView(tv("تعذر تحميل المحتوى."))}}}};tabs.addView(MaterialButton(this).apply{text="الأذكار";setOnClickListener{load("adhkar")}});tabs.addView(MaterialButton(this).apply{text="الأدعية";setOnClickListener{load("duas")}});load("adhkar")}
 private fun hadith(){clear();title.text="الحديث";content.addView(tv("صحيح البخاري ومسلم",26f,true));val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};content.addView(tabs);val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(body);fun load(c:String){body.removeAllViews();exec.execute{try{val a=PrayerRepository.hadith(c);runOnUiThread{for(i in 0 until min(a.length(),80)){val o=a.getJSONObject(i);body.addView(MaterialCardView(this).apply{radius=20f;setCardBackgroundColor(0xffffffff.toInt());layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)};addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(16,10,16,10);addView(tv(o.optString("title"),18f,true));addView(tv(o.optString("content"),17f));addView(tv("${o.optString("book","")} ${o.optString("number","")}",12f))})})}}}catch(_:Exception){runOnUiThread{body.addView(tv("تعذر تحميل الأحاديث."))}}}};tabs.addView(MaterialButton(this).apply{text="البخاري";setOnClickListener{load("bukhari")}});tabs.addView(MaterialButton(this).apply{text="مسلم";setOnClickListener{load("muslim")}});load("bukhari")}
 private fun calendar(){clear();title.text="التقويم";content.addView(tv("التقويم الهجري",26f,true));exec.execute{try{val o=PrayerRepository.calendar();runOnUiThread{content.addView(card("${o.optJSONObject("hijri")?.optString("day")} ${o.optJSONObject("hijri")?.optJSONObject("month")?.optString("ar")}","${o.optJSONObject("hijri")?.optString("year")} هـ · ${o.optJSONObject("gregorian")?.optString("date")} م","🌙"){})}}catch(_:Exception){runOnUiThread{content.addView(tv("تعذر تحميل التقويم."))}}}}
 private fun qibla(){clear();title.text="القبلة";content.addView(tv("اتجاه القبلة",27f,true));compass=tv("🧭\nجارٍ تحديد الاتجاه…",28f,true).apply{gravity=Gravity.CENTER;textAlignment=View.TEXT_ALIGNMENT_CENTER;setPadding(10,70,10,70)};content.addView(compass,LinearLayout.LayoutParams(-1,260));content.addView(tv("اسمح للتطبيق بالوصول إلى موقع الهاتف لحساب اتجاه القبلة بدقة.",15f));content.addView(MaterialButton(this).apply{text="تحديد موقعي";setOnClickListener{requestLocation()}});startCompass()}
 private fun requestLocation(){if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),51);return};val lm=getSystemService(LocationManager::class.java);val p=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?:lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);if(p!=null)calculateQibla(p) else toast("تعذر الحصول على الموقع. فعّل GPS ثم جرّب مرة أخرى")}
 private fun calculateQibla(l:Location){val phi1=Math.toRadians(l.latitude);val phi2=Math.toRadians(21.422487);val dl=Math.toRadians(39.826206-l.longitude);qibla=((Math.toDegrees(atan2(sin(dl),cos(phi1)*tan(phi2)-sin(phi1)*cos(dl)))+360)%360).toFloat();compass?.text="🧭\nالقبلة: ${qibla.roundToInt()}°"}
 private fun startCompass(){sensor=getSystemService(SENSOR_SERVICE) as SensorManager;sensor?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.let{sensor?.registerListener(this,it,SensorManager.SENSOR_DELAY_UI)}}
 override fun onSensorChanged(e:SensorEvent){if(e.sensor.type!=Sensor.TYPE_ROTATION_VECTOR)return;val r=FloatArray(9);SensorManager.getRotationMatrixFromVector(r,e.values);val o=FloatArray(3);SensorManager.getOrientation(r,o);val az=(Math.toDegrees(o[0].toDouble()).toFloat()+360)%360;val diff=((qibla-az+540)%360)-180;if(qibla>0)compass?.text="🧭\nالقبلة ${qibla.roundToInt()}°\n${if(abs(diff)<5)"✓ الهاتف باتجاه القبلة" else "حرّك الهاتف ${if(diff>0)"يميناً" else "يساراً"}"}"}
 override fun onAccuracyChanged(s:Sensor?,a:Int){}
 private fun more(){clear();title.text="المزيد";content.addView(tv("إعدادات سُنا مِشكاة",26f,true));content.addView(card("الأذان","تشغيل الأذان في الخلفية حتى عند قفل الشاشة","🔔"){enableAlarms()});content.addView(card("التسبيح","عداد تسبيح بسيط","📿"){tasbeeh()});content.addView(card("حول التطبيق","Abdellah Chaib · contact@chaibcalligraphy.com","ℹ️"){about()})}
 private fun tasbeeh(){clear();title.text="التسبيح";var n=0;val out=tv("0",56f,true);out.gravity=Gravity.CENTER;content.addView(tv("عداد التسبيح الإلكتروني",24f,true));content.addView(out,LinearLayout.LayoutParams(-1,170));content.addView(MaterialButton(this).apply{text="اضغط للعد";setOnClickListener{out.text=(++n).toString()}});content.addView(MaterialButton(this).apply{text="تصفير";setOnClickListener{n=0;out.text="0"}})}
 private fun settings(){more()}
 private fun about(){clear();title.text="حول سُنا مِشكاة";content.addView(tv("سُنا مِشكاة",30f,true));content.addView(tv("تطبيق إسلامي للصلاة والقرآن والأذكار والأحاديث والقبلة والتقويم.\n\nالمطور: ${AppConfig.DEVELOPER}\nالبريد: ${AppConfig.EMAIL}\nالموقع: chaibcalligraphy.com",17f))}
 private fun requestNotification(){if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),52)}
 private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
 override fun onDestroy(){sensor?.unregisterListener(this);exec.shutdownNow();super.onDestroy()}
}
