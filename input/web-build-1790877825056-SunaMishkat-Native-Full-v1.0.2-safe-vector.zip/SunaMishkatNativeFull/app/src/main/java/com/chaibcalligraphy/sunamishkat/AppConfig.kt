package com.chaibcalligraphy.sunamishkat

object AppConfig {
    const val API = "https://www.chaibcalligraphy.com/wp-json/mishkat/v1/"
    const val ADHAN_URL = "https://www.chaibcalligraphy.com/wp-content/uploads/2026/09/cbcd8d249dcc.mp3"
    const val APP_NAME = "سُنا مِشكاة"
    const val DEVELOPER = "Abdellah Chaib"
    const val EMAIL = "contact@chaibcalligraphy.com"
}
