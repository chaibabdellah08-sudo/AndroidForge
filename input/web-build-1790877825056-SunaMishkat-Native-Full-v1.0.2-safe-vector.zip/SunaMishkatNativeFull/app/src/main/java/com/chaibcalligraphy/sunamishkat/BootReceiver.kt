package com.chaibcalligraphy.sunamishkat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BootReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){
   val today=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
   Prefs.cached(context,today)?.let{AdhanScheduler.scheduleDay(context,it)} ?: AdhanScheduler.scheduleSync(context)
 }
}
