package com.chaibcalligraphy.sunamishkat

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PrayerRepository {
    data class Prayer(val key:String,val title:String,val time:String)
    data class Day(val date:String,val prayers:List<Prayer>,val city:String,val country:String)

    private fun get(path:String):String {
        val c=URL(AppConfig.API+path).openConnection() as HttpURLConnection
        c.requestMethod="GET"; c.connectTimeout=12000; c.readTimeout=15000
        c.setRequestProperty("Accept","application/json")
        return c.inputStream.bufferedReader().use{it.readText()}.also{c.disconnect()}
    }
    fun today(date:String = SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())):Day {
        val q= "prayer-times?date=$date"
        val o=JSONObject(get(q)); val t=o.getJSONObject("timings"); val loc=o.getJSONObject("location")
        val names=listOf("Fajr" to "الفجر","Dhuhr" to "الظهر","Asr" to "العصر","Maghrib" to "المغرب","Isha" to "العشاء")
        return Day(date,names.map{(k,n)->Prayer(k,n,clean(t.optString(k)))},loc.optString("city","Oran"),loc.optString("country","Algeria"))
    }
    fun config():JSONObject = JSONObject(get("app-config"))
    fun home():JSONObject = JSONObject(get("home"))
    fun quran():org.json.JSONArray = org.json.JSONArray(get("quran/surahs"))
    fun surah(id:Int,reciter:String):JSONObject = JSONObject(get("quran/surah/$id?reciter=$reciter"))
    fun adhkar():org.json.JSONArray = org.json.JSONArray(get("adhkar"))
    fun duas():org.json.JSONArray = org.json.JSONArray(get("duas"))
    fun hadith(collection:String=""):org.json.JSONArray = org.json.JSONArray(get("hadith?collection=$collection"))
    fun calendar():JSONObject = JSONObject(get("calendar"))
    private fun clean(v:String):String = v.substringBefore(" ").trim()
}
