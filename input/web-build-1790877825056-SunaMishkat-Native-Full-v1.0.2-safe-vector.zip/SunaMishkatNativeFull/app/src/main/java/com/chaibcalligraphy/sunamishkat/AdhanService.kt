package com.chaibcalligraphy.sunamishkat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.IOException

class AdhanService:Service(){
 companion object { const val ACTION_PLAY="com.chaibcalligraphy.sunamishkat.PLAY"; const val ACTION_STOP="com.chaibcalligraphy.sunamishkat.STOP"; const val CHANNEL="adhan_playback" }
 private var player:MediaPlayer?=null
 override fun onCreate(){super.onCreate();createChannel()}
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
   if(intent?.action==ACTION_STOP){stopSelf();return START_NOT_STICKY}
   val prayer=intent?.getStringExtra("prayer")?:""
   startForeground(7001,notification(prayer))
   play(prayer);return START_NOT_STICKY
 }
 private fun createChannel(){
   if(Build.VERSION.SDK_INT>=26){getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"أذان سُنا مِشكاة",NotificationManager.IMPORTANCE_HIGH).apply{description="تشغيل الأذان في الخلفية"})}
 }
 private fun notification(prayer:String):Notification{
   val stop=PendingIntent.getService(this,7002,Intent(this,AdhanService::class.java).setAction(ACTION_STOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
   val open=PendingIntent.getActivity(this,7003,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
   val name=when(prayer){"Fajr"->"الفجر";"Dhuhr"->"الظهر";"Asr"->"العصر";"Maghrib"->"المغرب";"Isha"->"العشاء";else->"تجربة الأذان"}
   return NotificationCompat.Builder(this,CHANNEL).setSmallIcon(com.chaibcalligraphy.sunamishkat.R.drawable.ic_stat_adhan).setContentTitle("سُنا مِشكاة · $name").setContentText("حان الآن وقت الأذان").setContentIntent(open).setOngoing(true).setPriority(NotificationCompat.PRIORITY_HIGH).addAction(android.R.drawable.ic_media_pause,"إيقاف",stop).build()
 }
 private fun play(prayer:String){
   player?.release();player=null
   val p=MediaPlayer()
   p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
   p.setVolume(Prefs.volume(this),Prefs.volume(this))
   p.setDataSource(AppConfig.ADHAN_URL)
   p.setOnPreparedListener{it.start()}
   p.setOnCompletionListener{stopSelf()}
   p.setOnErrorListener{_,_,_->stopSelf();true}
   player=p
   try{p.prepareAsync()}catch(_:IOException){stopSelf()}
 }
 override fun onDestroy(){player?.stop();player?.release();player=null;stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
}
