package com.chaibcalligraphy.sunamishkat;
public final class AppConfig {
 public static final String ADHAN_URL=AdhanAudioCache.REGULAR_URL;
 private AppConfig(){}
}
