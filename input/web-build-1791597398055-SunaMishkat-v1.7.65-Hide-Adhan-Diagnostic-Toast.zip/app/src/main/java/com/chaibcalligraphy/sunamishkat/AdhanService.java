package com.chaibcalligraphy.sunamishkat;

import android.app.*;
import android.content.*;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.*;
import android.os.*;
import android.widget.RemoteViews;

public class AdhanService extends Service {
    static final int NOTIF=1441;
    private static AdhanService instance;
    private boolean notificationHidden=false;
    public static final String ACTION_FINISHED="com.chaibcalligraphy.sunamishkat.ADHAN_FINISHED";
    private MediaPlayer player;
    private boolean finished=false;
    private boolean started=false;
    private String currentPrayer="";
    private String currentMessage="";
    private String currentSoundUrl="";
    private boolean testMode=false;
    private final Handler durationHandler = new Handler(Looper.getMainLooper());
    private final Runnable durationStop = this::finishAdhan;

    @Override public void onCreate(){
        super.onCreate();
        instance=this;
        String ch="suna_adhan_v3";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel nc=new NotificationChannel(ch,"الأذان | Adhan",NotificationManager.IMPORTANCE_HIGH);
            nc.setDescription("تنبيه صغير للأذان وتشغيله في وقت الصلاة");
            nc.enableLights(true);
            nc.setLightColor(Color.rgb(47,207,107));
            nc.setVibrationPattern(new long[]{0,180,90,180});
            nc.setSound(null,null);
            nc.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(nc);
        }
        startForeground(NOTIF,buildNotification(ch));
    }

    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null && i.hasExtra("prayer")) currentPrayer=i.getStringExtra("prayer");
        durationHandler.removeCallbacks(durationStop);
        if(i!=null){
            testMode=i.getBooleanExtra("test", false);
            currentMessage=i.getStringExtra("message");
            if(currentMessage==null) currentMessage="";
            currentSoundUrl=i.getStringExtra("sound_url");
            if(currentSoundUrl==null) currentSoundUrl="";
            if(testMode){
                int seconds=i.getIntExtra("duration",0);
                if(seconds>0){durationHandler.removeCallbacks(durationStop);durationHandler.postDelayed(durationStop,seconds*1000L);}
            }
        }
        if(!started){
            started=true;
        } else {
            if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}
            finished=false;
        }
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF,buildNotification(chName()));
        startPlayer();
        return START_NOT_STICKY;
    }

    private String chName(){return "suna_adhan_v3";}

    private Notification buildNotification(String ch){
        Intent stop=new Intent(this,AdhanStopReceiver.class);
        PendingIntent stopPi=PendingIntent.getBroadcast(this,1443,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);

        RemoteViews compact=new RemoteViews(getPackageName(),R.layout.notification_adhan);
        compact.setImageViewResource(R.id.adhan_notification_logo,R.drawable.suna_mishkat_icon);
        compact.setTextViewText(R.id.adhan_notification_title,"الأذان | Adhan");
        compact.setTextViewText(R.id.adhan_notification_prayer,displayNotificationText());
        compact.setOnClickPendingIntent(R.id.adhan_notification_stop,stopPi);

        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ch):new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_stop_adhan)
         .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.suna_mishkat_icon))
         .setContentTitle("الأذان | Adhan")
         .setContentText(displayNotificationText())
         .setSubText("سُنا مِشكاة")
         .setColor(Color.rgb(47,207,107))
         .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_HIGH)
         .setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true)
         .setAutoCancel(false)
         .setCustomContentView(compact)
         .setCustomHeadsUpContentView(compact)
         .addAction(new Notification.Action.Builder(R.drawable.ic_stat_stop_adhan,"إيقاف الأذان | Stop",stopPi).build());
        return b.build();
    }

    private String displayNotificationText(){
        return currentMessage.trim().isEmpty() ? prayerName(currentPrayer) : currentMessage.trim();
    }

    private void startPlayer(){
        player=new MediaPlayer();
        try{
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            android.content.SharedPreferences remote=getSharedPreferences("adhan_remote_config",MODE_PRIVATE);
            String prayerKey=currentPrayer==null?"":currentPrayer.toLowerCase(java.util.Locale.ROOT);
            float volume=remote.getInt("volume",85)/100f;
            player.setVolume(volume,volume);
            // Prefer the cached local recording. Fajr has its own recording; all other prayers share the regular adhan.
            String url = getIntentAudioUrl(remote, prayerKey);
            java.io.File cached=AdhanAudioCache.cachedFile(this, prayerKey);
            if(AdhanAudioCache.isCachedForUrl(this, prayerKey, url)){
                player.setDataSource(cached.getAbsolutePath());
            }else{
                // If the selected recording changed, never play the stale cached file.
                // Stream the selected URL online; a background cache refresh will save it for offline use.
                player.setDataSource(url);
                AdhanAudioCache.warmUp(getApplicationContext(),
                    remote.getString("fajr_url", AdhanAudioCache.FAJR_URL),
                    remote.getString("regular_url", AdhanAudioCache.REGULAR_URL));
            }
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(p->finishAdhan());
            player.setOnErrorListener((mp, what, extra) -> { finishAdhan(); return true; });
            player.prepareAsync();
        }catch(Exception e){finishAdhan();}
    }

    private String getIntentAudioUrl(android.content.SharedPreferences remote, String prayerKey){
        if(testMode && currentSoundUrl.startsWith("https://")) return currentSoundUrl;
        String configured = remote.getString(prayerKey + "_url", "");
        if(configured.startsWith("https://")) return configured;
        String selected = AdhanAudioCache.urlForPrayer(prayerKey);
        return selected;
    }

    private String prayerName(String p){
        if(p==null||p.trim().isEmpty())return "الأذان";
        switch(p.toLowerCase()){
            case "fajr":return "الفجر | Fajr";
            case "dhuhr":return "الظهر | Dhuhr";
            case "asr":return "العصر | Asr";
            case "maghrib":return "المغرب | Maghrib";
            case "isha":return "العشاء | Isha";
            default:return p;
        }
    }

    private void finishAdhan(){
        if(finished)return; finished=true;
        durationHandler.removeCallbacks(durationStop);
        try{sendBroadcast(new Intent(ACTION_FINISHED).setPackage(getPackageName()));}catch(Exception ignored){}
        stopForeground(true); stopSelf();
    }

    @Override public android.os.IBinder onBind(Intent i){return null;}
    public static void hideForAlert(){
        AdhanService s=instance;
        if(s!=null) s.hideNotification();
    }
    public static void showAfterAlert(){
        AdhanService s=instance;
        if(s!=null) s.showNotification();
    }
    private void hideNotification(){
        if(notificationHidden)return;
        notificationHidden=true;
        if(Build.VERSION.SDK_INT>=24){
            try{stopForeground(STOP_FOREGROUND_REMOVE);}catch(Exception ignored){}
        }else{try{stopForeground(true);}catch(Exception ignored){}}
    }
    private void showNotification(){
        if(!notificationHidden || finished)return;
        notificationHidden=false;
        try{startForeground(NOTIF,buildNotification(chName()));}catch(Exception ignored){}
    }
    @Override public void onDestroy(){
        instance=null;
        if(player!=null){try{player.release();}catch(Exception ignored){}}
        super.onDestroy();
    }
}
