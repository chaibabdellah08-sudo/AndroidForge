package com.chaibcalligraphy.sunamishkat;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Downloads both adhan recordings once so scheduled playback can work offline. */
public final class AdhanAudioCache {
    private static final String TAG = "AdhanAudioCache";
    public static final String FAJR_URL = "https://www.chaibcalligraphy.com/wp-content/uploads/2026/09/1003.mp3";
    public static final String REGULAR_URL = "https://www.chaibcalligraphy.com/wp-content/uploads/2026/09/cbcd8d249dcc.mp3";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private AdhanAudioCache() {}

    public static File cachedFile(Context context, String prayer) {
        File dir = new File(context.getFilesDir(), "adhan-audio");
        return new File(dir, isFajr(prayer) ? "adhan-fajr.mp3" : "adhan-regular.mp3");
    }

    public static String urlForPrayer(String prayer) {
        return isFajr(prayer) ? FAJR_URL : REGULAR_URL;
    }

    public static void warmUp(Context context) {
        android.content.SharedPreferences p = context.getSharedPreferences("adhan_remote_config", Context.MODE_PRIVATE);
        String fajrUrl = p.getString("fajr_url", FAJR_URL);
        String regularUrl = p.getString("regular_url", REGULAR_URL);
        warmUp(context, fajrUrl, regularUrl);
    }

    public static void warmUp(Context context, String fajrUrl, String regularUrl) {
        Context app = context.getApplicationContext();
        final String f = validUrl(fajrUrl) ? fajrUrl : FAJR_URL;
        final String r = validUrl(regularUrl) ? regularUrl : REGULAR_URL;
        EXECUTOR.execute(() -> {
            downloadIfNeeded(app, true, f);
            downloadIfNeeded(app, false, r);
        });
    }

    public static boolean isCachedForUrl(Context context, String prayer, String url) {
        if (!validUrl(url)) return false;
        File file = cachedFile(context, prayer);
        if (!file.isFile() || file.length() <= 4096) return false;
        String saved = context.getSharedPreferences("adhan_audio_cache", Context.MODE_PRIVATE)
                .getString(file.getName() + "_url", "");
        return url.equals(saved);
    }

    private static void downloadIfNeeded(Context context, boolean fajr, String url) {
        File target = cachedFile(context, fajr ? "fajr" : "dhuhr");
        if (target.isFile() && target.length() > 4096 && isCachedForUrl(context, fajr ? "fajr" : "dhuhr", url)) return;
        File dir = target.getParentFile();
        if (dir == null || (!dir.exists() && !dir.mkdirs())) return;
        File temp = new File(dir, target.getName() + ".part");
        HttpURLConnection connection = null;
        try {
            URL urlObj = new URL(url);
            connection = (HttpURLConnection) urlObj.openConnection();
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "SunaMishkat-Android");
            connection.connect();
            if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 300) {
                throw new java.io.IOException("HTTP " + connection.getResponseCode());
            }
            try (InputStream in = connection.getInputStream(); FileOutputStream out = new FileOutputStream(temp)) {
                byte[] buffer = new byte[16 * 1024];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                out.getFD().sync();
            }
            if (temp.length() > 4096) {
                if (target.exists()) target.delete();
                if (!temp.renameTo(target)) throw new java.io.IOException("Could not store cached adhan");
                context.getSharedPreferences("adhan_audio_cache", Context.MODE_PRIVATE).edit()
                        .putString(target.getName() + "_url", url).apply();
                Log.i(TAG, "Cached " + target.getName() + " bytes=" + target.length());
            } else {
                throw new java.io.IOException("Audio file is empty or too small");
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not cache " + (fajr ? "Fajr" : "regular") + " adhan; it will retry next launch", e);
            // A partial download must never be used as an audio source.
            // Keep an existing valid cache untouched.
            if (temp.exists()) temp.delete();
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static boolean validUrl(String value) {
        return value != null && (value.startsWith("https://") || value.startsWith("http://"));
    }

    private static boolean isFajr(String prayer) {
        return prayer != null && "fajr".equalsIgnoreCase(prayer.trim());
    }
}
