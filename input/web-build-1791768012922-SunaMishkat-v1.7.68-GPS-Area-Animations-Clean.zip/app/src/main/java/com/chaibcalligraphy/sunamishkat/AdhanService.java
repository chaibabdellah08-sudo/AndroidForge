package com.chaibcalligraphy.sunamishkat;

import android.app.*;
import android.content.*;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.*;
import android.os.*;
import android.widget.RemoteViews;

public class AdhanService extends Service {
    static final int NOTIF = 1441;
    private static final String CHANNEL_ID = "suna_adhan_v4_heads_up";
    public static final String ACTION_FINISHED = "com.chaibcalligraphy.sunamishkat.ADHAN_FINISHED";

    private static AdhanService instance;
    private MediaPlayer player;
    private boolean finished = false;
    private boolean started = false;
    private String currentPrayer = "";
    private int displayHour = -1;
    private int displayMinute = -1;

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "الأذان • تنبيه بارز", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("إشعار بارز للأذان مع شعار سُنا مشكاة وزر التحكم في التشغيل");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setShowBadge(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            if (intent.hasExtra("prayer")) {
                String prayer = intent.getStringExtra("prayer");
                if (prayer != null) currentPrayer = prayer;
            }
            if (intent.hasExtra("display_hour")) displayHour = intent.getIntExtra("display_hour", -1);
            if (intent.hasExtra("display_minute")) displayMinute = intent.getIntExtra("display_minute", -1);
        }

        if (!started) {
            started = true;
            startForeground(NOTIF, buildNotification());
            startPlayer();
        } else {
            updateNotification();
        }
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        RemoteViews banner = new RemoteViews(getPackageName(), R.layout.notification_adhan);
        banner.setTextViewText(R.id.adhan_notification_title, "الأذان | Adhan");
        banner.setTextViewText(R.id.adhan_notification_prayer, prayerNameBilingual(currentPrayer));
        banner.setImageViewResource(R.id.adhan_notification_stop,
                R.drawable.ic_stat_stop_adhan);
        banner.setContentDescription(R.id.adhan_notification_stop,
                "إيقاف الأذان | Stop Adhan");
        banner.setImageViewResource(R.id.adhan_notification_logo,
                R.drawable.suna_mishkat_icon);

        Intent open = new Intent(this, AdhanAlertActivity.class)
                .putExtra("prayer", currentPrayer)
                .putExtra("display_hour", displayHour)
                .putExtra("display_minute", displayMinute)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPending = PendingIntent.getActivity(this, 1442, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stopAndExit = new Intent(this, AdhanStopReceiver.class)
                .setAction(AdhanStopReceiver.ACTION_STOP_AND_EXIT)
                .setPackage(getPackageName());
        PendingIntent stopPending = PendingIntent.getBroadcast(this, 1444, stopAndExit,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        banner.setOnClickPendingIntent(R.id.adhan_notification_stop, stopPending);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        builder.setContentTitle("الأذان | Adhan")
                .setContentText(prayerNameBilingual(currentPrayer))
                .setTicker("سُنا مشكاة • حان وقت الأذان")
                .setSmallIcon(R.drawable.ic_stat_adhan)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.suna_mishkat_icon))
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setColor(Color.rgb(11, 107, 58))
                .setColorized(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setContentIntent(openPending)
                .setCustomContentView(banner)
                .setCustomBigContentView(banner)
                .setCustomHeadsUpContentView(banner);
        return builder.build();
    }

    private void updateNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null && started && !finished) nm.notify(NOTIF, buildNotification());
    }

    private void startPlayer() {
        player = new MediaPlayer();
        try {
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(AppConfig.ADHAN_URL);
            player.setOnPreparedListener(p -> {
                try { p.start(); } catch (IllegalStateException ignored) { finishAdhan(); }
                updateNotification();
            });
            player.setOnCompletionListener(p -> finishAdhan());
            player.setOnErrorListener((p, what, extra) -> { finishAdhan(); return true; });
            player.prepareAsync();
        } catch (Exception e) {
            finishAdhan();
        }
    }

    private String prayerNameBilingual(String prayer) {
        if (prayer == null) prayer = "";
        switch (prayer.toLowerCase(java.util.Locale.US)) {
            case "fajr": return "الفجر | Fajr";
            case "dhuhr": return "الظهر | Dhuhr";
            case "asr": return "العصر | Asr";
            case "maghrib": return "المغرب | Maghrib";
            case "isha": return "العشاء | Isha";
            default: return "الصلاة | Prayer";
        }
    }

    private void finishAdhan() {
        if (finished) return;
        finished = true;
        try { sendBroadcast(new Intent(ACTION_FINISHED).setPackage(getPackageName())); }
        catch (Exception ignored) { }
        stopForeground(true);
        stopSelf();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        instance = null;
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }
}
