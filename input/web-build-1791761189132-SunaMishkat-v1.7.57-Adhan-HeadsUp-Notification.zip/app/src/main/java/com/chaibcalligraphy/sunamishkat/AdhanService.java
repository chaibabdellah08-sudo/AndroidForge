package com.chaibcalligraphy.sunamishkat;

import android.app.*;
import android.content.*;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.*;
import android.os.*;
import android.widget.RemoteViews;

public class AdhanService extends Service {
    static final int NOTIF = 1441;
    private static final String CHANNEL_ID = "suna_adhan_v4_heads_up";
    public static final String ACTION_FINISHED = "com.chaibcalligraphy.sunamishkat.ADHAN_FINISHED";
    private static final String ACTION_TOGGLE_PLAYBACK = "com.chaibcalligraphy.sunamishkat.TOGGLE_ADHAN_PLAYBACK";

    private static AdhanService instance;
    private MediaPlayer player;
    private boolean finished = false;
    private boolean started = false;
    private boolean prepared = false;
    private boolean paused = false;
    private String currentPrayer = "";

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        // A fresh channel ID is intentional: Android will not let an app raise the
        // importance of an existing channel that was created as DEFAULT/MIN.
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "الأذان • تنبيه بارز", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("إشعار بارز للأذان مع شعار سُنا مشكاة وزر التحكم في التشغيل");
        channel.setSound(null, null); // The adhan stream itself is the audio; avoid a second notification sound.
        channel.enableVibration(false);
        channel.setShowBadge(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("prayer")) {
            String prayer = intent.getStringExtra("prayer");
            if (prayer != null) currentPrayer = prayer;
        }

        if (!started) {
            started = true;
            // Post the final, prayer-specific notification only once so the first
            // heads-up presentation contains the correct bilingual prayer name.
            startForeground(NOTIF, buildNotification());
            startPlayer();
        } else {
            updateNotification();
        }
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        RemoteViews banner = new RemoteViews(getPackageName(), R.layout.notification_adhan);
        banner.setTextViewText(R.id.adhan_notification_title, "Adhan | الأذان");
        banner.setTextViewText(R.id.adhan_notification_prayer, prayerNameBilingual(currentPrayer));
        banner.setTextViewText(R.id.adhan_notification_pause_label, paused ? "▶" : "Ⅱ");
        banner.setContentDescription(R.id.adhan_notification_pause_label,
                paused ? "استئناف الأذان" : "إيقاف مؤقت للأذان");
        banner.setImageViewResource(R.id.adhan_notification_logo,
                R.drawable.suna_mishkat_icon);

        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPending = PendingIntent.getActivity(this, 1442, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent toggle = new Intent(this, AdhanStopReceiver.class)
                .setAction(ACTION_TOGGLE_PLAYBACK)
                .setPackage(getPackageName());
        PendingIntent togglePending = PendingIntent.getBroadcast(this, 1444, toggle,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        banner.setOnClickPendingIntent(R.id.adhan_notification_pause, togglePending);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setContentTitle("Adhan | الأذان")
                .setContentText(prayerNameBilingual(currentPrayer))
                .setTicker("سُنا مشكاة • حان وقت الأذان")
                .setSmallIcon(R.drawable.ic_stat_adhan)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.suna_mishkat_icon))
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setColor(Color.rgb(5, 112, 67))
                .setColorized(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setContentIntent(openPending)
                .setCustomContentView(banner)
                .setCustomBigContentView(banner)
                .setCustomHeadsUpContentView(banner);
        return builder.build();
    }

    private void updateNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null && started && !finished) nm.notify(NOTIF, buildNotification());
    }

    public static void togglePlayback(Context context) {
        AdhanService service = instance;
        if (service != null) service.togglePlaybackInternal();
    }

    private void togglePlaybackInternal() {
        if (finished) return;
        if (!prepared) {
            // If the button is pressed before the streaming audio is prepared,
            // remember the requested state and apply it in onPrepared.
            paused = !paused;
        } else if (player != null) {
            try {
                if (paused) {
                    player.start();
                    paused = false;
                } else if (player.isPlaying()) {
                    player.pause();
                    paused = true;
                } else {
                    player.start();
                    paused = false;
                }
            } catch (IllegalStateException ignored) {
                paused = false;
            }
        }
        updateNotification();
    }

    private void startPlayer() {
        player = new MediaPlayer();
        try {
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(AppConfig.ADHAN_URL);
            player.setOnPreparedListener(p -> {
                prepared = true;
                if (!paused) {
                    try { p.start(); } catch (IllegalStateException ignored) { finishAdhan(); }
                }
                updateNotification();
            });
            player.setOnCompletionListener(p -> finishAdhan());
            player.setOnErrorListener((p, what, extra) -> { finishAdhan(); return true; });
            player.prepareAsync();
        } catch (Exception e) {
            finishAdhan();
        }
    }

    private String prayerNameBilingual(String prayer) {
        if (prayer == null) prayer = "";
        switch (prayer.toLowerCase(java.util.Locale.US)) {
            case "fajr": return "Fajr | الفجر";
            case "dhuhr": return "Dhuhr | الظهر";
            case "asr": return "Asr | العصر";
            case "maghrib": return "Maghrib | المغرب";
            case "isha": return "Isha | العشاء";
            default: return "Prayer | الصلاة";
        }
    }

    private void finishAdhan() {
        if (finished) return;
        finished = true;
        try { sendBroadcast(new Intent(ACTION_FINISHED).setPackage(getPackageName())); }
        catch (Exception ignored) { }
        stopForeground(true);
        stopSelf();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        instance = null;
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }
}
