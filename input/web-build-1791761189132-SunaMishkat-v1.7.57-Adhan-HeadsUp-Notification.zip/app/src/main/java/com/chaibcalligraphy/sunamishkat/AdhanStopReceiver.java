package com.chaibcalligraphy.sunamishkat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AdhanStopReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent != null && "com.chaibcalligraphy.sunamishkat.TOGGLE_ADHAN_PLAYBACK".equals(intent.getAction())) {
            AdhanService.togglePlayback(context);
            return;
        }
        context.stopService(new Intent(context, AdhanService.class));
    }
}
