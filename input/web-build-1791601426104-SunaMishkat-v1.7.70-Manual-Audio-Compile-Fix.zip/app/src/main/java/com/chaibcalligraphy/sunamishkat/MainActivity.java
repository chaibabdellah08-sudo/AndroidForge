package com.chaibcalligraphy.sunamishkat;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.content.Intent;
import android.net.Uri;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.content.ActivityNotFoundException;
import android.widget.Toast;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Surface;
import android.view.WindowManager;
import android.icu.util.Calendar;
import android.icu.util.ULocale;
import android.hardware.GeomagneticField;

import java.util.Locale;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements SensorEventListener {
    private WebView web;
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private boolean compassRunning = false;
    private LocationManager locationManager;
    private String pendingOpenHash;
    private final Handler adhanCommandHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService adhanCommandExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean adhanPollInFlight = false;
    private boolean adhanPolling = false;
    private boolean adhanConnectionStatusShown = false;
    private String lastAdhanPollFailure = "";
    private static final String ADHAN_COMMAND_URL = "https://www.chaibcalligraphy.com/wp-json/mishkat/v1/adhan-command";
    private final Runnable adhanPollRunnable = new Runnable() {
        @Override public void run() {
            if (!adhanPolling) return;
            if (!adhanPollInFlight) {
                adhanPollInFlight = true;
                adhanCommandExecutor.execute(() -> {
                    try { pollAdhanCommand(); }
                    finally { adhanPollInFlight = false; }
                });
            }
            adhanCommandHandler.postDelayed(this, 5000);
        }
    };

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(10,48,39));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(245,247,242));
        if(Build.VERSION.SDK_INT>=23) getWindow().getDecorView().setSystemUiVisibility(0);
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);
        rotationSensor=sensorManager!=null?sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR):null;
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},71);
        }
        buildWebView(state);
        // Download both recordings while online; subsequent adhan playback uses local files.
        AdhanAudioCache.warmUp(getApplicationContext());
        scheduleNativePrayerTimes();
    }

    private void buildWebView(Bundle state){
        web=new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(2,19,15));
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view,String url){ if(pendingOpenHash!=null){ String h=pendingOpenHash; pendingOpenHash=null; view.evaluateJavascript("location.hash=\""+h+"\"",null); } }
            private boolean handleUrl(String url){
                if(url==null)return false;
                Uri uri;
                try{uri=Uri.parse(url);}catch(Exception e){return false;}
                String scheme=uri.getScheme();
                if("mailto".equalsIgnoreCase(scheme)){
                    try{
                        Intent email=new Intent(Intent.ACTION_SENDTO,uri);
                        email.putExtra(Intent.EXTRA_SUBJECT,"التواصل مع مطور سُنا مِشكاة");
                        startActivity(Intent.createChooser(email,"اختيار تطبيق البريد الإلكتروني"));
                    }catch(ActivityNotFoundException e){
                        Toast.makeText(MainActivity.this,"لا يوجد تطبيق بريد إلكتروني مثبت على الهاتف",Toast.LENGTH_LONG).show();
                    }catch(Exception e){
                        Toast.makeText(MainActivity.this,"تعذر فتح البريد الإلكتروني",Toast.LENGTH_LONG).show();
                    }
                    return true;
                }
                if("http".equalsIgnoreCase(scheme)||"https".equalsIgnoreCase(scheme)){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){Toast.makeText(MainActivity.this,"تعذر فتح الرابط",Toast.LENGTH_SHORT).show();}
                    return true;
                }
                return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                return handleUrl(request!=null && request.getUrl()!=null?request.getUrl().toString():null);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url){
                return handleUrl(url);
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback){
                if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
                    pendingGeoCallback=callback;
                    pendingGeoOrigin=origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},72);
                }else callback.invoke(origin,true,false);
            }
        });
        web.addJavascriptInterface(new NativeBridge(this),"SunaMishkatNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        pendingOpenHash=getIntent().getStringExtra("open_hash");
    }

    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==72 && pendingGeoCallback!=null){
            boolean ok=grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED;
            pendingGeoCallback.invoke(pendingGeoOrigin,ok,false);
            pendingGeoCallback=null; pendingGeoOrigin=null;
            if(ok){ Toast.makeText(this,"تم السماح بالموقع للقبلة ومواقيت الصلاة",Toast.LENGTH_SHORT).show(); requestLocation(); scheduleNativePrayerTimes(); }
        }
    }

    public void startNativeCompass(){
        if(sensorManager==null || rotationSensor==null){
            sendHeading(-1);
            return;
        }
        if(!compassRunning){
            sensorManager.registerListener(this,rotationSensor,SensorManager.SENSOR_DELAY_GAME);
            compassRunning=true;
        }
    }

    public void stopNativeCompass(){
        if(sensorManager!=null && compassRunning) sensorManager.unregisterListener(this);
        compassRunning=false;
    }

    @Override public void onSensorChanged(SensorEvent event){
        if(event.sensor.getType()!=Sensor.TYPE_ROTATION_VECTOR)return;
        float[] rotation=new float[9];
        float[] orientation=new float[3];
        SensorManager.getRotationMatrixFromVector(rotation,event.values);
        int rotationMode=Surface.ROTATION_0;
        try{ rotationMode=((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRotation(); }catch(Exception ignored){}
        float[] adjusted=new float[9];
        if(rotationMode==Surface.ROTATION_90) SensorManager.remapCoordinateSystem(rotation,SensorManager.AXIS_Y,SensorManager.AXIS_MINUS_X,adjusted);
        else if(rotationMode==Surface.ROTATION_270) SensorManager.remapCoordinateSystem(rotation,SensorManager.AXIS_MINUS_Y,SensorManager.AXIS_X,adjusted);
        else if(rotationMode==Surface.ROTATION_180) SensorManager.remapCoordinateSystem(rotation,SensorManager.AXIS_MINUS_X,SensorManager.AXIS_MINUS_Y,adjusted);
        else System.arraycopy(rotation,0,adjusted,0,9);
        SensorManager.getOrientation(adjusted,orientation);
        double magnetic=Math.toDegrees(orientation[0]);
        double heading=(magnetic+360)%360;
        double[] ll=getLocationPair();
        if(ll!=null){
            try{ GeomagneticField g=new GeomagneticField((float)ll[0],(float)ll[1],0,System.currentTimeMillis()); heading=(heading+g.getDeclination()+360)%360; }catch(Exception ignored){}
        }
        sendHeading(heading);
    }

    private void sendHeading(double h){
        if(web==null)return;
        web.post(() -> web.evaluateJavascript("window.__nativeHeading && window.__nativeHeading("+String.format(Locale.US,"%.2f",h)+")",null));
    }
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}

    private double[] getLocationPair(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED) return null;
        try{
            Location best=null;
            if(locationManager!=null){
                Location gps=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                Location net=locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                best=(gps!=null && (net==null || gps.getTime()>=net.getTime()))?gps:net;
            }
            if(best!=null)return new double[]{best.getLatitude(),best.getLongitude()};
        }catch(Exception ignored){}
        return null;
    }

    public void requestLocation(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},72);
            return;
        }
        if(locationManager==null)return;
        try{
            Location best=null;
            for(String provider:new String[]{LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER}){
                try{
                    Location l=locationManager.getLastKnownLocation(provider);
                    if(l!=null && (best==null || l.getTime()>best.getTime()))best=l;
                }catch(Exception ignored){}
            }
            if(best!=null){ sendLocation(best); return; }
            LocationListener listener=new LocationListener(){
                @Override public void onLocationChanged(Location l){sendLocation(l);try{locationManager.removeUpdates(this);}catch(Exception ignored){}}
                @Override public void onProviderEnabled(String p){}
                @Override public void onProviderDisabled(String p){}
            };
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1000,1,listener,getMainLooper());
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,1,listener,getMainLooper());
        }catch(Exception ignored){}
    }

    private void sendLocation(Location l){
        if(web==null)return;
        String js=String.format(Locale.US,"window.__nativeLocation && window.__nativeLocation(%.7f,%.7f)",l.getLatitude(),l.getLongitude());
        web.post(() -> web.evaluateJavascript(js,null));
    }

    private String nativeHijri(){
        try{
            ULocale u=new ULocale("ar_SA@calendar=islamic-umalqura");
            java.util.Calendar base=appClockCalendar(this);
            Calendar c=Calendar.getInstance(u);
            c.setTimeInMillis(base.getTimeInMillis());
            int d=c.get(Calendar.DAY_OF_MONTH), m=c.get(Calendar.MONTH), y=c.get(Calendar.YEAR);
            String[] names={"محرم","صفر","ربيع الأول","ربيع الآخر","جمادى الأولى","جمادى الآخرة","رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة"};
            String name=(m>=0&&m<names.length)?names[m]:"";
            return "{\"day\":"+d+",\"month\":\""+name+"\",\"year\":"+y+"}";
        }catch(Exception e){return "";}
    }

    private static java.util.Calendar appClockCalendar(Context c){
        return java.util.Calendar.getInstance();
    }

    private void scheduleNativePrayerTimes(){
        
        
        double[] ll=getLocationPair();
        if(ll==null) ll=new double[]{35.6971, -0.6308}; 
        java.util.Calendar d=appClockCalendar(this);
        double tz=d.getTimeZone().getOffset(d.getTimeInMillis())/3600000.0;
        PrayerTimes pt=PrayerTimes.calculate(d,ll[0],ll[1],tz);
        android.content.SharedPreferences.Editor e=getSharedPreferences("prayer_times",0).edit();
        int[] vals={pt.fajr,pt.dhuhr,pt.asr,pt.maghrib,pt.isha}; String[] keys={"fajr","dhuhr","asr","maghrib","isha"};
        for(int i=0;i<keys.length;i++){e.putInt(keys[i]+"_h",vals[i]/60);e.putInt(keys[i]+"_m",vals[i]%60);} e.apply();
        AdhanScheduler.scheduleAll(this);
    }

    public static final class NativeBridge {
        private final MainActivity activity; private final Context context;
        NativeBridge(MainActivity a){activity=a;context=a.getApplicationContext();}
        @JavascriptInterface public void setPrayerTimes(String fajr,String dhuhr,String asr,String maghrib,String isha){
            String[] keys={"fajr","dhuhr","asr","maghrib","isha"}; String[] vals={fajr,dhuhr,asr,maghrib,isha};
            android.content.SharedPreferences.Editor e=context.getSharedPreferences("prayer_times",0).edit();
            for(int i=0;i<keys.length;i++){String v=vals[i]==null?"":vals[i].trim(); if(v.matches("\\d{1,2}:\\d{2}")){String[] p=v.split(":");e.putInt(keys[i]+"_h",Integer.parseInt(p[0]));e.putInt(keys[i]+"_m",Integer.parseInt(p[1]));}}
            e.apply(); AdhanScheduler.scheduleAll(context);
        }
        @JavascriptInterface public void setAdhanConfig(String json){
            try{
                org.json.JSONObject root=new org.json.JSONObject(json);
                org.json.JSONObject a=root.optJSONObject("adhan"); if(a==null)a=root;
                android.content.SharedPreferences.Editor e=context.getSharedPreferences("adhan_remote_config",Context.MODE_PRIVATE).edit();
                if(!context.getSharedPreferences("adhan_remote_config",Context.MODE_PRIVATE).getBoolean("local_override",false)) e.putBoolean("enabled",a.optBoolean("enabled",true));
                e.putInt("volume",Math.max(0,Math.min(100,(int)Math.round(a.optDouble("volume",0.85)*100))));
                String[] keys={"fajr","dhuhr","asr","maghrib","isha"};
                org.json.JSONObject enabled=a.optJSONObject("prayer_enabled"), settings=a.optJSONObject("prayer_settings"), prayers=a.optJSONObject("prayers");
                String global=a.optString("sound_url","");
                boolean hasGlobal=global.startsWith("https://") || global.startsWith("http://");
                String fajrUrl="", regularUrl="";
                for(String key:keys){
                    boolean on=enabled!=null?enabled.optBoolean(key,true):true;
                    org.json.JSONObject one=settings!=null?settings.optJSONObject(key):null;
                    String u="";
                    if(one!=null){on=one.optBoolean("enabled",on);u=one.optString("sound_url","");}
                    if(u.isEmpty() && prayers!=null) u=prayers.optString(key,"");
                    if(u.isEmpty()) u=a.optString(key,"");
                    // This app uses two recordings: one for Fajr and one shared by the other four prayers.
                    if("fajr".equals(key)){
                        if(u.startsWith("https://") || u.startsWith("http://")) fajrUrl=u;
                    }else if("dhuhr".equals(key)){
                        if(u.startsWith("https://") || u.startsWith("http://")) regularUrl=u;
                    }
                    e.putBoolean(key+"_enabled",on);
                }
                if(hasGlobal) regularUrl=global;
                if(fajrUrl.isEmpty()) fajrUrl=AdhanAudioCache.FAJR_URL;
                if(regularUrl.isEmpty()) regularUrl=AdhanAudioCache.REGULAR_URL;
                for(String key:keys){
                    String u="fajr".equals(key)?fajrUrl:regularUrl;
                    e.putString(key+"_url",u);
                }
                if(hasGlobal)e.putString("sound_url",global);
                e.putString("fajr_url",fajrUrl).putString("regular_url",regularUrl);
                e.putLong("updated_at",a.optLong("updated_at",root.optLong("settings_updated_at",0)));
                e.apply(); AdhanScheduler.scheduleAll(context); AdhanAudioCache.warmUp(context,fajrUrl,regularUrl);
            }catch(Exception ignored){}
        }
        @JavascriptInterface public void setAdhanEnabled(boolean enabled){
            android.content.SharedPreferences.Editor e=context.getSharedPreferences("adhan_remote_config",Context.MODE_PRIVATE).edit().putBoolean("enabled",enabled).putBoolean("local_override",true); e.apply();
            if(enabled) AdhanScheduler.scheduleAll(context); else { AdhanScheduler.cancelAll(context); context.stopService(new Intent(context,AdhanService.class)); }
        }
        @JavascriptInterface public void applyRemoteAdhanCommand(String type,String soundUrl,String prayer){
            applyRemoteAdhanCommand(type,soundUrl,prayer,"",0);
        }
        @JavascriptInterface public void applyRemoteAdhanCommand(String type,String soundUrl,String prayer,String message,int duration){
            applyRemoteAdhanCommand(type,soundUrl,prayer,message,duration,"صوتيات","");
        }
        @JavascriptInterface public void applyRemoteAdhanCommand(String type,String soundUrl,String prayer,String message,int duration,String notificationTitle,String notificationIcon){
            if("notification_test".equalsIgnoreCase(type)){
                showRemoteTestNotification(notificationTitle,message,notificationIcon);
                return;
            }
            if("stop".equalsIgnoreCase(type)){context.stopService(new Intent(context,AdhanService.class));return;}
            if("enable".equalsIgnoreCase(type)){setAdhanEnabled(true);return;}
            if("disable".equalsIgnoreCase(type)){setAdhanEnabled(false);return;}
            if("adhan_test".equalsIgnoreCase(type)||"play".equalsIgnoreCase(type)||"play_audio".equalsIgnoreCase(type)){
                String key=(prayer==null||prayer.trim().isEmpty())?"dhuhr":prayer.trim().toLowerCase(Locale.ROOT);
                if(!java.util.Arrays.asList("fajr","dhuhr","asr","maghrib","isha").contains(key)) key="dhuhr";
                Intent service=new Intent(context,AdhanService.class).putExtra("test",true).putExtra("prayer",key)
                    .putExtra("message",message==null?"":message).putExtra("duration",Math.max(0,Math.min(300,duration)))
                    .putExtra("sound_url",soundUrl==null?"":soundUrl);
                if(soundUrl!=null && (soundUrl.startsWith("https://")||soundUrl.startsWith("http://"))){
                    android.content.SharedPreferences prefs=context.getSharedPreferences("adhan_remote_config",Context.MODE_PRIVATE);
                    android.content.SharedPreferences.Editor e=prefs.edit().putString(key+"_url",soundUrl);
                    if("fajr".equals(key))e.putString("fajr_url",soundUrl);else e.putString("regular_url",soundUrl);
                    e.apply();
                    AdhanAudioCache.warmUp(context,prefs.getString("fajr_url",AdhanAudioCache.FAJR_URL),prefs.getString("regular_url",AdhanAudioCache.REGULAR_URL));
                }
                if(Build.VERSION.SDK_INT>=26)context.startForegroundService(service);else context.startService(service);
            }
        }
        private void showRemoteTestNotification(String title,String message,String iconUrl){
            try {
                if (android.os.Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    if (context instanceof Activity) ((Activity)context).runOnUiThread(() -> android.widget.Toast.makeText(context,"يرجى السماح بإشعارات تطبيق سُنا مِشكاة من إعدادات الهاتف",android.widget.Toast.LENGTH_LONG).show());
                    return;
                }
                final String channelId="suna_remote_audio_notifications";
                android.app.NotificationManager nm=(android.app.NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
                if(nm==null)return;
                if(android.os.Build.VERSION.SDK_INT>=26){
                    android.app.NotificationChannel channel=new android.app.NotificationChannel(channelId,"صوتيات",android.app.NotificationManager.IMPORTANCE_DEFAULT);
                    channel.setDescription("إشعارات صوتيات سُنا مِشكاة"); nm.createNotificationChannel(channel);
                }
                int smallIcon=R.drawable.ic_stat_stop_adhan;
                android.graphics.Bitmap large=android.graphics.BitmapFactory.decodeResource(context.getResources(),R.drawable.suna_mishkat_icon);
                android.app.Notification.Builder builder=android.os.Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(context,channelId):new android.app.Notification.Builder(context);
                builder.setSmallIcon(smallIcon).setContentTitle(title==null||title.trim().isEmpty()?"صوتيات":title).setContentText(message==null?"":message).setAutoCancel(true).setShowWhen(true);
                if(large!=null)builder.setLargeIcon(large);
                final int notificationId=71068; nm.notify(notificationId,builder.build());
                if(iconUrl!=null && (iconUrl.startsWith("https://")||iconUrl.startsWith("http://"))){
                    activity.adhanCommandExecutor.execute(() -> {
                        java.net.HttpURLConnection c=null;
                        try { c=(java.net.HttpURLConnection)new java.net.URL(iconUrl).openConnection(); c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setInstanceFollowRedirects(true); c.setRequestProperty("User-Agent","SunaMishkat-Android/1.7.68");
                            if(c.getResponseCode()==200){try(java.io.InputStream in=c.getInputStream()){android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeStream(in); if(bitmap!=null){builder.setLargeIcon(bitmap); nm.notify(notificationId,builder.build());}}}
                        } catch(Exception ignored){} finally {if(c!=null)c.disconnect();}
                    });
                }
            } catch(Exception ex){android.util.Log.e("SunaAdhan","Notification test failed",ex);}
        }
        @JavascriptInterface public String getLocalQuranAudio(String surahText,String reciter){
            try{
                int surah=Integer.parseInt(surahText);
                if(surah<1||surah>114)return "";
                String safeReciter=(reciter==null?"ar.alafasy":reciter.trim());
                if(!safeReciter.matches("[A-Za-z0-9._-]{1,80}"))safeReciter="ar.alafasy";
                File dir=new File(context.getFilesDir(),"quran_audio");
                File audio=new File(dir,safeReciter+"-"+surah+".mp3");
                return audio.isFile()&&audio.length()>1024?Uri.fromFile(audio).toString():"";
            }catch(Exception e){return "";}
        }
        @JavascriptInterface public void downloadQuranSurah(String surahText,String reciter){
            final int surah; final String safeReciter;
            try{surah=Integer.parseInt(surahText);if(surah<1||surah>114)return;}catch(Exception e){return;}
            String candidate=reciter==null?"ar.alafasy":reciter.trim();
            safeReciter=candidate.matches("[A-Za-z0-9._-]{1,80}")?candidate:"ar.alafasy";
            new Thread(()->{
                HttpURLConnection connection=null; File temp=null; boolean ok=false; String message="تعذر تنزيل السورة. تحقق من الإنترنت وحاول مجددًا."; String localUrl="";
                try{
                    File dir=new File(context.getFilesDir(),"quran_audio");
                    if(!dir.exists()&&!dir.mkdirs())throw new java.io.IOException("تعذر إنشاء مجلد الصوت");
                    File target=new File(dir,safeReciter+"-"+surah+".mp3");
                    temp=new File(dir,safeReciter+"-"+surah+".mp3.part");
                    URL url=new URL("https://cdn.islamic.network/quran/audio-surah/128/"+safeReciter+"/"+surah+".mp3");
                    connection=(HttpURLConnection)url.openConnection();connection.setConnectTimeout(20000);connection.setReadTimeout(30000);connection.setInstanceFollowRedirects(true);connection.setRequestProperty("User-Agent","SunaMishkat-Android");
                    int code=connection.getResponseCode();if(code<200||code>=300)throw new java.io.IOException("HTTP "+code);
                    try(InputStream in=connection.getInputStream();FileOutputStream out=new FileOutputStream(temp)){
                        byte[] buffer=new byte[16384];int n;long total=0;while((n=in.read(buffer))!=-1){total+=n;if(total>80L*1024*1024)throw new java.io.IOException("حجم الملف أكبر من الحد المسموح");out.write(buffer,0,n);}out.flush();out.getFD().sync();
                    }
                    if(temp.length()<1024)throw new java.io.IOException("ملف الصوت غير مكتمل");
                    if(target.exists()&&!target.delete())throw new java.io.IOException("تعذر استبدال الملف القديم");
                    if(!temp.renameTo(target))throw new java.io.IOException("تعذر حفظ ملف الصوت");
                    ok=true;localUrl=Uri.fromFile(target).toString();message="";
                }catch(Exception e){message="تعذر تنزيل السورة. تحقق من اتصال الإنترنت وحاول مجددًا.";if(temp!=null&&temp.exists())temp.delete();}
                finally{if(connection!=null)connection.disconnect();}
                final boolean success=ok;final String resultUrl=localUrl;final String resultMessage=message;
                activity.runOnUiThread(()->{if(activity.web!=null){String js="window.__quranDownloadResult&&window.__quranDownloadResult("+surah+","+org.json.JSONObject.quote(safeReciter)+","+success+","+org.json.JSONObject.quote(resultUrl)+","+org.json.JSONObject.quote(resultMessage)+")";activity.web.evaluateJavascript(js,null);}});
            },"mishkat-quran-download").start();
        }
        @JavascriptInterface public void scheduleAdhan(){AdhanScheduler.scheduleAll(context);}
        @JavascriptInterface public void requestLocation(){activity.requestLocation();}
        @JavascriptInterface public void startCompass(){activity.startNativeCompass();}
        @JavascriptInterface public void stopCompass(){activity.stopNativeCompass();}
        @JavascriptInterface public String getHijriDate(){return activity.nativeHijri();}
        @JavascriptInterface public void stopAdhan(){context.stopService(new Intent(context,AdhanService.class));}
        @JavascriptInterface public void testAdhan(){ testAdhan("dhuhr",-1,-1); }
        @JavascriptInterface public void testAdhan(String prayer,int hour,int minute){ Intent s=new Intent(context,AdhanService.class).putExtra("test",true).putExtra("prayer",prayer).putExtra("display_hour",hour).putExtra("display_minute",minute); if(Build.VERSION.SDK_INT>=26) context.startForegroundService(s); else context.startService(s); }
        @JavascriptInterface public void setClock24(boolean enabled){ context.getSharedPreferences("settings",0).edit().putBoolean("clock_24",enabled).apply(); }
        @JavascriptInterface public void setManualClock(int year,int month,int day,int hour,int minute,int second){ context.getSharedPreferences("settings",0).edit().putBoolean("manual_clock",true).putInt("manual_year",year).putInt("manual_month",month).putInt("manual_day",day).putInt("manual_hour",hour).putInt("manual_minute",minute).putInt("manual_second",second).putLong("manual_base_real",System.currentTimeMillis()).apply(); activity.scheduleNativePrayerTimes(); }
        @JavascriptInterface public void clearManualClock(){ context.getSharedPreferences("settings",0).edit().putBoolean("manual_clock",false).remove("manual_base_real").apply(); activity.scheduleNativePrayerTimes(); }
        @JavascriptInterface public boolean getClock24(){ return context.getSharedPreferences("settings",0).getBoolean("clock_24",true); }
        @JavascriptInterface public void openExactAlarmSettings(){if(Build.VERSION.SDK_INT>=31){try{context.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+context.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception ignored){}}}
        @JavascriptInterface public boolean exactAlarmAllowed(){if(Build.VERSION.SDK_INT<31)return true;android.app.AlarmManager am=(android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);return am!=null&&am.canScheduleExactAlarms();}
    }

    private void startAdhanCommandPolling() {
        if (adhanPolling) return;
        adhanPolling = true;
        adhanPollHandlerStart();
    }
    private void adhanPollHandlerStart() { adhanPollHandlerPost(0); }
    private void adhanPollHandlerPost(long delay) { adhanCommandHandler.postDelayed(adhanPollRunnable, delay); }
    private void stopAdhanCommandPolling() {
        adhanPolling = false;
        adhanCommandHandler.removeCallbacks(adhanPollRunnable);
    }
    private void pollAdhanCommand() {
        HttpURLConnection conn = null;
        try {
            // Add a cache-buster and explicit no-cache headers so a CDN/page cache
            // cannot keep returning an old "pending=false" response.
            conn = (HttpURLConnection) new URL(ADHAN_COMMAND_URL + "?_=" + System.currentTimeMillis()).openConnection();
            conn.setRequestMethod("GET"); conn.setConnectTimeout(10000); conn.setReadTimeout(10000);
            conn.setUseCaches(false);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
            conn.setRequestProperty("Pragma", "no-cache");
            conn.setRequestProperty("User-Agent", "SunaMishkat-Android/1.7.68");
            int responseCode = conn.getResponseCode();
            if (responseCode != 200) {
                String reason = "HTTP " + responseCode;
                android.util.Log.e("SunaAdhan", "Command endpoint returned " + reason + " at " + conn.getURL());
                lastAdhanPollFailure = reason;
                return;
            }
            lastAdhanPollFailure = "";
            StringBuilder body = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line; while ((line = r.readLine()) != null) body.append(line);
            }
            JSONObject root = new JSONObject(body.toString());
            if (!adhanConnectionStatusShown) {
                adhanConnectionStatusShown = true;
                android.util.Log.i("SunaAdhan", "Command endpoint connected successfully; pending=" + root.optBoolean("pending", false));
            }
            if (!root.optBoolean("pending", false)) return;
            JSONObject command = root.optJSONObject("command"); if (command == null) return;
            String id = command.optString("id", ""); if (id.isEmpty()) return;
            android.content.SharedPreferences prefs = getSharedPreferences("adhan_remote_commands", MODE_PRIVATE);
            if (id.equals(prefs.getString("last_acknowledged_id", ""))) { acknowledgeAdhanCommand(id); return; }
            String type = command.optString("type", "");
            String sound = command.optString("sound_url", "");
            String prayer = command.optString("prayer", "dhuhr");
            // Execute on the Android UI thread so the bridge/service call uses the application context safely.
            runOnUiThread(() -> {
                try {
                    String message=command.optString("message", "");
                    int duration=command.optInt("duration", 0);
                    String notificationTitle=command.optString("notification_title", "صوتيات");
                    String notificationIcon=command.optString("notification_icon", "");
                    new NativeBridge(MainActivity.this).applyRemoteAdhanCommand(type, sound, prayer, message, duration, notificationTitle, notificationIcon);
                    getSharedPreferences("adhan_remote_commands", MODE_PRIVATE).edit().putString("last_acknowledged_id", id).apply();
                    adhanCommandExecutor.execute(() -> acknowledgeAdhanCommand(id));
                } catch (Exception ex) {
                    android.util.Log.e("SunaAdhan", "Could not execute remote command", ex);
                }
            });
        } catch (Exception e) {
            String reason = e.getClass().getSimpleName();
            android.util.Log.e("SunaAdhan", "Adhan command poll failed: " + e.getMessage(), e);
            lastAdhanPollFailure = reason;
        } finally { if (conn != null) conn.disconnect(); }
    }
    private void acknowledgeAdhanCommand(String id) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(ADHAN_COMMAND_URL + "/ack").openConnection();
            conn.setRequestMethod("POST"); conn.setConnectTimeout(7000); conn.setReadTimeout(7000);
            conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] data = new JSONObject().put("id", id).toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = conn.getOutputStream()) { out.write(data); }
            int code = conn.getResponseCode();
            if (code >= 200 && code < 300) getSharedPreferences("adhan_remote_commands", MODE_PRIVATE).edit().putString("last_acknowledged_id", id).apply();
            else android.util.Log.w("SunaAdhan", "Command ACK HTTP " + code);
        } catch (Exception e) { android.util.Log.w("SunaAdhan", "Command ACK failed: " + e.getMessage()); }
        finally { if (conn != null) conn.disconnect(); }
    }
    @Override protected void onResume() { super.onResume(); startAdhanCommandPolling(); }
    @Override protected void onPause() { stopAdhanCommandPolling(); super.onPause(); }

    @Override protected void onNewIntent(Intent intent){ super.onNewIntent(intent); setIntent(intent); pendingOpenHash=intent.getStringExtra("open_hash"); if(web!=null&&web.getUrl()!=null&&pendingOpenHash!=null){ String h=pendingOpenHash; pendingOpenHash=null; web.evaluateJavascript("location.hash=\""+h+"\"",null); } }

    @Override protected void onDestroy(){stopNativeCompass();super.onDestroy();}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
