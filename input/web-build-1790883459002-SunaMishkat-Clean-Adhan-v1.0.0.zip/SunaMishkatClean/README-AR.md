# سُنا مِشكاة — Clean Build 1.0.0
مشروع Android نظيف بدون مكتبات خارجية للتقليل من أخطاء Gradle/Maven.
الهدف الأول: تثبيت APK واختبار الأذان مع قفل الشاشة.
Java 17 / Android SDK 35 / minSdk 26.
