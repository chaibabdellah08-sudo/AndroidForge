package com.chaibcalligraphy.sunamishkat;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i) { AdhanScheduler.scheduleTest(c,60000); }
}
