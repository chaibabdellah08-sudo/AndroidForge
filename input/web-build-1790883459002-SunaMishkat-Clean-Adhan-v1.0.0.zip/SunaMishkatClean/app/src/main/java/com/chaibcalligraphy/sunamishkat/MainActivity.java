package com.chaibcalligraphy.sunamishkat;
import android.app.*;
import android.os.*;
import android.content.*;
import android.provider.Settings;
import android.net.Uri;
import android.view.*;
import android.widget.*;
public class MainActivity extends Activity {
 LinearLayout box;
 int pad=28;
 @Override public void onCreate(Bundle b){super.onCreate(b);
  box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(pad,pad,pad,pad);
  TextView title=new TextView(this); title.setText("سُنا مِشكاة"); title.setTextSize(32); title.setGravity(Gravity.CENTER); box.addView(title,new LinearLayout.LayoutParams(-1,100));
  TextView sub=new TextView(this); sub.setText("نسخة الأساس — اختبار الأذان"); sub.setTextSize(18); sub.setGravity(Gravity.CENTER); box.addView(sub,new LinearLayout.LayoutParams(-1,80));
  Button alarm=new Button(this); alarm.setText("🔔 اختبار الأذان بعد 10 ثوانٍ"); alarm.setOnClickListener(v->{AdhanScheduler.scheduleTest(this,10000);Toast.makeText(this,"تمت جدولة الأذان بعد 10 ثوانٍ",Toast.LENGTH_LONG).show();}); box.addView(alarm);
  Button play=new Button(this); play.setText("▶ تشغيل الأذان الآن"); play.setOnClickListener(v->{Intent i=new Intent(this,AdhanService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);});box.addView(play);
  Button exact=new Button(this); exact.setText("⚙ السماح بالمنبهات الدقيقة"); exact.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=31)try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));}catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}});box.addView(exact);
  TextView dev=new TextView(this);dev.setText("\nAbdellah Chaib\ncontact@chaibcalligraphy.com");dev.setGravity(Gravity.CENTER);dev.setTextSize(15);box.addView(dev,new LinearLayout.LayoutParams(-1,-2));
  setContentView(box);
 }
}
