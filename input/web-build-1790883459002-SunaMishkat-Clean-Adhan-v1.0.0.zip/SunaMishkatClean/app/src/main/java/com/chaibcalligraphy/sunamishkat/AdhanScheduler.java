package com.chaibcalligraphy.sunamishkat;
import android.app.*;
import android.content.*;
public final class AdhanScheduler {
 public static void scheduleTest(Context c,long delayMs){
   AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
   Intent in=new Intent(c,AdhanReceiver.class);
   PendingIntent pi=PendingIntent.getBroadcast(c,1001,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   long at=System.currentTimeMillis()+delayMs;
   if(android.os.Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
   else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);
 }
 private AdhanScheduler(){}
}
