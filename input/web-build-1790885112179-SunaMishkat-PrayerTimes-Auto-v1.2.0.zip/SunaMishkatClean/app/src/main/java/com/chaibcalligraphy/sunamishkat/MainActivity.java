package com.chaibcalligraphy.sunamishkat;

import android.Manifest; import android.app.*; import android.os.*; import android.content.*; import android.content.pm.PackageManager; import android.location.*; import android.provider.Settings; import android.net.Uri; import android.graphics.Typeface; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 LinearLayout box; TextView status; LocationManager lm; final String[] keys={"fajr","dhuhr","asr","maghrib","isha"}; final String[] names={"الفجر","الظهر","العصر","المغرب","العشاء"};
 @Override public void onCreate(Bundle b){super.onCreate(b); build(); if(Build.VERSION.SDK_INT>=23) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},44); else calculateFromLocation();}
 TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(10,10,10,10);return t;}
 void build(){
  box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28,20,28,20); box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
  TextView title=tv("سُنا مِشكاة",32); title.setGravity(Gravity.CENTER); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); box.addView(title,new LinearLayout.LayoutParams(-1,90));
  TextView sub=tv("مواقيت الصلاة والأذان التلقائي",18); sub.setGravity(Gravity.CENTER); box.addView(sub);
  status=tv("📍 نحتاج إلى موقعك لحساب المواقيت تلقائيًا",16); status.setGravity(Gravity.CENTER); box.addView(status);
  for(int i=0;i<5;i++) addRow(i);
  Button calc=new Button(this); calc.setText("📍 حساب المواقيت تلقائيًا"); calc.setOnClickListener(v->calculateFromLocation()); box.addView(calc);
  Button save=new Button(this); save.setText("💾 حفظ وجدولة الأذان"); save.setOnClickListener(v->{AdhanScheduler.scheduleAll(this);status.setText("✅ تم حفظ المواقيت وجدولة الأذانات");}); box.addView(save);
  Button test=new Button(this); test.setText("🔔 اختبار الأذان بعد 10 ثوانٍ"); test.setOnClickListener(v->{AdhanScheduler.scheduleTest(this,10000);Toast.makeText(this,"سيعمل الأذان بعد 10 ثوانٍ",Toast.LENGTH_SHORT).show();}); box.addView(test);
  Button exact=new Button(this); exact.setText("⚙ السماح بالمنبهات الدقيقة"); exact.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=31)try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));}catch(Exception e){}}); box.addView(exact);
  TextView dev=tv("\nAbdellah Chaib\ncontact@chaibcalligraphy.com",14);dev.setGravity(Gravity.CENTER);box.addView(dev); setContentView(box);
 }
 void addRow(final int i){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView n=tv(names[i],18);n.setGravity(Gravity.CENTER);row.addView(n,new LinearLayout.LayoutParams(0,70,1));TextView time=tv(getTime(i),18);time.setGravity(Gravity.CENTER);time.setTag(i);row.addView(time,new LinearLayout.LayoutParams(0,70,1));box.addView(row);}
 String getTime(int i){android.content.SharedPreferences p=getSharedPreferences("prayer_times",0);int m=p.getInt(keys[i]+"_min",-1);return m<0?"--:--":PrayerTimes.fmt(m);}
 void refresh(){for(int j=0;j<box.getChildCount();j++){View v=box.getChildAt(j);if(v instanceof LinearLayout){for(int k=0;k<((LinearLayout)v).getChildCount();k++){View x=((LinearLayout)v).getChildAt(k);Object tag=x.getTag();if(tag instanceof Integer){int i=(Integer)tag;((TextView)x).setText(getTime(i));}}}}}
 void calculateFromLocation(){
  lm=(LocationManager)getSystemService(LOCATION_SERVICE); Location loc=null;
  try{if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){status.setText("📍 اسمح للتطبيق بالوصول إلى الموقع ثم اضغط مرة أخرى");return;} if(lm.isProviderEnabled(LocationManager.GPS_PROVIDER))loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER); if(loc==null && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);}catch(Exception e){}
  if(loc==null){status.setText("📍 تعذر الحصول على الموقع. فعّل GPS ثم اضغط مرة أخرى.");return;}
  double tz=TimeZone.getDefault().getOffset(System.currentTimeMillis())/3600000.0; PrayerTimes pt=PrayerTimes.calculate(Calendar.getInstance(),loc.getLatitude(),loc.getLongitude(),tz); int[] vals={pt.fajr,pt.dhuhr,pt.asr,pt.maghrib,pt.isha}; android.content.SharedPreferences.Editor e=getSharedPreferences("prayer_times",0).edit(); for(int i=0;i<5;i++)e.putInt(keys[i]+"_min",vals[i]);e.putString("location",String.format(Locale.US,"%.5f, %.5f",loc.getLatitude(),loc.getLongitude()));e.apply(); refresh(); AdhanScheduler.scheduleAll(this); status.setText("📍 تم حساب المواقيت وجدولة الأذان تلقائيًا"); }
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==44 && g.length>0)calculateFromLocation();}
}
