package com.chaibcalligraphy.sunamishkat;

import java.util.*;

public final class PrayerTimes {
    public final int fajr, sunrise, dhuhr, asr, sunset, maghrib, isha;
    private PrayerTimes(int f,int sr,int d,int a,int ss,int m,int i){fajr=f;sunrise=sr;dhuhr=d;asr=a;sunset=ss;maghrib=m;isha=i;}
    public static PrayerTimes calculate(Calendar date,double lat,double lon,double tzHours){
        int doy=date.get(Calendar.DAY_OF_YEAR); double gamma=2*Math.PI/365*(doy-1);
        double eqt=229.18*(0.000075+0.001868*Math.cos(gamma)-0.032077*Math.sin(gamma)-0.014615*Math.cos(2*gamma)-0.040849*Math.sin(2*gamma));
        double decl=0.006918-0.399912*Math.cos(gamma)+0.070257*Math.sin(gamma)-0.006758*Math.cos(2*gamma)+0.000907*Math.sin(2*gamma)-0.002697*Math.cos(3*gamma)+0.00148*Math.sin(3*gamma);
        double noon=720-4*lon-eqt+tzHours*60;
        int sr=minToClock(noon-ha(lat,decl,-0.833)), ss=minToClock(noon+ha(lat,decl,-0.833));
        int fajr=minToClock(noon-ha(lat,decl,-18)); int isha=minToClock(noon+ha(lat,decl,-18));
        int dhuhr=minToClock(noon);
        double asrAngle=Math.toDegrees(Math.acos((Math.sin(Math.toRadians(90-Math.toDegrees(Math.atan(1+Math.tan(Math.toRadians(Math.abs(lat-decl))))))))));
        // Standard shadow-length 1 calculation via solar altitude formula.
        double angle=Math.toDegrees(Math.atan(1.0/(1.0+Math.tan(Math.toRadians(Math.abs(lat-Math.toDegrees(decl)))))));
        int asr=minToClock(noon+ha(lat,decl,angle));
        return new PrayerTimes(fajr,sr,dhuhr,asr,ss,ss+1,isha);
    }
    private static double ha(double lat,double dec,double altitude){
        double x=(Math.sin(Math.toRadians(altitude))-Math.sin(Math.toRadians(lat))*Math.sin(dec))/(Math.cos(Math.toRadians(lat))*Math.cos(dec));
        x=Math.max(-1,Math.min(1,x)); return Math.toDegrees(Math.acos(x))*4;
    }
    private static int minToClock(double minutes){
        int m=(int)Math.round(minutes); m=((m%1440)+1440)%1440; return m;
    }
    public static String fmt(int m){return String.format(Locale.US,"%02d:%02d",m/60,m%60);}
    public static int tzMinutes(){return TimeZone.getDefault().getOffset(System.currentTimeMillis())/60000;}
    private PrayerTimes(){}
}
