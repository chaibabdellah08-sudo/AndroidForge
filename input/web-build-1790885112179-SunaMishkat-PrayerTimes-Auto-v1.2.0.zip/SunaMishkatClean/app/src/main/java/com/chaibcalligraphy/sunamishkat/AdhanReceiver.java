package com.chaibcalligraphy.sunamishkat;
import android.content.*; import android.os.Build;
public class AdhanReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i) {
   String prayer=i.getStringExtra("prayer");
   if(prayer!=null && !"test".equals(prayer)) AdhanScheduler.scheduleNext(c,prayer);
   Intent s=new Intent(c,AdhanService.class).putExtra("prayer",prayer);
   if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s); else c.startService(s);
 }
}
