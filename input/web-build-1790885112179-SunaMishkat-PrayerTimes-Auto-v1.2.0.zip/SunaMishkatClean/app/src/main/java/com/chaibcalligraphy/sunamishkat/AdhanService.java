package com.chaibcalligraphy.sunamishkat;
import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
public class AdhanService extends Service {
 static final int NOTIF=1441;
 MediaPlayer player;
 @Override public void onCreate(){
   super.onCreate();
   String ch="suna_adhan";
   NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
   if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"الأذان",NotificationManager.IMPORTANCE_HIGH));
   Intent open=new Intent(this,MainActivity.class);
   PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
   Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ch):new Notification.Builder(this);
   b.setContentTitle("🔔 سُنا مِشكاة").setContentText("حان وقت الأذان").setSmallIcon(com.chaibcalligraphy.sunamishkat.R.drawable.ic_stat_adhan).setContentIntent(pi).setOngoing(false);
   startForeground(NOTIF,b.build());
   player=new MediaPlayer();
   try{
    player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
    player.setDataSource(AppConfig.ADHAN_URL);
    player.setOnPreparedListener(MediaPlayer::start);
    player.setOnCompletionListener(p->{p.release();stopForeground(true);stopSelf();});
    player.prepareAsync();
   }catch(Exception e){stopForeground(true);stopSelf();}
 }
 @Override public int onStartCommand(Intent i,int f,int id){return START_NOT_STICKY;}
 @Override public android.os.IBinder onBind(Intent i){return null;}
 @Override public void onDestroy(){if(player!=null){try{player.release();}catch(Exception ignored){}} super.onDestroy();}
}
