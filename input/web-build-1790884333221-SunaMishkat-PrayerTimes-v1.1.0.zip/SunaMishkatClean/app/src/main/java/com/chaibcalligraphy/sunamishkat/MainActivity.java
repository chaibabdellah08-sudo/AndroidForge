package com.chaibcalligraphy.sunamishkat;

import android.app.*; import android.os.*; import android.content.*; import android.provider.Settings; import android.net.Uri; import android.graphics.Typeface; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 LinearLayout box; final String[] keys={"fajr","dhuhr","asr","maghrib","isha"}; final String[] names={"الفجر","الظهر","العصر","المغرب","العشاء"}; TextView status;
 @Override public void onCreate(Bundle b){super.onCreate(b); build();}
 TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(8,8,8,8);return t;}
 void build(){
  box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(30,24,30,24);box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
  TextView title=tv("سُنا مِشكاة",32);title.setGravity(Gravity.CENTER);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);box.addView(title,new LinearLayout.LayoutParams(-1,90));
  TextView sub=tv("أوقات الصلاة والأذان",19);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,60));
  status=tv("اضبط أوقات الصلاة ثم اضغط حفظ وجدولة الأذان",16);status.setGravity(Gravity.CENTER);box.addView(status);
  for(int i=0;i<5;i++) addPrayerRow(i);
  Button save=new Button(this);save.setText("💾 حفظ وجدولة الأذان");save.setOnClickListener(v->{AdhanScheduler.scheduleAll(this);status.setText("✅ تم حفظ أوقات الصلاة وجدولة الأذان");Toast.makeText(this,"تمت جدولة الأذانات",Toast.LENGTH_SHORT).show();});box.addView(save);
  Button test=new Button(this);test.setText("🔔 اختبار الأذان بعد 10 ثوانٍ");test.setOnClickListener(v->{AdhanScheduler.scheduleTest(this,10000);Toast.makeText(this,"سيعمل الأذان بعد 10 ثوانٍ",Toast.LENGTH_SHORT).show();});box.addView(test);
  Button play=new Button(this);play.setText("▶ تشغيل الأذان الآن");play.setOnClickListener(v->{Intent i=new Intent(this,AdhanService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);});box.addView(play);
  Button exact=new Button(this);exact.setText("⚙ السماح بالمنبهات الدقيقة");exact.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=31)try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));}catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}});box.addView(exact);
  TextView dev=tv("\nAbdellah Chaib\ncontact@chaibcalligraphy.com",15);dev.setGravity(Gravity.CENTER);box.addView(dev);
  setContentView(box);
 }
 void addPrayerRow(final int i){
  LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,4,0,4);
  TextView n=tv(names[i],18);n.setGravity(Gravity.CENTER);row.addView(n,new LinearLayout.LayoutParams(0,70,1));
  final Button time=new Button(this);time.setText(getTime(i));time.setOnClickListener(v->pick(i,time));row.addView(time,new LinearLayout.LayoutParams(0,70,1));
  box.addView(row);
 }
 String getTime(int i){android.content.SharedPreferences p=getSharedPreferences("prayer_times",0);int h=p.getInt(keys[i]+"_h",-1),m=p.getInt(keys[i]+"_m",-1);return h<0?"تحديد الوقت":String.format(Locale.US,"%02d:%02d",h,m);}
 void pick(final int i,final Button b){android.content.SharedPreferences p=getSharedPreferences("prayer_times",0);int h=p.getInt(keys[i]+"_h",12),m=p.getInt(keys[i]+"_m",0);TimePickerDialog d=new TimePickerDialog(this,(v,hh,mm)->{p.edit().putInt(keys[i]+"_h",hh).putInt(keys[i]+"_m",mm).apply();b.setText(String.format(Locale.US,"%02d:%02d",hh,mm));},h,m,true);d.setTitle(names[i]);d.show();}
}
