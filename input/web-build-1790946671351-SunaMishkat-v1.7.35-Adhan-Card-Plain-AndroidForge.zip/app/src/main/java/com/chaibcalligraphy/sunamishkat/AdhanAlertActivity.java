package com.chaibcalligraphy.sunamishkat;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AdhanAlertActivity extends Activity {
    private StopSlider slider;
    private final BroadcastReceiver finishedReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { finish(); }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.rgb(2, 19, 15));
        buildUi();
        AdhanService.hideForAlert();
        IntentFilter f = new IntentFilter(AdhanService.ACTION_FINISHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(finishedReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(finishedReceiver, f);
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private TextView text(String s, float size, int color, int gravity) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(gravity); t.setFontFeatureSettings("kern"); return t;
    }

    private void buildUi() {
        String prayer = getIntent().getStringExtra("prayer");
        String title = prayerName(prayer);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setPadding(24, 30, 24, 30);
        root.setBackgroundColor(Color.rgb(4, 48, 39));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(28, 28, 28, 30); card.setBackground(bg(Color.rgb(7, 78, 62), 42));
        card.setElevation(18);
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));

                        TextView now = text("حان الآن وقت الأذان", 25, Color.WHITE, Gravity.CENTER);
        now.setTypeface(null, android.graphics.Typeface.BOLD); card.addView(now, new LinearLayout.LayoutParams(-1, 52));

        TextView p = text(title, 31, Color.rgb(244, 202, 89), Gravity.CENTER);
        p.setTypeface(null, android.graphics.Typeface.BOLD); card.addView(p, new LinearLayout.LayoutParams(-1, 54));

        TextView time = text(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()), 18, Color.rgb(210, 232, 224), Gravity.CENTER);
        card.addView(time, new LinearLayout.LayoutParams(-1, 34));

        TextView hint = text("اسحب لإيقاف الأذان", 15, Color.rgb(190, 214, 206), Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 38); hp.topMargin = 14; card.addView(hint, hp);

        slider = new StopSlider(this);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 68); sp.topMargin = 8; card.addView(slider, sp);
        slider.setOnStopListener(() -> stopAdhan());

        TextView foot = text("يمكنك إيقاف الأذان بسحب الزر حتى النهاية", 12, Color.rgb(150, 184, 171), Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, 30); fp.topMargin = 10; card.addView(foot, fp);

        setContentView(root);
    }

    private String prayerName(String p) {
        if (p == null) return "الأذان";
        switch (p.toLowerCase(Locale.US)) {
            case "fajr": return "أذان الفجر";
            case "dhuhr": return "أذان الظهر";
            case "asr": return "أذان العصر";
            case "maghrib": return "أذان المغرب";
            case "isha": return "أذان العشاء";
            default: return p;
        }
    }

    private void stopAdhan() {
        stopService(new Intent(this, AdhanService.class));
        finish();
    }

    @Override protected void onStop() {
        super.onStop();
        // When the alert leaves the foreground, restore the notification so
        // the ongoing adhan still has a system control while the app is hidden.
        AdhanService.showAfterAlert();
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(finishedReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        // Do not stop the adhan accidentally; the slider is the intentional stop control.
        moveTaskToBack(true);
    }

    public static class StopSlider extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private float progress = 1f;
        private boolean dragging;
        private Runnable listener;
        private final GradientDrawable thumbBg = new GradientDrawable();
        public StopSlider(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        public void setOnStopListener(Runnable r){listener=r;}
        @Override protected void onDraw(android.graphics.Canvas c){
            super.onDraw(c); float w=getWidth(), h=getHeight();
            paint.setColor(Color.rgb(4,38,30)); c.drawRoundRect(0,8,w,h-8,(h-8)/2f,(h-8)/2f,paint);
            paint.setColor(Color.rgb(34,106,86)); c.drawRoundRect(4,12,w-4,h-12,(h-24)/2f,(h-24)/2f,paint);
            paint.setColor(Color.argb(120,255,255,255)); paint.setTextSize(16); paint.setTextAlign(android.graphics.Paint.Align.CENTER);
            c.drawText("اسحب إلى اليسار لإيقاف الأذان", w/2f, h/2f+6, paint);
            float x = 8 + progress*(w-16);
            paint.setColor(Color.WHITE); c.drawCircle(x,h/2f,23,paint);
            paint.setColor(Color.rgb(12,91,73)); paint.setTextSize(22); c.drawText("🔔",x,h/2f+8,paint);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            float w=getWidth();
            if(e.getAction()==MotionEvent.ACTION_DOWN){dragging=true; update(e.getX(),w); return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE){if(dragging){update(e.getX(),w); return true;}}
            if(e.getAction()==MotionEvent.ACTION_UP){if(dragging){update(e.getX(),w);dragging=false;if(progress<0.12f && listener!=null)listener.run();return true;}}
            return true;
        }
        private void update(float x,float w){progress=Math.max(0,Math.min(1,(x-8)/(w-16)));invalidate();}
    }
}
